# Retro YouTube Time Machine (2006–2019)

An interactive historical web reconstruction, temporal video discovery engine, and adaptive 70/30 recommendation system spanning every YouTube era from **2006 to 2019**.

## 1. Purpose & Three Reality Layers

YouTube Data API v3 provides current metadata and publication timestamps (`publishedAt`), but does not expose historical homepage snapshots, historical view/like counts from a past date, or retired 2006–2009 5-star ratings. To maintain strict historical and engineering honesty, this application separates three explicit layers:

- **Katman A — `Historical Reference`**: Documented UI transitions (e.g., 2006–2009 5-star rating widget and right-hand watch metadata box, March 2010 switch to Thumbs Up/Down, July 2011 *Cosmic Panda* dark theater stage, 2013 *Hitchhiker* card layout & *One Channel* banner, 2015 transparent HTML5 player bar, and August 2017 *Polymer* redesign with the standalone red Play icon logo and Dark Theme).
- **Katman B — `Live YouTube Data`**: Real video IDs, UTC publication timestamps (`publishedAfter = YYYY-01-01T00:00:00Z`, `publishedBefore = (YYYY+1)-01-01T00:00:00Z`), channel titles, and current statistics fetched via the backend Express proxy.
- **Katman C — `Simulated Historical Experience`**: Deterministic 5-star rating simulation (`ratingSimulation.ts`), era-weighted 70/30 recommendation profiles (`recommendationEngine.ts`), and local archive fallback when no API key is configured.

## 2. Technology Stack

- **Frontend (`client/`)**: React 18, Vite, TypeScript (strict), Tailwind CSS + CSS Custom Properties (`--tm-*` applied via `data-era` and `data-year`), Zustand (`localStorage` persisted profile v2), Lucide React, Zod, Vitest.
- **Backend (`server/`)**: Node.js (>=18), Express, TypeScript, Axios, `node-cache` (15-minute TTL + in-flight concurrent request deduplication), Zod, Pino structured logging (with secret redaction), Vitest & Supertest.

## 3. Setup & Running Instructions

### Prerequisites
- Node.js `>= 18.0.0` and `npm >= 9.0.0`

### Installation
```bash
npm install
```

### Environment Variables
Copy `.env.example` to `server/.env`:
```bash
cp .env.example server/.env
```
Edit `server/.env` and set your YouTube Data API v3 key (optional — if omitted, the server automatically runs in verified Mock Fallback Mode):
```env
PORT=4000
NODE_ENV=development
CORS_ORIGIN=http://localhost:5173
YOUTUBE_API_KEY=your_youtube_api_key_here
CACHE_TTL_SECONDS=900
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX_REQUESTS=60
```

> **Security Rule**: Never place `YOUTUBE_API_KEY` inside `client/.env` or any `VITE_` variable. The API key lives exclusively on the backend server.

### Development Mode
Run backend (`http://localhost:4000`) and frontend (`http://localhost:5173`):
```bash
npm run dev:server
npm run dev:client
```

### Production Build & Start
```bash
npm run build
npm run start
```

### Verification Commands (Tests, Typecheck, Lint)
```bash
npm run test
npm run typecheck
npm run lint
```

## 4. Quota Protection, Caching & Fallback Behavior

1. **Batched `videos.list` Lookup**: `GET /api/videos` issues one `search.list` call and batches all returned video IDs into a single `videos.list` call (`part=snippet,contentDetails,statistics`).
2. **15-Minute `node-cache` + In-Flight Deduplication**: Identical concurrent requests share a single in-flight upstream Promise so 10 simultaneous requests consume only 1 upstream call.
3. **Automatic Mock Fallback**: When `YOUTUBE_API_KEY` is absent or quota (`403 quotaExceeded`) is reached, the server responds with `isMock: true`, `source: "mock-fallback"`, and period-verified mock records for the requested year.
