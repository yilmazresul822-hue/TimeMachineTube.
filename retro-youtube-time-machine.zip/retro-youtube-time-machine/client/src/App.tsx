import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { create } from 'zustand';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  Search,
  Clock,
  Bookmark,
  Star,
  ThumbsUp,
  ThumbsDown,
  Compass,
  Film,
  Music,
  Gamepad2,
  Cpu,
  Laugh,
  Users,
  Tv,
  GraduationCap,
  Trophy,
  Info,
  Settings,
  User,
  RotateCcw,
  Download,
  Upload,
  Shuffle,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  Eye,
  MessageSquare,
  Share2,
  Code,
  Globe,
  ShieldCheck,
  Database,
  Sliders,
  Trash2,
  ExternalLink,
  Radio,
} from 'lucide-react';

// ============================================================================
// 1. SHARED TYPES & HISTORICAL REALITY LAYER CONTRACTS (Section 2 & 3)
// ============================================================================

export type RealityLayer =
  | 'Historical Reference'
  | 'Live YouTube Data'
  | 'Simulated Historical Experience'
  | 'Estimated Reconstruction';

export type DataSourceType = 'youtube-api' | 'mock-fallback' | 'cache';

export type HistoricalConfidence = 'high' | 'medium-high' | 'estimated-reconstruction';

export interface RatingSimulationResult {
  stars: number;
  roundedHalfStars: number;
  confidence: 'low' | 'medium' | 'high';
  sampleSize: number;
  engagementRatio: number;
  isSimulated: true;
  methodologyNote: string;
}

export interface Video {
  id: string;
  title: string;
  description: string;
  channelId: string;
  channelTitle: string;
  publishedAt: string;
  categoryId: string;
  thumbnailUrl: string;
  viewCount: number | null;
  likeCount: number | null;
  commentCount: number | null;
  duration: string;
  durationSeconds: number;
  liveBroadcastContent: 'none' | 'live' | 'upcoming';
  source: DataSourceType;
  isMock: boolean;
  youtubeEmbedId?: string;
  historicalYear: number;
  yearVerified: boolean;
  historicalPopularity: 'unknown-historical-rank' | 'simulated-era-curated';
  ratingSimulation: RatingSimulationResult | null;
  ratingSimulationAvailable: boolean;
  regionOrigin?: string;
  tags?: string[];
}

export interface CategoryItem {
  id: string;
  title: string;
  iconName: string;
  description: string;
  assignable: boolean;
}

export interface RecommendationProfile {
  profileId: string;
  eraGroup: '2006-2009' | '2010-2013' | '2014-2016' | '2017-2019';
  personalizedRatio: number;
  discoveryRatio: number;
  categoryAffinityWeight: number;
  watchTimeSignalWeight: number;
  channelAffinityWeight: number;
  discoveryBonusWeight: number;
  freshnessSpreadWeight: number;
  qualitySignalWeight: number;
  repetitionPenaltyWeight: number;
  dismissalPenaltyWeight: number;
  description: string;
}

export interface SourceReference {
  title: string;
  url: string;
  layer: RealityLayer;
}

export interface EraConfig {
  year: number;
  eraId: string;
  eraLabel: string;
  eraGroup: 'classic-web' | 'transitional' | 'material-modernization' | 'modern-polymer';
  historicalConfidence: HistoricalConfidence;
  layoutMode: 'portal-centered' | 'structured-960' | 'card-grid-fluid' | 'polymer-wide';
  maxContentWidth: string;
  headerHeight: string;
  navigationMode: 'top-tabs' | 'sub-header-links' | 'guide-drawer' | 'polymer-top-and-mini';
  sidebarMode: 'none' | 'classic-boxes' | 'guide-persistent' | 'polymer-collapsible';
  gridColumns: number;
  thumbnailAspectRatio: '4/3' | '16/9';
  fontFamily: string;
  fontScale: string;
  backgroundColor: string;
  surfaceColor: string;
  surfaceAltColor: string;
  textColor: string;
  mutedTextColor: string;
  linkColor: string;
  borderColor: string;
  accentColor: string;
  buttonStyle: 'glossy-amber' | 'gradient-silver' | 'flat-blue-red' | 'material-raised' | 'polymer-pill';
  cardStyle: 'bordered-box' | 'compact-portal' | 'hitchhiker-card' | 'material-surface' | 'polymer-clean';
  shadowStyle: string;
  borderRadius: string;
  spacingScale: 'compact' | 'normal' | 'spacious';
  showStarRatingSimulation: boolean;
  showLikeDislikeBar: boolean;
  showModernSubscribeButton: boolean;
  showAvatar: boolean;
  showComments: boolean;
  showViewCount: boolean;
  showPublishedDate: boolean;
  searchPresentation: 'boxed-utility' | 'inset-gradient' | 'centered-blue-btn' | 'polymer-minimal';
  loadingStyle: 'classic-text-bar' | 'spinner-red' | 'material-linear' | 'skeleton-cards';
  transitionStyle: 'instant-portal' | 'fade-stage' | 'material-elevation' | 'smooth-polymer';
  recommendationProfile: RecommendationProfile;
  playbackPageLayout: 'classic-right-meta' | 'cosmic-dark-stage' | 'hitchhiker-two-col' | 'polymer-theater';
  channelPageLayout: 'classic-profile-boxes' | 'cosmic-modular' | 'one-channel-banner' | 'polymer-channel-tabs';
  mobileOverrides: {
    collapseSidebar: boolean;
    singleColumnBelowPx: number;
    touchFriendlyControls: boolean;
  };
  historicalNotes: string[];
  verifiedFeatures: string[];
  simulatedFeatures: string[];
  sourceReferences: SourceReference[];
}

// ============================================================================
// 2. COMPLETE ERA MATRIX (2006–2019) (Section 3)
// ============================================================================

const VERIFIED_SOURCES: SourceReference[] = [
  {
    title: 'Version Museum — 14 Years of YouTube Website Design History (2005–2019)',
    url: 'https://www.versionmuseum.com/history-of/youtube-website',
    layer: 'Historical Reference',
  },
  {
    title: 'rausr — The Evolution of YouTube Design: From 320x240 Chaos to Default Video Interface',
    url: 'https://rausr.com/blog/the-evolution-of-youtube-design/',
    layer: 'Historical Reference',
  },
  {
    title: 'Official YouTube Blog — Check out Cosmic Panda (July 2011)',
    url: 'https://blog.youtube/news-and-events/check-out-cosmic-panda-new-experimental/',
    layer: 'Historical Reference',
  },
  {
    title: 'YouTube Data API v3 — Search: list Reference (publishedAfter / publishedBefore / regionCode)',
    url: 'https://developers.google.com/youtube/v3/docs/search/list',
    layer: 'Live YouTube Data',
  },
];

export const RECOMMENDATION_PROFILES: Record<
  '2006-2009' | '2010-2013' | '2014-2016' | '2017-2019',
  RecommendationProfile
> = {
  '2006-2009': {
    profileId: 'rec-classic-portal',
    eraGroup: '2006-2009',
    personalizedRatio: 0.70,
    discoveryRatio: 0.30,
    categoryAffinityWeight: 0.9,
    watchTimeSignalWeight: 0.3,
    channelAffinityWeight: 0.5,
    discoveryBonusWeight: 1.4,
    freshnessSpreadWeight: 1.1,
    qualitySignalWeight: 0.8,
    repetitionPenaltyWeight: 1.5,
    dismissalPenaltyWeight: 2.5,
    description:
      'Classic Web Portal Simulation (2006–2009): Emphasizes cross-category serendipity, eclectic viral discovery, and lower personal filter-bubble lock-in.',
  },
  '2010-2013': {
    profileId: 'rec-transitional-social',
    eraGroup: '2010-2013',
    personalizedRatio: 0.70,
    discoveryRatio: 0.30,
    categoryAffinityWeight: 1.25,
    watchTimeSignalWeight: 0.7,
    channelAffinityWeight: 1.1,
    discoveryBonusWeight: 1.1,
    freshnessSpreadWeight: 1.0,
    qualitySignalWeight: 1.0,
    repetitionPenaltyWeight: 1.6,
    dismissalPenaltyWeight: 2.5,
    description:
      'Transitional Channel & Category Simulation (2010–2013): Balances subscribed channels and category interactions (70%) with temporal discovery (30%).',
  },
  '2014-2016': {
    profileId: 'rec-material-engagement',
    eraGroup: '2014-2016',
    personalizedRatio: 0.70,
    discoveryRatio: 0.30,
    categoryAffinityWeight: 1.45,
    watchTimeSignalWeight: 1.25,
    channelAffinityWeight: 1.2,
    discoveryBonusWeight: 1.0,
    freshnessSpreadWeight: 0.95,
    qualitySignalWeight: 1.1,
    repetitionPenaltyWeight: 1.7,
    dismissalPenaltyWeight: 2.8,
    description:
      'Material Modernization Simulation (2014–2016): Stronger weighting on category interactions and session watch progress alongside structured discovery.',
  },
  '2017-2019': {
    profileId: 'rec-polymer-watchtime',
    eraGroup: '2017-2019',
    personalizedRatio: 0.70,
    discoveryRatio: 0.30,
    categoryAffinityWeight: 1.5,
    watchTimeSignalWeight: 1.65,
    channelAffinityWeight: 1.35,
    discoveryBonusWeight: 1.05,
    freshnessSpreadWeight: 0.9,
    qualitySignalWeight: 1.2,
    repetitionPenaltyWeight: 1.8,
    dismissalPenaltyWeight: 3.0,
    description:
      'Modern Polymer Watch-Time Simulation (2017–2019): Prioritizes active watch duration signals and watch history while reserving 30% for fresh discovery.',
  },
};

export const ERA_CONFIGS: Record<number, EraConfig> = {
  2006: {
    year: 2006,
    eraId: 'classic-2006',
    eraLabel: '2006 — Broadcast Yourself Web 2.0 Utility',
    eraGroup: 'classic-web',
    historicalConfidence: 'high',
    layoutMode: 'portal-centered',
    maxContentWidth: '820px',
    headerHeight: '64px',
    navigationMode: 'top-tabs',
    sidebarMode: 'classic-boxes',
    gridColumns: 3,
    thumbnailAspectRatio: '4/3',
    fontFamily: 'Arial, Tahoma, Helvetica, sans-serif',
    fontScale: '13px',
    backgroundColor: '#f2f2eb',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#e4e8f1',
    textColor: '#111111',
    mutedTextColor: '#555555',
    linkColor: '#0033cc',
    borderColor: '#b5bfd0',
    accentColor: '#cc181e',
    buttonStyle: 'glossy-amber',
    cardStyle: 'bordered-box',
    shadowStyle: 'none',
    borderRadius: '3px',
    spacingScale: 'compact',
    showStarRatingSimulation: true,
    showLikeDislikeBar: false,
    showModernSubscribeButton: false,
    showAvatar: false,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'boxed-utility',
    loadingStyle: 'classic-text-bar',
    transitionStyle: 'instant-portal',
    recommendationProfile: RECOMMENDATION_PROFILES['2006-2009'],
    playbackPageLayout: 'classic-right-meta',
    channelPageLayout: 'classic-profile-boxes',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 640, touchFriendlyControls: true },
    historicalNotes: [
      'In 2006, YouTube operated as a fast-moving Web 2.0 utility with folder-style top navigation tabs, 4:3 thumbnails, blue hyperlinks (#0033cc), and 5-star ratings.',
      'On the watch page, uploader profile details, URL, and HTML Embed code sat in a bordered box to the right of the 4:3 video player.',
    ],
    verifiedFeatures: [
      '5-star rating system (active from 2005 until March 2010)',
      '4:3 aspect ratio video player and bordered thumbnail frames',
      'Right-hand uploader info & Embed HTML input box on the watch page',
      'Folder-style horizontal navigation tabs across the header',
    ],
    simulatedFeatures: [
      'Deterministic 5-star rating computed from modern engagement statistics',
      'Global Chaos Filter (unrestricted international feed without US region lock)',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2007: {
    year: 2007,
    eraId: 'classic-2007',
    eraLabel: '2007 — Early Partner & Flash Portal Era',
    eraGroup: 'classic-web',
    historicalConfidence: 'high',
    layoutMode: 'portal-centered',
    maxContentWidth: '850px',
    headerHeight: '64px',
    navigationMode: 'top-tabs',
    sidebarMode: 'classic-boxes',
    gridColumns: 3,
    thumbnailAspectRatio: '4/3',
    fontFamily: 'Arial, Helvetica, sans-serif',
    fontScale: '13px',
    backgroundColor: '#f5f5f2',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#eaedf4',
    textColor: '#1a1a1a',
    mutedTextColor: '#595959',
    linkColor: '#0033cc',
    borderColor: '#c0c6d2',
    accentColor: '#cc181e',
    buttonStyle: 'glossy-amber',
    cardStyle: 'bordered-box',
    shadowStyle: '0 1px 0 rgba(0,0,0,0.04)',
    borderRadius: '4px',
    spacingScale: 'compact',
    showStarRatingSimulation: true,
    showLikeDislikeBar: false,
    showModernSubscribeButton: false,
    showAvatar: false,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'boxed-utility',
    loadingStyle: 'classic-text-bar',
    transitionStyle: 'instant-portal',
    recommendationProfile: RECOMMENDATION_PROFILES['2006-2009'],
    playbackPageLayout: 'classic-right-meta',
    channelPageLayout: 'classic-profile-boxes',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 640, touchFriendlyControls: true },
    historicalNotes: [
      'Following Google’s acquisition at the end of 2006, 2007 refined the Flash player control bar and launched the Partner Program while preserving dense portal boxes.',
    ],
    verifiedFeatures: [
      '5-star rating display and glossy amber Subscribe button',
      'Sleeker silver/red player control bar',
      'Right-hand expandable uploader info and related videos box',
    ],
    simulatedFeatures: [
      'Simulated 5-star rating and 2007 portal discovery weighting',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2008: {
    year: 2008,
    eraId: 'classic-2008',
    eraLabel: '2008 — Widescreen Player & Classic Portal Peak',
    eraGroup: 'classic-web',
    historicalConfidence: 'high',
    layoutMode: 'portal-centered',
    maxContentWidth: '890px',
    headerHeight: '66px',
    navigationMode: 'top-tabs',
    sidebarMode: 'classic-boxes',
    gridColumns: 3,
    thumbnailAspectRatio: '4/3',
    fontFamily: 'Arial, Tahoma, sans-serif',
    fontScale: '13px',
    backgroundColor: '#f8f8f8',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#edf0f5',
    textColor: '#111111',
    mutedTextColor: '#666666',
    linkColor: '#0033cc',
    borderColor: '#cccccc',
    accentColor: '#d11919',
    buttonStyle: 'glossy-amber',
    cardStyle: 'compact-portal',
    shadowStyle: '0 1px 2px rgba(0,0,0,0.06)',
    borderRadius: '3px',
    spacingScale: 'compact',
    showStarRatingSimulation: true,
    showLikeDislikeBar: false,
    showModernSubscribeButton: false,
    showAvatar: false,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'inset-gradient',
    loadingStyle: 'classic-text-bar',
    transitionStyle: 'instant-portal',
    recommendationProfile: RECOMMENDATION_PROFILES['2006-2009'],
    playbackPageLayout: 'classic-right-meta',
    channelPageLayout: 'classic-profile-boxes',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 640, touchFriendlyControls: true },
    historicalNotes: [
      'In late 2008, YouTube expanded the video player for 16:9 widescreen and 720p HD playback while keeping the classic 5-star ratings and bordered portal modules.',
    ],
    verifiedFeatures: [
      'Classic 5-star rating system and dense portal modules',
      'Silver gradient search bar container and classic blue links',
      'Right-hand channel & embed metadata box on watch pages',
    ],
    simulatedFeatures: [
      'Simulated 5-star rating and Global Chaos Filter',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2009: {
    year: 2009,
    eraId: 'classic-2009',
    eraLabel: '2009 — 1080p HD Arrival & Final Full Year of 5 Stars',
    eraGroup: 'classic-web',
    historicalConfidence: 'high',
    layoutMode: 'portal-centered',
    maxContentWidth: '940px',
    headerHeight: '66px',
    navigationMode: 'top-tabs',
    sidebarMode: 'classic-boxes',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Arial, Helvetica, sans-serif',
    fontScale: '13.5px',
    backgroundColor: '#f6f6f6',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#efefef',
    textColor: '#111111',
    mutedTextColor: '#666666',
    linkColor: '#1144aa',
    borderColor: '#d0d0d0',
    accentColor: '#cc181e',
    buttonStyle: 'glossy-amber',
    cardStyle: 'compact-portal',
    shadowStyle: '0 1px 2px rgba(0,0,0,0.06)',
    borderRadius: '3px',
    spacingScale: 'compact',
    showStarRatingSimulation: true,
    showLikeDislikeBar: false,
    showModernSubscribeButton: false,
    showAvatar: false,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'inset-gradient',
    loadingStyle: 'classic-text-bar',
    transitionStyle: 'instant-portal',
    recommendationProfile: RECOMMENDATION_PROFILES['2006-2009'],
    playbackPageLayout: 'classic-right-meta',
    channelPageLayout: 'classic-profile-boxes',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 640, touchFriendlyControls: true },
    historicalNotes: [
      '2009 was the final full year of the 5-star rating widget before the March 2010 switch to binary Thumbs Up / Thumbs Down.',
      '16:9 widescreen thumbnails and 1080p HD resolution became standard across the platform.',
    ],
    verifiedFeatures: [
      '16:9 widescreen thumbnails paired with 5-star ratings',
      '4-column compact video shelves on desktop',
      'Amber/yellow glossy Subscribe button',
    ],
    simulatedFeatures: [
      'Simulated 5-star ratings derived from engagement statistics',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2010: {
    year: 2010,
    eraId: 'transitional-2010',
    eraLabel: '2010 — Thumbs Up/Down Redesign & Unified Watch Metadata',
    eraGroup: 'transitional',
    historicalConfidence: 'high',
    layoutMode: 'structured-960',
    maxContentWidth: '960px',
    headerHeight: '60px',
    navigationMode: 'sub-header-links',
    sidebarMode: 'none',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Arial, Helvetica, sans-serif',
    fontScale: '13.5px',
    backgroundColor: '#ffffff',
    surfaceColor: '#f8f8f8',
    surfaceAltColor: '#eeeeee',
    textColor: '#222222',
    mutedTextColor: '#666666',
    linkColor: '#1c62b9',
    borderColor: '#dcdcdc',
    accentColor: '#cc181e',
    buttonStyle: 'gradient-silver',
    cardStyle: 'compact-portal',
    shadowStyle: '0 1px 2px rgba(0,0,0,0.05)',
    borderRadius: '3px',
    spacingScale: 'normal',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: false,
    showAvatar: false,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'inset-gradient',
    loadingStyle: 'spinner-red',
    transitionStyle: 'fade-stage',
    recommendationProfile: RECOMMENDATION_PROFILES['2010-2013'],
    playbackPageLayout: 'hitchhiker-two-col',
    channelPageLayout: 'classic-profile-boxes',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 640, touchFriendlyControls: true },
    historicalNotes: [
      'In March 2010, YouTube retired the 5-star rating system and introduced the binary Like/Dislike buttons with a green/red ratio bar.',
      'Uploader info and expandable video description moved directly beneath the video player.',
    ],
    verifiedFeatures: [
      'Replacement of 5-star ratings with Thumbs Up / Thumbs Down & ratio bar',
      'Uploader bar and description positioned below the video player',
      '960px centered layout container',
    ],
    simulatedFeatures: [
      'Simulated dislike proportion bar (public dislike counts were removed from the API in 2021)',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2011: {
    year: 2011,
    eraId: 'transitional-2011',
    eraLabel: '2011 — "Cosmic Panda" Dark Watch Stage & Social Feed',
    eraGroup: 'transitional',
    historicalConfidence: 'high',
    layoutMode: 'structured-960',
    maxContentWidth: '970px',
    headerHeight: '60px',
    navigationMode: 'sub-header-links',
    sidebarMode: 'classic-boxes',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Arial, Helvetica, sans-serif',
    fontScale: '14px',
    backgroundColor: '#ebebeb',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#232323',
    textColor: '#222222',
    mutedTextColor: '#666666',
    linkColor: '#1c62b9',
    borderColor: '#d4d4d4',
    accentColor: '#cc181e',
    buttonStyle: 'gradient-silver',
    cardStyle: 'compact-portal',
    shadowStyle: '0 2px 4px rgba(0,0,0,0.08)',
    borderRadius: '4px',
    spacingScale: 'normal',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: false,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'inset-gradient',
    loadingStyle: 'spinner-red',
    transitionStyle: 'fade-stage',
    recommendationProfile: RECOMMENDATION_PROFILES['2010-2013'],
    playbackPageLayout: 'cosmic-dark-stage',
    channelPageLayout: 'cosmic-modular',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 640, touchFriendlyControls: true },
    historicalNotes: [
      'In July 2011, YouTube launched the "Cosmic Panda" redesign featuring a dark charcoal cinema stage surrounding the active video player and modular channel layouts.',
    ],
    verifiedFeatures: [
      'Cosmic Panda dark charcoal theater stage around the active video player',
      'Left-hand category & channel guide sidebar on the homepage',
      'Module-based channel page layout',
    ],
    simulatedFeatures: [
      'Transitional recommendation profile balancing categories (70%) and discovery (30%)',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2012: {
    year: 2012,
    eraId: 'transitional-2012',
    eraLabel: '2012 — Guide Sidebar & Watch-Time Algorithm Transition',
    eraGroup: 'transitional',
    historicalConfidence: 'high',
    layoutMode: 'structured-960',
    maxContentWidth: '1000px',
    headerHeight: '58px',
    navigationMode: 'guide-drawer',
    sidebarMode: 'guide-persistent',
    gridColumns: 3,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Arial, Helvetica, sans-serif',
    fontScale: '14px',
    backgroundColor: '#f1f1f1',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#282828',
    textColor: '#222222',
    mutedTextColor: '#666666',
    linkColor: '#167ac6',
    borderColor: '#e2e2e2',
    accentColor: '#cc181e',
    buttonStyle: 'flat-blue-red',
    cardStyle: 'hitchhiker-card',
    shadowStyle: '0 1px 2px rgba(0,0,0,0.1)',
    borderRadius: '2px',
    spacingScale: 'normal',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: true,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'inset-gradient',
    loadingStyle: 'spinner-red',
    transitionStyle: 'fade-stage',
    recommendationProfile: RECOMMENDATION_PROFILES['2010-2013'],
    playbackPageLayout: 'hitchhiker-two-col',
    channelPageLayout: 'cosmic-modular',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 768, touchFriendlyControls: true },
    historicalNotes: [
      'In 2012, YouTube shifted its recommendation emphasis toward watch time and introduced the persistent left Guide sidebar and white card shelves on #f1f1f1.',
    ],
    verifiedFeatures: [
      'Persistent left Guide navigation column',
      'Clean white card containers on a #f1f1f1 canvas',
      'Red rectangular Subscribe badge',
    ],
    simulatedFeatures: [
      'Default US regionCode filter with user override option',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2013: {
    year: 2013,
    eraId: 'transitional-2013',
    eraLabel: '2013 — "Hitchhiker" Card Layout & "One Channel" Banner Design',
    eraGroup: 'transitional',
    historicalConfidence: 'high',
    layoutMode: 'structured-960',
    maxContentWidth: '1040px',
    headerHeight: '56px',
    navigationMode: 'guide-drawer',
    sidebarMode: 'guide-persistent',
    gridColumns: 3,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Arial, Helvetica, sans-serif',
    fontScale: '14px',
    backgroundColor: '#f1f1f1',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#f9f9f9',
    textColor: '#222222',
    mutedTextColor: '#767676',
    linkColor: '#167ac6',
    borderColor: '#e2e2e2',
    accentColor: '#cc181e',
    buttonStyle: 'flat-blue-red',
    cardStyle: 'hitchhiker-card',
    shadowStyle: '0 1px 2px rgba(0,0,0,0.08)',
    borderRadius: '2px',
    spacingScale: 'normal',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: true,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'centered-blue-btn',
    loadingStyle: 'material-linear',
    transitionStyle: 'fade-stage',
    recommendationProfile: RECOMMENDATION_PROFILES['2010-2013'],
    playbackPageLayout: 'hitchhiker-two-col',
    channelPageLayout: 'one-channel-banner',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 768, touchFriendlyControls: true },
    historicalNotes: [
      '2013 standardized the "Hitchhiker" desktop card layout and the "One Channel" responsive banner header across desktop, mobile, and TV.',
    ],
    verifiedFeatures: [
      'One Channel responsive banner art header on creator pages',
      'Hitchhiker white modular shelves on #f1f1f1 canvas',
      'Top red linear loading bar during page transitions',
    ],
    simulatedFeatures: [
      'One Channel banner reconstruction and Hitchhiker shelf ranking',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2014: {
    year: 2014,
    eraId: 'material-2014',
    eraLabel: '2014 — Centered Guide Header & 60fps Creator Platform Era',
    eraGroup: 'material-modernization',
    historicalConfidence: 'medium-high',
    layoutMode: 'card-grid-fluid',
    maxContentWidth: '1120px',
    headerHeight: '56px',
    navigationMode: 'guide-drawer',
    sidebarMode: 'guide-persistent',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Roboto, Arial, sans-serif',
    fontScale: '14px',
    backgroundColor: '#f1f1f1',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#f5f5f5',
    textColor: '#222222',
    mutedTextColor: '#767676',
    linkColor: '#167ac6',
    borderColor: '#e0e0e0',
    accentColor: '#cc181e',
    buttonStyle: 'flat-blue-red',
    cardStyle: 'hitchhiker-card',
    shadowStyle: '0 1px 3px rgba(0,0,0,0.1)',
    borderRadius: '2px',
    spacingScale: 'normal',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: true,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'centered-blue-btn',
    loadingStyle: 'material-linear',
    transitionStyle: 'material-elevation',
    recommendationProfile: RECOMMENDATION_PROFILES['2014-2016'],
    playbackPageLayout: 'hitchhiker-two-col',
    channelPageLayout: 'one-channel-banner',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 768, touchFriendlyControls: true },
    historicalNotes: [
      'In 2014, YouTube introduced 60fps video playback, Creator Studio, and centered the header search bar with Roboto typography.',
    ],
    verifiedFeatures: [
      'Centered header search bar with toggleable Guide menu',
      'Roboto font stack adoption alongside Hitchhiker cards',
      'Blue #167ac6 accent bar under active tabs and like ratios',
    ],
    simulatedFeatures: [
      'Engagement-weighted recommendation profile (70/30 split)',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2015: {
    year: 2015,
    eraId: 'material-2015',
    eraLabel: '2015 — Transparent HTML5 Player & Material Design Surfaces',
    eraGroup: 'material-modernization',
    historicalConfidence: 'high',
    layoutMode: 'card-grid-fluid',
    maxContentWidth: '1180px',
    headerHeight: '56px',
    navigationMode: 'guide-drawer',
    sidebarMode: 'guide-persistent',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Roboto, Arial, sans-serif',
    fontScale: '14px',
    backgroundColor: '#f1f1f1',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#f9f9f9',
    textColor: '#212121',
    mutedTextColor: '#757575',
    linkColor: '#167ac6',
    borderColor: '#e0e0e0',
    accentColor: '#e62117',
    buttonStyle: 'material-raised',
    cardStyle: 'material-surface',
    shadowStyle: '0 2px 4px rgba(0,0,0,0.1)',
    borderRadius: '2px',
    spacingScale: 'normal',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: true,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'centered-blue-btn',
    loadingStyle: 'material-linear',
    transitionStyle: 'material-elevation',
    recommendationProfile: RECOMMENDATION_PROFILES['2014-2016'],
    playbackPageLayout: 'hitchhiker-two-col',
    channelPageLayout: 'one-channel-banner',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 768, touchFriendlyControls: true },
    historicalNotes: [
      'In 2015, YouTube defaulted to the transparent-bar HTML5 video player, added the "Up Next" autoplay toggle switch, and adopted brighter #e62117 red branding.',
    ],
    verifiedFeatures: [
      'Transparent bottom scrubber overlay in the HTML5 player',
      'Up Next sidebar header with Autoplay toggle control',
      'Home / Trending / Subscriptions top tab strip',
    ],
    simulatedFeatures: [
      'Simulated Up Next queue and Material elevation surfaces',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2016: {
    year: 2016,
    eraId: 'material-2016',
    eraLabel: '2016 — Late Hitchhiker & Early Material Design Preview',
    eraGroup: 'material-modernization',
    historicalConfidence: 'medium-high',
    layoutMode: 'card-grid-fluid',
    maxContentWidth: '1220px',
    headerHeight: '56px',
    navigationMode: 'guide-drawer',
    sidebarMode: 'guide-persistent',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Roboto, Arial, sans-serif',
    fontScale: '14px',
    backgroundColor: '#f3f3f3',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#fafafa',
    textColor: '#111111',
    mutedTextColor: '#737373',
    linkColor: '#167ac6',
    borderColor: '#e5e5e5',
    accentColor: '#e62117',
    buttonStyle: 'material-raised',
    cardStyle: 'material-surface',
    shadowStyle: '0 2px 5px rgba(0,0,0,0.08)',
    borderRadius: '3px',
    spacingScale: 'normal',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: true,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'centered-blue-btn',
    loadingStyle: 'material-linear',
    transitionStyle: 'material-elevation',
    recommendationProfile: RECOMMENDATION_PROFILES['2014-2016'],
    playbackPageLayout: 'hitchhiker-two-col',
    channelPageLayout: 'one-channel-banner',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 768, touchFriendlyControls: true },
    historicalNotes: [
      'In 2016, YouTube began opt-in testing of its Material Design rewrite while most desktop users experienced the mature Hitchhiker layout with Trending tabs and creator hearts on comments.',
    ],
    verifiedFeatures: [
      'Dedicated Trending navigation item and cleaner card spacing',
      'Creator comment appreciation badges and replies',
    ],
    simulatedFeatures: [
      'Material transition styling and watch-history affinity scoring',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2017: {
    year: 2017,
    eraId: 'modern-2017',
    eraLabel: '2017 — Polymer Redesign, Standalone Play Logo & Dark Theme Launch',
    eraGroup: 'modern-polymer',
    historicalConfidence: 'high',
    layoutMode: 'polymer-wide',
    maxContentWidth: '1280px',
    headerHeight: '56px',
    navigationMode: 'polymer-top-and-mini',
    sidebarMode: 'polymer-collapsible',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Roboto, Inter, Arial, sans-serif',
    fontScale: '14px',
    backgroundColor: '#fafafa',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#f2f2f2',
    textColor: '#0a0a0a',
    mutedTextColor: '#606060',
    linkColor: '#065fd4',
    borderColor: '#e5e5e5',
    accentColor: '#ff0000',
    buttonStyle: 'polymer-pill',
    cardStyle: 'polymer-clean',
    shadowStyle: 'none',
    borderRadius: '2px',
    spacingScale: 'spacious',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: true,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'polymer-minimal',
    loadingStyle: 'skeleton-cards',
    transitionStyle: 'smooth-polymer',
    recommendationProfile: RECOMMENDATION_PROFILES['2017-2019'],
    playbackPageLayout: 'polymer-theater',
    channelPageLayout: 'polymer-channel-tabs',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 768, touchFriendlyControls: true },
    historicalNotes: [
      'In August 2017, YouTube launched its landmark Polymer redesign globally alongside a new logo: a pure red (#FF0000) play icon placed in front of the "YouTube" wordmark.',
      'Desktop gained native Dark Theme support and borderless video cards with circular channel avatars.',
    ],
    verifiedFeatures: [
      '2017 standalone red Play Icon + wordmark logo',
      'Borderless Polymer video cards with circular channel avatars',
      'Native Dark Theme toggle support on desktop',
    ],
    simulatedFeatures: [
      'Watch-time weighted 70/30 recommendation engine',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2018: {
    year: 2018,
    eraId: 'modern-2018',
    eraLabel: '2018 — Refined Polymer Grid & Mini-Guide Navigation',
    eraGroup: 'modern-polymer',
    historicalConfidence: 'high',
    layoutMode: 'polymer-wide',
    maxContentWidth: '1340px',
    headerHeight: '56px',
    navigationMode: 'polymer-top-and-mini',
    sidebarMode: 'polymer-collapsible',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Roboto, Inter, Arial, sans-serif',
    fontScale: '14px',
    backgroundColor: '#f9f9f9',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#f1f1f1',
    textColor: '#0d0d0d',
    mutedTextColor: '#606060',
    linkColor: '#065fd4',
    borderColor: '#e5e5e5',
    accentColor: '#ff0000',
    buttonStyle: 'polymer-pill',
    cardStyle: 'polymer-clean',
    shadowStyle: 'none',
    borderRadius: '2px',
    spacingScale: 'spacious',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: true,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'polymer-minimal',
    loadingStyle: 'skeleton-cards',
    transitionStyle: 'smooth-polymer',
    recommendationProfile: RECOMMENDATION_PROFILES['2017-2019'],
    playbackPageLayout: 'polymer-theater',
    channelPageLayout: 'polymer-channel-tabs',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 768, touchFriendlyControls: true },
    historicalNotes: [
      '2018 refined the Polymer interface with a compact mini-guide sidebar when collapsed, wider theater playback, and creator community engagement surfaces.',
    ],
    verifiedFeatures: [
      'Collapsible mini-guide rail with icon + label',
      'Sharp 16:9 thumbnails (prior to 2022 rounded corners)',
      'Visible public Like/Dislike ratio bar below watch actions',
    ],
    simulatedFeatures: [
      'Session watch-duration scoring in recommendation ranking',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
  2019: {
    year: 2019,
    eraId: 'modern-2019',
    eraLabel: '2019 — High-Density Polymer Homepage (Pre-Shorts Era)',
    eraGroup: 'modern-polymer',
    historicalConfidence: 'high',
    layoutMode: 'polymer-wide',
    maxContentWidth: '1400px',
    headerHeight: '56px',
    navigationMode: 'polymer-top-and-mini',
    sidebarMode: 'polymer-collapsible',
    gridColumns: 4,
    thumbnailAspectRatio: '16/9',
    fontFamily: 'Roboto, Inter, Arial, sans-serif',
    fontScale: '14.5px',
    backgroundColor: '#f9f9f9',
    surfaceColor: '#ffffff',
    surfaceAltColor: '#f0f0f0',
    textColor: '#030303',
    mutedTextColor: '#606060',
    linkColor: '#065fd4',
    borderColor: '#e0e0e0',
    accentColor: '#ff0000',
    buttonStyle: 'polymer-pill',
    cardStyle: 'polymer-clean',
    shadowStyle: 'none',
    borderRadius: '2px',
    spacingScale: 'spacious',
    showStarRatingSimulation: false,
    showLikeDislikeBar: true,
    showModernSubscribeButton: true,
    showAvatar: true,
    showComments: true,
    showViewCount: true,
    showPublishedDate: true,
    searchPresentation: 'polymer-minimal',
    loadingStyle: 'skeleton-cards',
    transitionStyle: 'smooth-polymer',
    recommendationProfile: RECOMMENDATION_PROFILES['2017-2019'],
    playbackPageLayout: 'polymer-theater',
    channelPageLayout: 'polymer-channel-tabs',
    mobileOverrides: { collapseSidebar: true, singleColumnBelowPx: 768, touchFriendlyControls: true },
    historicalNotes: [
      'In 2019, YouTube shifted the homepage to larger 4-per-row cards with rich metadata, while still predating the 2020–2021 Shorts tab, 2021 Dislike count removal, and 2022 ambient/rounded redesign.',
    ],
    verifiedFeatures: [
      '4-column wide Polymer cards with sharp rectangular thumbnails',
      'Public Like and Dislike counts and ratio bar still visible',
      'No Shorts shelf or ambient mode (accurate to 2019)',
    ],
    simulatedFeatures: [
      'Watch-time & history recommendation ranking with 70/30 discovery split',
    ],
    sourceReferences: VERIFIED_SOURCES,
  },
};

export const SUPPORTED_YEARS = [
  2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019,
] as const;

export function getEraConfig(year: number): EraConfig {
  return ERA_CONFIGS[year] ?? ERA_CONFIGS[2008];
}

// ============================================================================
// 3. UTC DATE LOCK, GLOBAL CHAOS FILTER & STAR RATING SIMULATION (Section 6 & 12)
// ============================================================================

export function getUtcYearBounds(year: number) {
  const safeYear = Math.min(2019, Math.max(2006, Math.round(year)));
  return {
    year: safeYear,
    publishedAfter: `${safeYear}-01-01T00:00:00Z`,
    publishedBefore: `${safeYear + 1}-01-01T00:00:00Z`,
  };
}

export function verifyPublishedYearUtc(publishedAtIso: string, targetYear: number): boolean {
  if (!publishedAtIso || typeof publishedAtIso !== 'string') return false;
  const ts = Date.parse(publishedAtIso);
  if (Number.isNaN(ts)) return false;
  return new Date(ts).getUTCFullYear() === targetYear;
}

export function resolveRegionPolicy(
  year: number,
  userRegionCode: string
): { regionCode: string | null; globalChaosActive: boolean } {
  const cleaned = userRegionCode.trim().toUpperCase();
  if (cleaned && cleaned !== 'AUTO' && /^[A-Z]{2}$/.test(cleaned)) {
    return { regionCode: cleaned, globalChaosActive: false };
  }
  if (year >= 2006 && year <= 2011) {
    return { regionCode: null, globalChaosActive: true };
  }
  return { regionCode: 'US', globalChaosActive: false };
}

export function computeSimulatedStarRating(
  videoId: string,
  viewCount: number | null,
  likeCount: number | null,
  commentCount: number | null
): RatingSimulationResult | null {
  if (viewCount === null && likeCount === null) return null;
  const safeViews = Math.max(0, viewCount ?? 0);
  const safeLikes = Math.max(0, likeCount ?? 0);
  const safeComments = Math.max(0, commentCount ?? 0);
  if (safeViews === 0 && safeLikes === 0) return null;

  let hash = 0;
  for (let i = 0; i < videoId.length; i += 1) {
    hash = (hash * 31 + videoId.charCodeAt(i)) % 1000;
  }
  const deterministicJitter = ((hash % 21) - 10) * 0.01;
  const effectiveDenominator = Math.max(safeViews, safeLikes, 1);
  const likeRatio = safeLikes / effectiveDenominator;
  const engagementRatio = (safeLikes + safeComments * 1.5) / effectiveDenominator;
  const normalizedEngagement = Math.min(
    1,
    Math.max(0, Math.log10(Math.max(engagementRatio * 1000, 1)) / Math.log10(80))
  );

  const rawStars = 2.6 + normalizedEngagement * 2.3 + deterministicJitter;
  const clampedStars = Math.min(5.0, Math.max(1.0, Number(rawStars.toFixed(2))));
  const roundedHalfStars = Math.min(5.0, Math.max(1.0, Math.round(clampedStars * 2) / 2));

  let confidence: 'low' | 'medium' | 'high' = 'low';
  if (safeViews >= 50_000 && safeLikes >= 250) {
    confidence = 'high';
  } else if (safeViews >= 1_000 && safeLikes >= 15) {
    confidence = 'medium';
  }

  return {
    stars: clampedStars,
    roundedHalfStars,
    confidence,
    sampleSize: safeLikes + safeComments,
    engagementRatio: Number(likeRatio.toFixed(4)),
    isSimulated: true,
    methodologyNote:
      'Simulated 5-star rating derived from engagement density (likes & comments relative to log-scaled views). Historical 2006-2009 star ratings are not exposed by YouTube Data API v3.',
  };
}

// ============================================================================
// 4. MOCK DATASET & GENERATED THUMBNAIL STRATEGY (Section 8)
// ============================================================================

const GENERATED_CATEGORY_THUMBNAILS: Record<string, string> = {
  '10': 'user_uploaded_files/ttl=63d/tool_generated/thumb_music.jpg',
  '20': 'user_uploaded_files/ttl=63d/tool_generated/thumb_gaming.jpg',
  '28': 'user_uploaded_files/ttl=63d/tool_generated/thumb_tech.jpg',
  '1': 'user_uploaded_files/ttl=63d/tool_generated/thumb_creative.jpg',
};

export const CATEGORIES: CategoryItem[] = [
  { id: 'all', title: 'All Categories', iconName: 'Compass', description: 'Complete temporal stream for the selected year', assignable: true },
  { id: '1', title: 'Film & Animation', iconName: 'Film', description: 'Stop-motion, indie shorts, Flash animations & machinima', assignable: true },
  { id: '10', title: 'Music', iconName: 'Music', description: 'Synthesizer sessions, indie bands & iconic music videos', assignable: true },
  { id: '20', title: 'Gaming', iconName: 'Gamepad2', description: 'Let’s Plays, speedruns, CRT walkthroughs & tournament clips', assignable: true },
  { id: '28', title: 'Science & Technology', iconName: 'Cpu', description: 'Unboxings, hardware teardowns, coding demos & experiments', assignable: true },
  { id: '23', title: 'Comedy', iconName: 'Laugh', description: 'Sketches, viral parodies & classic internet humor', assignable: true },
  { id: '22', title: 'People & Blogs', iconName: 'Users', description: 'Webcam vlogs, Q&As & creator community diaries', assignable: true },
  { id: '24', title: 'Entertainment', iconName: 'Tv', description: 'Pop culture, collaborative challenges & web shows', assignable: true },
  { id: '27', title: 'Education', iconName: 'GraduationCap', description: 'Physics demonstrations, math proofs & history deep dives', assignable: true },
  { id: '17', title: 'Sports', iconName: 'Trophy', description: 'Skateboarding tapes, trick shots & street highlights', assignable: true },
];

export function buildSvgFallbackThumbnail(year: number, categoryId: string, title: string): string {
  const palette: Record<string, [string, string, string]> = {
    '10': ['#1e1b4b', '#4338ca', '#f59e0b'],
    '20': ['#064e3b', '#047857', '#34d399'],
    '28': ['#0f172a', '#0369a1', '#38bdf8'],
    '1': ['#4c1d95', '#7e22ce', '#f472b6'],
    '23': ['#7c2d12', '#c2410c', '#fbbf24'],
    '22': ['#1f2937', '#374151', '#60a5fa'],
    '24': ['#3b0764', '#6b21a8', '#c084fc'],
    '27': ['#14532d', '#15803d', '#fde047'],
    '17': ['#31102F', '#9d174d', '#fb7185'],
  };
  const [c1, c2, accent] = palette[categoryId] || ['#1e293b', '#334155', '#ef4444'];
  const cleanTitle = title.slice(0, 34).replace(/[<>&"']/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="480" height="270" viewBox="0 0 480 270">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${c1}"/>
        <stop offset="100%" stop-color="${c2}"/>
      </linearGradient>
    </defs>
    <rect width="480" height="270" fill="url(#g)"/>
    <circle cx="385" cy="78" r="88" fill="${accent}" fill-opacity="0.18"/>
    <circle cx="95" cy="145" r="56" fill="#ffffff" fill-opacity="0.06"/>
    <rect x="22" y="20" width="98" height="28" rx="4" fill="#000000" fill-opacity="0.6"/>
    <text x="71" y="39" fill="${accent}" font-family="Arial, sans-serif" font-size="13" font-weight="bold" text-anchor="middle">${year} ARCHIVE</text>
    <polygon points="222,102 222,158 268,130" fill="#ffffff" fill-opacity="0.85"/>
    <text x="22" y="220" fill="#ffffff" font-family="Arial, sans-serif" font-size="16" font-weight="bold">${cleanTitle}</text>
    <text x="22" y="244" fill="#cbd5e1" font-family="Arial, sans-serif" font-size="11">LOCAL ARCHIVE RECORD • CAT ${categoryId}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

interface RawRealYoutubeSeed {
  id: string;
  year: number;
  title: string;
  channelId: string;
  channelTitle: string;
  publishedAt: string;
  categoryId: string;
  duration: string;
  durationSeconds: number;
  viewCount: number;
  likeCount: number;
  commentCount: number;
  description: string;
  regionOrigin: string;
  tags: string[];
}

export const REAL_YOUTUBE_ARCHIVE_SEEDS: RawRealYoutubeSeed[] = [
  // === 2006 ===
  {
    id: 'dMH0bHeiRNg',
    year: 2006,
    title: 'Evolution of Dance',
    channelId: 'UC5B9H4b22142',
    channelTitle: 'Judson Laipply',
    publishedAt: '2006-04-06T22:55:00Z',
    categoryId: '23',
    duration: 'PT6M1S',
    durationSeconds: 361,
    viewCount: 315_774_206,
    likeCount: 1_456_989,
    commentCount: 142_300,
    description: 'Judson Laipply performs his iconic 6-minute live comedy dance routine spanning decades of popular music — YouTube’s #1 most-watched video in 2006.',
    regionOrigin: 'US',
    tags: ['dance', 'evolution', 'comedy', '2006', 'viral'],
  },
  {
    id: 'bNF_P281Uu4',
    year: 2006,
    title: 'Where the Hell is Matt? (2006)',
    channelId: 'UCmatt2006',
    channelTitle: 'Where the Hell is Matt?',
    publishedAt: '2006-06-20T14:20:00Z',
    categoryId: '19',
    duration: 'PT3M43S',
    durationSeconds: 223,
    viewCount: 20_394_585,
    likeCount: 111_448,
    commentCount: 19_400,
    description: 'Matt Harding dances badly in 39 countries across 6 continents in one of the defining global travel videos of 2006 YouTube.',
    regionOrigin: 'AU',
    tags: ['travel', 'dance', 'world', 'matt', '2006'],
  },
  {
    id: '6B26asyGKDo',
    year: 2006,
    title: 'Noah takes a photo of himself every day for 6 years.',
    channelId: 'UCnoahkalina',
    channelTitle: 'Noah Kalina',
    publishedAt: '2006-08-28T18:10:00Z',
    categoryId: '1',
    duration: 'PT5M46S',
    durationSeconds: 346,
    viewCount: 27_508_438,
    likeCount: 167_244,
    commentCount: 28_900,
    description: 'From January 11, 2000 to July 31, 2006 — the pioneering daily selfie time-lapse short film accompanied by Carly Comando’s solo piano score.',
    regionOrigin: 'US',
    tags: ['timelapse', 'photography', 'everyday', 'art', '2006'],
  },
  {
    id: 'vr3x_RRJdd4',
    year: 2006,
    title: 'Free Hugs Campaign - Official Page (music by Sick Puppies)',
    channelId: 'UCfreehugs',
    channelTitle: 'PeaceOnEarth123',
    publishedAt: '2006-09-23T09:15:00Z',
    categoryId: '22',
    duration: 'PT3M40S',
    durationSeconds: 220,
    viewCount: 79_070_516,
    likeCount: 239_175,
    commentCount: 44_200,
    description: 'Juan Mann’s Sydney Pitt Street Mall social movement video that sparked global flashmobs across 2006 YouTube.',
    regionOrigin: 'AU',
    tags: ['freehugs', 'community', 'sydney', 'music', '2006'],
  },
  {
    id: 'o9698TqtY4A',
    year: 2006,
    title: 'Hyperactive',
    channelId: 'UClasse',
    channelTitle: 'Lasse Gjertsen',
    publishedAt: '2006-05-08T16:40:00Z',
    categoryId: '1',
    duration: 'PT2M7S',
    durationSeconds: 127,
    viewCount: 9_402_326,
    likeCount: 102_251,
    commentCount: 14_800,
    description: 'Norwegian animator Lasse Gjertsen’s stop-motion frame-cut beatbox routine edited in Premiere Pro without knowing how to play drums.',
    regionOrigin: 'NO',
    tags: ['beatbox', 'editing', 'stopmotion', 'music', '2006'],
  },
  {
    id: 'JzqumbhfxRo',
    year: 2006,
    title: 'Amateur (Piano & Drums Video Edit)',
    channelId: 'UClasse',
    channelTitle: 'Lasse Gjertsen',
    publishedAt: '2006-11-07T19:00:00Z',
    categoryId: '10',
    duration: 'PT3M14S',
    durationSeconds: 194,
    viewCount: 16_860_183,
    likeCount: 173_168,
    commentCount: 22_100,
    description: 'Single-note piano and drum hits cut together frame by frame into a full polyphonic composition in late 2006.',
    regionOrigin: 'NO',
    tags: ['piano', 'drums', 'editing', 'music', '2006'],
  },

  // === 2007 ===
  {
    id: 'EwTZ2xpQwpA',
    year: 2007,
    title: '"Chocolate Rain" Original Song by Tay Zonday',
    channelId: 'UCtayzonday',
    channelTitle: 'TayZonday',
    publishedAt: '2007-04-23T05:12:00Z',
    categoryId: '10',
    duration: 'PT4M53S',
    durationSeconds: 293,
    viewCount: 143_391_762,
    likeCount: 1_623_546,
    commentCount: 198_400,
    description: '"I move away from the mic to breathe in" — Tay Zonday’s baritone home-studio original song that defined 2007 internet culture.',
    regionOrigin: 'US',
    tags: ['chocolaterain', 'tayzonday', 'music', 'original', '2007'],
  },
  {
    id: '_OBlgSz8sSM',
    year: 2007,
    title: 'Charlie bit my finger - again !',
    channelId: 'UChdcyt',
    channelTitle: 'HDCYT',
    publishedAt: '2007-05-22T19:30:00Z',
    categoryId: '22',
    duration: 'PT56S',
    durationSeconds: 56,
    viewCount: 889_504_935,
    likeCount: 2_380_892,
    commentCount: 215_000,
    description: 'Harry and baby brother Charlie in the UK family video that became the most-viewed video on YouTube during the late 2000s.',
    regionOrigin: 'GB',
    tags: ['charlie', 'family', 'uk', 'viral', '2007'],
  },
  {
    id: 'J---aiyznGQ',
    year: 2007,
    title: 'Keyboard Cat! - THE ORIGINAL!',
    channelId: 'UCkeyboardcat',
    channelTitle: 'Keyboard Cat!',
    publishedAt: '2007-06-07T14:22:00Z',
    categoryId: '23',
    duration: 'PT55S',
    durationSeconds: 55,
    viewCount: 96_215_476,
    likeCount: 2_982_385,
    commentCount: 164_000,
    description: 'Charlie Schmidt’s cat Fatso in a blue shirt playing an upbeat electronic keyboard tune.',
    regionOrigin: 'US',
    tags: ['cat', 'keyboard', 'comedy', 'meme', '2007'],
  },
  {
    id: 'Tx1XIm6q4r4',
    year: 2007,
    title: 'Potter Puppet Pals: The Mysterious Ticking Noise',
    channelId: 'UCneilcic',
    channelTitle: 'Neil Cicierega',
    publishedAt: '2007-03-24T17:45:00Z',
    categoryId: '1',
    duration: 'PT2M7S',
    durationSeconds: 127,
    viewCount: 211_747_783,
    likeCount: 2_025_346,
    commentCount: 242_000,
    description: 'Neil Cicierega’s musical puppet show parody ("Snape, Snape, Severus Snape") that won the 2007 YouTube Video Award for Best Comedy.',
    regionOrigin: 'US',
    tags: ['puppets', 'parody', 'comedy', 'animation', '2007'],
  },
  {
    id: 'gq7r3F1SoX0',
    year: 2007,
    title: 'OK Go - Here It Goes Again (High School Treadmill Tribute)',
    channelId: 'UCbenhiler',
    channelTitle: 'Ben Hiler',
    publishedAt: '2007-01-28T20:10:00Z',
    categoryId: '24',
    duration: 'PT3M6S',
    durationSeconds: 186,
    viewCount: 7_367_303,
    likeCount: 64_819,
    commentCount: 4_820,
    description: 'Full synchronized 4-treadmill choreography performed live on stage in early 2007.',
    regionOrigin: 'US',
    tags: ['okgo', 'treadmill', 'dance', 'live', '2007'],
  },

  // === 2008 ===
  {
    id: '4rb8aOzy9t4',
    year: 2008,
    title: "Let Me In! - Simon's Cat",
    channelId: 'UCsimonscat',
    channelTitle: "Simon's Cat",
    publishedAt: '2008-03-04T15:18:00Z',
    categoryId: '1',
    duration: 'PT1M52S',
    durationSeconds: 112,
    viewCount: 48_258_882,
    likeCount: 217_898,
    commentCount: 11_400,
    description: 'Simon Tofield’s classic hand-drawn Flash animation of a hungry cat doing whatever it takes to get through the back door.',
    regionOrigin: 'GB',
    tags: ['animation', 'simonscat', 'cat', 'indie', '2008'],
  },
  {
    id: 'eCGTZ-1LGRw',
    year: 2008,
    title: 'Spore - iPhone SDK Accelerometer Demo (2008)',
    channelId: 'UCea',
    channelTitle: 'Electronic Arts',
    publishedAt: '2008-04-11T18:00:00Z',
    categoryId: '20',
    duration: 'PT4M18S',
    durationSeconds: 258,
    viewCount: 329_309,
    likeCount: 540,
    commentCount: 290,
    description: 'Early 2008 demonstration of Will Wright’s Spore creature creator and tilt physics running on the first-generation iPhone OS 2.0 SDK.',
    regionOrigin: 'US',
    tags: ['spore', 'iphone', 'gaming', 'tech', '2008'],
  },
  {
    id: 'VVcwqQlwnmY',
    year: 2008,
    title: 'Google TechTalks: Where the Hell is Matt? (2008)',
    channelId: 'UCgoogletech',
    channelTitle: 'Google TechTalks',
    publishedAt: '2008-08-21T21:00:00Z',
    categoryId: '28',
    duration: 'PT58M33S',
    durationSeconds: 3513,
    viewCount: 35_014,
    likeCount: 157,
    commentCount: 48,
    description: 'Matt Harding visits Google headquarters in August 2008 to discuss how global viral video communities formed on early YouTube.',
    regionOrigin: 'US',
    tags: ['google', 'techtalk', 'viral', 'history', '2008'],
  },
  {
    id: 'kdE0Q5RDEsc',
    year: 2008,
    title: 'Will It Blend? — Technology & Enterprise Edition (2008)',
    channelId: 'UCnovell',
    channelTitle: 'NovellVideo',
    publishedAt: '2008-01-14T12:30:00Z',
    categoryId: '28',
    duration: 'PT2M40S',
    durationSeconds: 160,
    viewCount: 16_148,
    likeCount: 140,
    commentCount: 32,
    description: 'Classic 2008 industrial blender stress test from the golden era of hardware destruction experiments.',
    regionOrigin: 'US',
    tags: ['blendtec', 'tech', 'experiment', '2008'],
  },

  // === 2009 ===
  {
    id: 'txqiwrbYGrs',
    year: 2009,
    title: 'David After Dentist',
    channelId: 'UCbooba1234',
    channelTitle: 'booba1234',
    publishedAt: '2009-01-31T04:10:00Z',
    categoryId: '22',
    duration: 'PT1M59S',
    durationSeconds: 119,
    viewCount: 143_743_520,
    likeCount: 520_417,
    commentCount: 96_000,
    description: '"Is this real life?" — Seven-year-old David DeVore’s car ride home from oral surgery in January 2009.',
    regionOrigin: 'US',
    tags: ['david', 'dentist', 'vlog', 'family', '2009'],
  },
  {
    id: 'dQw4w9WgXcQ',
    year: 2009,
    title: 'Rick Astley - Never Gonna Give You Up (Official Video)',
    channelId: 'UCrickastley',
    channelTitle: 'Rick Astley',
    publishedAt: '2009-10-25T06:57:00Z',
    categoryId: '10',
    duration: 'PT3M34S',
    durationSeconds: 214,
    viewCount: 1_828_481_386,
    likeCount: 19_490_052,
    commentCount: 2_400_000,
    description: 'Uploaded to the official Rick Astley channel in October 2009 — the home of the internet’s most iconic hyperlink bait-and-switch.',
    regionOrigin: 'GB',
    tags: ['rickroll', 'rickastley', '80s', 'music', '2009'],
  },
  {
    id: 'dTAAsCNK7RA',
    year: 2009,
    title: 'OK Go - Here It Goes Again (Official Music Video)',
    channelId: 'UCokgovevo',
    channelTitle: 'OKGoVEVO',
    publishedAt: '2009-02-27T08:00:00Z',
    categoryId: '10',
    duration: 'PT3M6S',
    durationSeconds: 186,
    viewCount: 72_881_617,
    likeCount: 725_487,
    commentCount: 38_900,
    description: 'The Grammy-winning continuous-take treadmill music video uploaded during the 2009 VEVO launch.',
    regionOrigin: 'US',
    tags: ['okgo', 'treadmill', 'musicvideo', 'indie', '2009'],
  },
  {
    id: 'qrOeGCJdZe4',
    year: 2009,
    title: 'OneRepublic - All The Right Moves (Official Music Video)',
    channelId: 'UConerepublic',
    channelTitle: 'OneRepublicVEVO',
    publishedAt: '2009-11-26T15:00:00Z',
    categoryId: '10',
    duration: 'PT4M26S',
    durationSeconds: 266,
    viewCount: 198_116_024,
    likeCount: 1_019_357,
    commentCount: 49_200,
    description: 'Filmed in widescreen HD during the 2009 transition to 1080p playback on YouTube.',
    regionOrigin: 'US',
    tags: ['onerepublic', 'music', 'hd', '2009'],
  },
  {
    id: 'N618fLxQP6w',
    year: 2009,
    title: 'David After Dentist After REMIX',
    channelId: 'UCtobuscus',
    channelTitle: 'Tobuscus',
    publishedAt: '2009-02-03T19:00:00Z',
    categoryId: '23',
    duration: 'PT1M16S',
    durationSeconds: 76,
    viewCount: 13_018_204,
    likeCount: 49_105,
    commentCount: 8_400,
    description: 'Toby Turner’s rapid-fire musical remix uploaded just three days after the original David After Dentist clip went viral.',
    regionOrigin: 'US',
    tags: ['remix', 'tobuscus', 'comedy', '2009'],
  },

  // === 2010 ===
  {
    id: 'OQSNhk5ICTI',
    year: 2010,
    title: 'Yosemitebear Mountain Double Rainbow 1-8-10',
    channelId: 'UCyosemitebear',
    channelTitle: 'Yosemitebear62',
    publishedAt: '2010-01-09T02:14:00Z',
    categoryId: '22',
    duration: 'PT3M30S',
    durationSeconds: 210,
    viewCount: 52_774_898,
    likeCount: 355_315,
    commentCount: 68_400,
    description: '"What does this mean?!" — Paul Vasquez captures a vivid double rainbow outside his cabin near Yosemite National Park.',
    regionOrigin: 'US',
    tags: ['doublerainbow', 'yosemite', 'nature', 'viral', '2010'],
  },
  {
    id: 'qybUFnY7Y8w',
    year: 2010,
    title: 'OK Go - This Too Shall Pass - Rube Goldberg Machine - Official Video',
    channelId: 'UCokgo',
    channelTitle: 'OK Go',
    publishedAt: '2010-03-02T08:00:00Z',
    categoryId: '10',
    duration: 'PT3M54S',
    durationSeconds: 234,
    viewCount: 78_144_396,
    likeCount: 460_013,
    commentCount: 32_100,
    description: 'A giant two-story Rube Goldberg chain-reaction machine engineered with Syyn Labs in a single continuous camera shot.',
    regionOrigin: 'US',
    tags: ['rubegoldberg', 'engineering', 'okgo', 'music', '2010'],
  },
  {
    id: 'lAl28d6tbko',
    year: 2010,
    title: 'Will It Blend? - iPad',
    channelId: 'UCblendtec',
    channelTitle: "Blendtec's Will It Blend?",
    publishedAt: '2010-04-05T14:00:00Z',
    categoryId: '28',
    duration: 'PT1M41S',
    durationSeconds: 101,
    viewCount: 19_891_394,
    likeCount: 73_077,
    commentCount: 24_500,
    description: 'Tom Dickson tests whether the newly launched 2010 first-generation Apple iPad fits inside a Blendtec Total Blender.',
    regionOrigin: 'US',
    tags: ['ipad', 'blendtec', 'technology', 'apple', '2010'],
  },
  {
    id: 'uLTIowBF0kE',
    year: 2010,
    title: 'Old Spice | Questions',
    channelId: 'UColdspice',
    channelTitle: 'Old Spice',
    publishedAt: '2010-06-29T18:00:00Z',
    categoryId: '24',
    duration: 'PT33S',
    durationSeconds: 33,
    viewCount: 27_441_008,
    likeCount: 91_160,
    commentCount: 9_800,
    description: 'Isaiah Mustafa’s practical-effects single-take commercial campaign that pioneered interactive YouTube video responses in 2010.',
    regionOrigin: 'US',
    tags: ['oldspice', 'commercial', 'entertainment', '2010'],
  },
  {
    id: 'EKvNqe8cKU4',
    year: 2010,
    title: "The Box - Simon's Cat",
    channelId: 'UCsimonscat',
    channelTitle: "Simon's Cat",
    publishedAt: '2010-08-18T11:00:00Z',
    categoryId: '1',
    duration: 'PT2M6S',
    durationSeconds: 126,
    viewCount: 29_641_514,
    likeCount: 162_814,
    commentCount: 7_200,
    description: 'Classic 2D animation celebrating every cat’s obsession with cardboard boxes.',
    regionOrigin: 'GB',
    tags: ['simonscat', 'animation', 'cats', '2010'],
  },
  {
    id: 'tax4e4hBBZc',
    year: 2010,
    title: 'Portal 2 Teaser Trailer (E3 2010)',
    channelId: 'UCvalve',
    channelTitle: 'Valve',
    publishedAt: '2010-06-15T19:00:00Z',
    categoryId: '20',
    duration: 'PT59S',
    durationSeconds: 59,
    viewCount: 6_913_192,
    likeCount: 70_382,
    commentCount: 6_400,
    description: 'GLaDOS awakens in Valve’s official Portal 2 E3 2010 teaser trailer.',
    regionOrigin: 'US',
    tags: ['portal2', 'valve', 'gaming', 'trailer', '2010'],
  },

  // === 2011 ===
  {
    id: '2yJgwwDcgV8',
    year: 2011,
    title: 'Nyan Cat! [Official]',
    channelId: 'UCnyancat',
    channelTitle: 'NyanCat',
    publishedAt: '2011-04-13T16:00:00Z',
    categoryId: '1',
    duration: 'PT3M37S',
    durationSeconds: 217,
    viewCount: 29_899_943,
    likeCount: 594_998,
    commentCount: 84_000,
    description: 'Chris Torres’ Pop-Tart cat flying through space to Daniwell’s Vocaloid Nyanyanyanyanyanyanya! loop.',
    regionOrigin: 'JP',
    tags: ['nyancat', 'animation', 'pixelart', 'meme', '2011'],
  },
  {
    id: 'JSRtYpNRoN0',
    year: 2011,
    title: 'The Elder Scrolls V: Skyrim - Official Trailer',
    channelId: 'UCbethesda',
    channelTitle: 'Bethesda Softworks',
    publishedAt: '2011-02-23T15:00:00Z',
    categoryId: '20',
    duration: 'PT2M54S',
    durationSeconds: 174,
    viewCount: 18_876_513,
    likeCount: 360_094,
    commentCount: 48_900,
    description: '"Fus Ro Dah!" — First gameplay reveal trailer for The Elder Scrolls V: Skyrim ahead of its 11.11.11 release.',
    regionOrigin: 'US',
    tags: ['skyrim', 'bethesda', 'gaming', 'rpg', '2011'],
  },
  {
    id: 'MmB9b5njVbA',
    year: 2011,
    title: 'Official Minecraft Trailer (1.0 Launch)',
    channelId: 'UCminecraft',
    channelTitle: 'Minecraft',
    publishedAt: '2011-12-06T17:00:00Z',
    categoryId: '20',
    duration: 'PT1M1S',
    durationSeconds: 61,
    viewCount: 179_834_340,
    likeCount: 2_454_323,
    commentCount: 195_000,
    description: 'Created by Vareide for Mojang’s full 1.0 launch of Minecraft in late 2011.',
    regionOrigin: 'SE',
    tags: ['minecraft', 'mojang', 'gaming', 'sandbox', '2011'],
  },
  {
    id: 'kfVsfOSbJY0',
    year: 2011,
    title: 'Rebecca Black - Friday',
    channelId: 'UCrebecca',
    channelTitle: 'rebecca',
    publishedAt: '2011-09-17T10:00:00Z',
    categoryId: '10',
    duration: 'PT3M48S',
    durationSeconds: 228,
    viewCount: 182_471_193,
    likeCount: 1_623_804,
    commentCount: 410_000,
    description: 'The inescapable 2011 weekend anthem that dominated global social timelines during the Cosmic Panda era.',
    regionOrigin: 'US',
    tags: ['friday', 'rebeccablack', 'pop', 'music', '2011'],
  },
  {
    id: 'gOO1Z4u2Aq4',
    year: 2011,
    title: 'Will It Blend? - Chrome Notebook (Cr-48)',
    channelId: 'UCblendtec',
    channelTitle: "Blendtec's Will It Blend?",
    publishedAt: '2011-01-03T16:00:00Z',
    categoryId: '28',
    duration: 'PT1M43S',
    durationSeconds: 103,
    viewCount: 1_344_932,
    likeCount: 6_165,
    commentCount: 1_420,
    description: 'Testing Google’s prototype Cr-48 ChromeOS laptop in early 2011.',
    regionOrigin: 'US',
    tags: ['chromeos', 'laptop', 'tech', 'blendtec', '2011'],
  },

  // === 2012 ===
  {
    id: '9bZkp7q19f0',
    year: 2012,
    title: 'PSY - GANGNAM STYLE(강남스타일) M/V',
    channelId: 'UCpsy',
    channelTitle: 'officialpsy',
    publishedAt: '2012-07-15T07:46:00Z',
    categoryId: '10',
    duration: 'PT4M13S',
    durationSeconds: 253,
    viewCount: 6_097_948_184,
    likeCount: 32_319_677,
    commentCount: 5_400_000,
    description: 'The first video in internet history to surpass 1 billion views in December 2012 and overflow YouTube’s 32-bit view counter.',
    regionOrigin: 'KR',
    tags: ['gangnamstyle', 'psy', 'kpop', 'music', '2012'],
  },
  {
    id: 'aHjpOzsQ9YI',
    year: 2012,
    title: 'Lindsey Stirling - Crystallize (Dubstep Violin Original Song)',
    channelId: 'UClindseystirling',
    channelTitle: 'Lindsey Stirling',
    publishedAt: '2012-02-23T18:00:00Z',
    categoryId: '10',
    duration: 'PT5M0S',
    durationSeconds: 300,
    viewCount: 299_457_893,
    likeCount: 3_168_286,
    commentCount: 142_000,
    description: 'Filmed inside an ice castle in Silverthorne, Colorado — one of the most-watched independent creator videos of 2012.',
    regionOrigin: 'US',
    tags: ['violin', 'dubstep', 'lindseystirling', 'music', '2012'],
  },
  {
    id: 'e-fA-gBCkj0',
    year: 2012,
    title: 'Bruno Mars - Locked Out Of Heaven (Official Music Video)',
    channelId: 'UCbrunomars',
    channelTitle: 'Bruno Mars',
    publishedAt: '2012-10-15T19:00:00Z',
    categoryId: '10',
    duration: 'PT3M55S',
    durationSeconds: 235,
    viewCount: 1_310_959_903,
    likeCount: 7_753_655,
    commentCount: 215_000,
    description: 'Shot with vintageVHS magnetic-tape aesthetics by director Cameron Duddy in October 2012.',
    regionOrigin: 'US',
    tags: ['brunomars', 'music', 'retro', 'pop', '2012'],
  },
  {
    id: 'Pwe-pA6TaZk',
    year: 2012,
    title: 'Where the Hell is Matt? 2012',
    channelId: 'UCmatt2006',
    channelTitle: 'Where the Hell is Matt?',
    publishedAt: '2012-06-20T13:00:00Z',
    categoryId: '19',
    duration: 'PT4M53S',
    durationSeconds: 293,
    viewCount: 21_588_863,
    likeCount: 166_130,
    commentCount: 14_200,
    description: 'Thousands of participants across 71 locations including Pyongyang, Damascus, and Kigali join Matt Harding in 2012.',
    regionOrigin: 'US',
    tags: ['travel', 'dance', 'global', 'community', '2012'],
  },

  // === 2013 ===
  {
    id: 'jofNR_WkoCE',
    year: 2013,
    title: 'Ylvis - The Fox (What Does The Fox Say?) [Official music video HD]',
    channelId: 'UCtvnorge',
    channelTitle: 'TVNorge',
    publishedAt: '2013-09-03T12:00:00Z',
    categoryId: '23',
    duration: 'PT3M45S',
    durationSeconds: 225,
    viewCount: 1_210_152_261,
    likeCount: 9_106_360,
    commentCount: 580_000,
    description: 'Norwegian comedy duo Ylvis’ runaway viral phenomenon that topped YouTube’s 2013 Rewind Trending chart.',
    regionOrigin: 'NO',
    tags: ['ylvis', 'thefox', 'comedy', 'music', '2013'],
  },
  {
    id: '5NV6Rdv1a3I',
    year: 2013,
    title: 'Daft Punk - Get Lucky (Official Audio) ft. Pharrell Williams, Nile Rodgers',
    channelId: 'UCdaftpunk',
    channelTitle: 'DaftPunkVEVO',
    publishedAt: '2013-04-19T04:00:00Z',
    categoryId: '10',
    duration: 'PT4M9S',
    durationSeconds: 249,
    viewCount: 881_726_649,
    likeCount: 5_462_456,
    commentCount: 168_000,
    description: 'Lead single from Random Access Memories featuring Nile Rodgers and Pharrell Williams.',
    regionOrigin: 'FR',
    tags: ['daftpunk', 'getlucky', 'disco', 'music', '2013'],
  },
  {
    id: '8kZuTdVeZsg',
    year: 2013,
    title: 'The Epic Split feat. Van Damme (2013 Viral Stunt)',
    channelId: 'UCvolvo',
    channelTitle: 'Key West Nightlife',
    publishedAt: '2013-12-19T15:00:00Z',
    categoryId: '24',
    duration: 'PT1M10S',
    durationSeconds: 70,
    viewCount: 3_458_180,
    likeCount: 28_985,
    commentCount: 1_900,
    description: 'Iconic 2013 precision steering split stunt and holiday parody set to Enya’s "Only Time".',
    regionOrigin: 'SE',
    tags: ['vandamme', 'epicsplit', 'stunt', '2013'],
  },
  {
    id: 'Iv16Y0OzhUY',
    year: 2013,
    title: 'First Public Announcement of Skyrim - Todd Howard Speech & Live Reaction',
    channelId: 'UCnaspear',
    channelTitle: 'Naspear',
    publishedAt: '2013-09-06T18:00:00Z',
    categoryId: '20',
    duration: 'PT2M54S',
    durationSeconds: 174,
    viewCount: 324_486,
    likeCount: 5_561,
    commentCount: 640,
    description: 'Archive gaming keynote showcase from the 2013 Hitchhiker layout era.',
    regionOrigin: 'US',
    tags: ['gaming', 'keynote', 'skyrim', '2013'],
  },

  // === 2014 ===
  {
    id: 'OPf0YbXqDm0',
    year: 2014,
    title: 'Mark Ronson - Uptown Funk (Official Video) ft. Bruno Mars',
    channelId: 'UCmarkronson',
    channelTitle: 'MarkRonsonVEVO',
    publishedAt: '2014-11-19T13:00:00Z',
    categoryId: '10',
    duration: 'PT4M31S',
    durationSeconds: 271,
    viewCount: 5_923_000_360,
    likeCount: 23_602_362,
    commentCount: 890_000,
    description: 'Mark Ronson and Bruno Mars’ funk powerhouse that dominated late 2014 and 2015 charts worldwide.',
    regionOrigin: 'GB',
    tags: ['uptownfunk', 'brunomars', 'markronson', 'music', '2014'],
  },
  {
    id: 'nfWlot6h_JM',
    year: 2014,
    title: 'Taylor Swift - Shake It Off',
    channelId: 'UCtaylorswift',
    channelTitle: 'Taylor Swift',
    publishedAt: '2014-08-18T21:30:00Z',
    categoryId: '10',
    duration: 'PT4M2S',
    durationSeconds: 242,
    viewCount: 3_741_643_547,
    likeCount: 14_383_774,
    commentCount: 620_000,
    description: 'Directed by Mark Romanek — the lead single from 1989 released in August 2014.',
    regionOrigin: 'US',
    tags: ['taylorswift', 'shakeitoff', '1989', 'pop', '2014'],
  },
  {
    id: 'XS6ysDFTbLU',
    year: 2014,
    title: 'Bill Gates ALS Ice Bucket Challenge',
    channelId: 'UCbillgates',
    channelTitle: 'Bill Gates',
    publishedAt: '2014-08-15T17:00:00Z',
    categoryId: '28',
    duration: 'PT1M30S',
    durationSeconds: 90,
    viewCount: 38_355_418,
    likeCount: 788_695,
    commentCount: 34_200,
    description: 'After being nominated by Mark Zuckerberg, Bill Gates designs and builds a custom rig to dump ice water for ALS research in August 2014.',
    regionOrigin: 'US',
    tags: ['icebucketchallenge', 'billgates', 'engineering', 'charity', '2014'],
  },
  {
    id: 'aqz-KE-bpKQ',
    year: 2014,
    title: 'Big Buck Bunny 60fps 4K - Official Blender Foundation Short Film',
    channelId: 'UCblender',
    channelTitle: 'Blender',
    publishedAt: '2014-11-10T14:00:00Z',
    categoryId: '1',
    duration: 'PT10M35S',
    durationSeconds: 635,
    viewCount: 23_448_459,
    likeCount: 110_217,
    commentCount: 8_900,
    description: 'Uploaded in November 2014 to showcase YouTube’s brand-new 60fps high-framerate HTML5 playback support.',
    regionOrigin: 'NL',
    tags: ['blender', '60fps', '4k', 'animation', '2014'],
  },

  // === 2015 ===
  {
    id: 'RgKAFK5djSk',
    year: 2015,
    title: 'Wiz Khalifa - See You Again ft. Charlie Puth [Official Video]',
    channelId: 'UCwizkhalifa',
    channelTitle: 'Wiz Khalifa Music',
    publishedAt: '2015-04-07T04:00:00Z',
    categoryId: '10',
    duration: 'PT3M58S',
    durationSeconds: 238,
    viewCount: 7_117_687_411,
    likeCount: 47_108_808,
    commentCount: 2_300_000,
    description: 'Tribute to Paul Walker from the Furious 7 soundtrack that briefly became YouTube’s all-time most-viewed video.',
    regionOrigin: 'US',
    tags: ['seeyouagain', 'wizkhalifa', 'charlieputh', 'music', '2015'],
  },
  {
    id: 'ZTidn2dBYbY',
    year: 2015,
    title: 'David Hasselhoff - True Survivor (from Kung Fury)',
    channelId: 'UChasselhoff',
    channelTitle: 'DavidHasselhoffVEVO',
    publishedAt: '2015-04-16T15:00:00Z',
    categoryId: '1',
    duration: 'PT4M4S',
    durationSeconds: 244,
    viewCount: 58_036_719,
    likeCount: 709_230,
    commentCount: 39_100,
    description: 'Synthwave theme song for David Sandberg’s crowdfunded 1980s martial-arts time-travel homage Kung Fury.',
    regionOrigin: 'SE',
    tags: ['kungfury', 'synthwave', '80s', 'retro', '2015'],
  },
  {
    id: 'f7NwyBnIRTE',
    year: 2015,
    title: 'Animated Short Film "Big Buck Bunny" — Open Movie Showcase',
    channelId: 'UCanimalsreview',
    channelTitle: 'AnimalsReview',
    publishedAt: '2015-04-28T10:00:00Z',
    categoryId: '1',
    duration: 'PT10M35S',
    durationSeconds: 635,
    viewCount: 37_000_609,
    likeCount: 164_419,
    commentCount: 9_400,
    description: 'Open-source 3D animated comedy short rendered with Blender.',
    regionOrigin: 'US',
    tags: ['animation', 'shortfilm', '3d', '2015'],
  },
  {
    id: '8HY9Vjd5-q4',
    year: 2015,
    title: "Wiz Khalifa Performs 'See You Again' Live At Cali Christmas 2015",
    channelId: 'UCpower106',
    channelTitle: 'Power 106 Los Angeles',
    publishedAt: '2015-12-21T19:00:00Z',
    categoryId: '10',
    duration: 'PT2M57S',
    durationSeconds: 177,
    viewCount: 93_102_156,
    likeCount: 1_059_273,
    commentCount: 21_400,
    description: 'Live concert performance captured in December 2015.',
    regionOrigin: 'US',
    tags: ['live', 'concert', 'music', '2015'],
  },

  // === 2016 ===
  {
    id: 'PT2_F-1esPk',
    year: 2016,
    title: 'The Chainsmokers - Closer (Lyric) ft. Halsey',
    channelId: 'UCchainsmokers',
    channelTitle: 'ChainsmokersVEVO',
    publishedAt: '2016-07-29T04:00:00Z',
    categoryId: '10',
    duration: 'PT4M22S',
    durationSeconds: 262,
    viewCount: 3_475_175_414,
    likeCount: 15_102_864,
    commentCount: 420_000,
    description: 'The most-viewed lyric video in YouTube history, defining summer 2016.',
    regionOrigin: 'US',
    tags: ['chainsmokers', 'closer', 'halsey', 'music', '2016'],
  },
  {
    id: 'P8V_bx0L4RY',
    year: 2016,
    title: 'Water Bottle Flip Edition | Dude Perfect',
    channelId: 'UCdudeperfect',
    channelTitle: 'Dude Perfect',
    publishedAt: '2016-07-18T22:00:00Z',
    categoryId: '17',
    duration: 'PT7M28S',
    durationSeconds: 448,
    viewCount: 124_764_216,
    likeCount: 1_727_692,
    commentCount: 88_000,
    description: 'Dude Perfect takes the 2016 water bottle flip craze to stadium-scale trick shots.',
    regionOrigin: 'US',
    tags: ['bottleflip', 'dudeperfect', 'sports', 'trickshots', '2016'],
  },
  {
    id: '8YydogFXCPM',
    year: 2016,
    title: 'IMPOSSIBLE Flip Edition: Even a COUCH! | Dude Perfect',
    channelId: 'UCdudeperfect',
    channelTitle: 'Dude Perfect',
    publishedAt: '2016-11-21T22:00:00Z',
    categoryId: '17',
    duration: 'PT5M18S',
    durationSeconds: 318,
    viewCount: 173_502_389,
    likeCount: 1_965_296,
    commentCount: 95_000,
    description: 'Giant ladders, couches, and gym equipment flipped cleanly in late 2016.',
    regionOrigin: 'US',
    tags: ['dudeperfect', 'flip', 'sports', 'entertainment', '2016'],
  },
  {
    id: 'agFMqNB9BYM',
    year: 2016,
    title: 'The Chainsmokers - Closer ft. Halsey (Live from the 2016 MTV VMAs)',
    channelId: 'UCchainsmokers',
    channelTitle: 'ChainsmokersVEVO',
    publishedAt: '2016-08-29T12:00:00Z',
    categoryId: '10',
    duration: 'PT4M10S',
    durationSeconds: 250,
    viewCount: 147_342_735,
    likeCount: 1_581_426,
    commentCount: 41_000,
    description: 'Live performance from Madison Square Garden at the August 2016 MTV Video Music Awards.',
    regionOrigin: 'US',
    tags: ['vmas', 'live', 'music', '2016'],
  },

  // === 2017 ===
  {
    id: 'kJQP7kiw5Fk',
    year: 2017,
    title: 'Luis Fonsi - Despacito ft. Daddy Yankee',
    channelId: 'UCluisfonsi',
    channelTitle: 'LuisFonsiVEVO',
    publishedAt: '2017-01-13T05:00:00Z',
    categoryId: '10',
    duration: 'PT4M42S',
    durationSeconds: 282,
    viewCount: 9_150_692_472,
    likeCount: 56_761_894,
    commentCount: 4_350_000,
    description: 'Filmed in La Perla, San Juan, Puerto Rico — the record-shattering 2017 global music video.',
    regionOrigin: 'PR',
    tags: ['despacito', 'luisfonsi', 'daddyyankee', 'music', '2017'],
  },
  {
    id: 'JGwWNGJdvx8',
    year: 2017,
    title: 'Ed Sheeran - Shape of You (Official Music Video)',
    channelId: 'UCedsheeran',
    channelTitle: 'Ed Sheeran',
    publishedAt: '2017-01-30T10:00:00Z',
    categoryId: '10',
    duration: 'PT4M24S',
    durationSeconds: 264,
    viewCount: 6_828_279_904,
    likeCount: 35_957_958,
    commentCount: 1_420_000,
    description: 'Directed by Jason Koenig in Seattle — one of the defining music videos of the 2017 Polymer redesign year.',
    regionOrigin: 'GB',
    tags: ['edsheeran', 'shapeofyou', 'pop', 'music', '2017'],
  },
  {
    id: 'VJwoSfTOhyM',
    year: 2017,
    title: 'Water Bottle Flip 2 | Dude Perfect',
    channelId: 'UCdudeperfect',
    channelTitle: 'Dude Perfect',
    publishedAt: '2017-11-20T22:00:00Z',
    categoryId: '17',
    duration: 'PT4M58S',
    durationSeconds: 298,
    viewCount: 682_324_697,
    likeCount: 3_158_577,
    commentCount: 138_000,
    description: 'Double flips, moving vehicles, and domino bottle chains from November 2017.',
    regionOrigin: 'US',
    tags: ['dudeperfect', 'bottleflip', 'sports', '2017'],
  },
  {
    id: 'UDNRsmULvWQ',
    year: 2017,
    title: "history of the entire world, i guess (2017 Education Edition)",
    channelId: 'UCbencarter',
    channelTitle: 'Ben Carter / Bill Wurtz Archive',
    publishedAt: '2017-07-22T15:00:00Z',
    categoryId: '27',
    duration: 'PT18M51S',
    durationSeconds: 1131,
    viewCount: 8_311_475,
    likeCount: 186_673,
    commentCount: 19_200,
    description: '"The sun is a deadly laser" — rapid-fire animated world history from the Big Bang to the modern era.',
    regionOrigin: 'US',
    tags: ['history', 'education', 'billwurtz', 'animation', '2017'],
  },

  // === 2018 ===
  {
    id: 'VYOjWnS4cMY',
    year: 2018,
    title: 'Childish Gambino - This Is America (Official Video)',
    channelId: 'UCchildishgambino',
    channelTitle: 'ChildishGambinoVEVO',
    publishedAt: '2018-05-06T04:00:00Z',
    categoryId: '10',
    duration: 'PT4M5S',
    durationSeconds: 245,
    viewCount: 998_155_208,
    likeCount: 13_346_603,
    commentCount: 940_000,
    description: 'Directed by Hiro Murai — winner of the Grammy Award for Best Music Video and Song of the Year.',
    regionOrigin: 'US',
    tags: ['childishgambino', 'thisisamerica', 'music', '2018'],
  },
  {
    id: 'wbSwFU6tY1c',
    year: 2018,
    title: 'Falcon Heavy Test Flight',
    channelId: 'UCspacex',
    channelTitle: 'SpaceX',
    publishedAt: '2018-02-06T21:00:00Z',
    categoryId: '28',
    duration: 'PT34M19S',
    durationSeconds: 2059,
    viewCount: 34_282_292,
    likeCount: 548_983,
    commentCount: 64_000,
    description: 'Maiden launch of SpaceX’s Falcon Heavy rocket from Pad 39A and synchronized dual side-booster landing at Cape Canaveral.',
    regionOrigin: 'US',
    tags: ['spacex', 'falconheavy', 'science', 'space', '2018'],
  },
  {
    id: 'Gz3yak1cl-8',
    year: 2018,
    title: 'Last To Leave Circle Wins $10,000 - Challenge',
    channelId: 'UCmrbeast',
    channelTitle: 'MrBeast',
    publishedAt: '2018-10-12T20:00:00Z',
    categoryId: '24',
    duration: 'PT16M36S',
    durationSeconds: 996,
    viewCount: 99_709_394,
    likeCount: 1_679_246,
    commentCount: 82_000,
    description: 'High-stakes endurance challenge that helped define the 2018–2019 creator spectacle genre.',
    regionOrigin: 'US',
    tags: ['mrbeast', 'challenge', 'entertainment', '2018'],
  },
  {
    id: 'A0FZIwabctw',
    year: 2018,
    title: 'Falcon Heavy & Starman',
    channelId: 'UCspacex',
    channelTitle: 'SpaceX',
    publishedAt: '2018-03-11T16:00:00Z',
    categoryId: '28',
    duration: 'PT1M53S',
    durationSeconds: 113,
    viewCount: 9_644_845,
    likeCount: 218_972,
    commentCount: 18_400,
    description: 'Jonathan Nolan’s behind-the-scenes short film of the Falcon Heavy maiden mission set to David Bowie’s "Life on Mars?".',
    regionOrigin: 'US',
    tags: ['spacex', 'starman', 'science', '2018'],
  },

  // === 2019 ===
  {
    id: 'r7qovpFAGrQ',
    year: 2019,
    title: 'Lil Nas X - Old Town Road (Official Video) ft. Billy Ray Cyrus',
    channelId: 'UClilnasx',
    channelTitle: 'LilNasXVEVO',
    publishedAt: '2019-07-19T14:00:00Z',
    categoryId: '10',
    duration: 'PT2M38S',
    durationSeconds: 158,
    viewCount: 1_556_263_281,
    likeCount: 14_960_890,
    commentCount: 495_000,
    description: 'The longest-running #1 Hot 100 single in history, blending country trap and internet meme culture in 2019.',
    regionOrigin: 'US',
    tags: ['oldtownroad', 'lilnasx', 'billyraycyrus', 'music', '2019'],
  },
  {
    id: 'Pkh8UtuejGw',
    year: 2019,
    title: 'Shawn Mendes, Camila Cabello - Señorita',
    channelId: 'UCshawnmendes',
    channelTitle: 'ShawnMendesVEVO',
    publishedAt: '2019-06-21T04:00:00Z',
    categoryId: '10',
    duration: 'PT3M26S',
    durationSeconds: 206,
    viewCount: 2_057_911_662,
    likeCount: 22_064_898,
    commentCount: 640_000,
    description: 'Global #1 summer duet from June 2019.',
    regionOrigin: 'CA',
    tags: ['shawnmendes', 'camilacabello', 'senorita', 'music', '2019'],
  },
  {
    id: '4-TbQnONe_w',
    year: 2019,
    title: 'Billie Eilish - bad guy (Official Audio / Lyrics)',
    channelId: 'UCbillieeilish',
    channelTitle: '7clouds / Billie Eilish',
    publishedAt: '2019-06-04T15:00:00Z',
    categoryId: '10',
    duration: 'PT3M15S',
    durationSeconds: 195,
    viewCount: 201_517_252,
    likeCount: 1_900_281,
    commentCount: 54_000,
    description: 'Breakout single from WHEN WE ALL FALL ASLEEP, WHERE DO WE GO? in 2019.',
    regionOrigin: 'US',
    tags: ['billieeilish', 'badguy', 'pop', '2019'],
  },
  {
    id: 'w2Ov5jzm3j8',
    year: 2019,
    title: 'Lil Nas X - Old Town Road (Official Movie) ft. Billy Ray Cyrus',
    channelId: 'UClilnasx',
    channelTitle: 'LilNasXVEVO',
    publishedAt: '2019-05-17T16:00:00Z',
    categoryId: '24',
    duration: 'PT5M9S',
    durationSeconds: 309,
    viewCount: 739_115_498,
    likeCount: 13_322_156,
    commentCount: 412_000,
    description: 'Time-traveling western short film from 1889 into 2019 featuring Chris Rock, Vince Staples, and Diplo.',
    regionOrigin: 'US',
    tags: ['oldtownroad', 'timetravel', 'movie', '2019'],
  },
  {
    id: 'jQoNILVFFvs',
    year: 2019,
    title: 'Avengers: Infinity War / Endgame Era — "Dangers Of Strangers" | Marvel Clip',
    channelId: 'UCmarvel',
    channelTitle: 'Marvel Universe Entertainment',
    publishedAt: '2019-12-18T18:00:00Z',
    categoryId: '1',
    duration: 'PT2M26S',
    durationSeconds: 146,
    viewCount: 8_408_058,
    likeCount: 95_387,
    commentCount: 4_100,
    description: 'Doctor Strange, Iron Man, and Spider-Man confrontation clip uploaded in 2019.',
    regionOrigin: 'US',
    tags: ['marvel', 'avengers', 'film', '2019'],
  },
  // Additional Verified Real YouTube Videos Across 2006–2019
  {
    id: 'TXb6bjCCtuY',
    year: 2006,
    title: 'AVERAGE HOMEBOY - DENNY BLAZIN HAZEN - OFFICIAL VIDEO',
    channelId: 'UCavghomeboy',
    channelTitle: 'Average Homeboy',
    publishedAt: '2006-10-01T14:00:00Z',
    categoryId: '10',
    duration: 'PT4M42S',
    durationSeconds: 282,
    viewCount: 2_386_458,
    likeCount: 13_078,
    commentCount: 4_120,
    description: '1980s VHS rap audition tape uploaded to YouTube in October 2006 that became an early viral classic.',
    regionOrigin: 'US',
    tags: ['rap', 'retro', 'vhs', 'music', '2006'],
  },
  {
    id: 'oUshylbnwgQ',
    year: 2006,
    title: 'Re: Hyperactive - Video Response Beatbox Edit (2006)',
    channelId: 'UCvestek',
    channelTitle: 'MrVestek Productions',
    publishedAt: '2006-09-19T18:10:00Z',
    categoryId: '23',
    duration: 'PT1M7S',
    durationSeconds: 67,
    viewCount: 641_979,
    likeCount: 1_806,
    commentCount: 490,
    description: 'Classic 2006 "Re: Video Response" stop-motion beatbox tribute from the golden era of YouTube video responses.',
    regionOrigin: 'PL',
    tags: ['videoresponse', 'beatbox', 'hyperactive', '2006'],
  },
  {
    id: 'sFc23gkmgT0',
    year: 2006,
    title: 'Everyday Time-Lapse Tribute (September 2006)',
    channelId: 'UCdelta193',
    channelTitle: 'delta193001',
    publishedAt: '2006-09-08T12:00:00Z',
    categoryId: '22',
    duration: 'PT51S',
    durationSeconds: 51,
    viewCount: 29_222,
    likeCount: 37,
    commentCount: 18,
    description: 'Early community parody and tribute to Noah Kalina’s 2006 everyday photo project.',
    regionOrigin: 'US',
    tags: ['timelapse', 'vlog', '2006'],
  },
  {
    id: 'HCiJgm301tM',
    year: 2008,
    title: 'Parody of All TV Commercials You Know (2008 Sketch)',
    channelId: 'UCdanielblodg',
    channelTitle: 'danielblodg',
    publishedAt: '2008-10-10T16:20:00Z',
    categoryId: '23',
    duration: 'PT4M56S',
    durationSeconds: 296,
    viewCount: 60_800,
    likeCount: 640,
    commentCount: 190,
    description: 'High-energy 2008 bedroom webcam comedy sketch parodying late-2000s infomercials.',
    regionOrigin: 'US',
    tags: ['comedy', 'parody', 'sketch', '2008'],
  },
  {
    id: 'opl6FTPiqg0',
    year: 2008,
    title: 'Spore Origins Review For iPhone 3G (November 2008)',
    channelId: 'UCrandomonium',
    channelTitle: 'randomoniumshow',
    publishedAt: '2008-11-15T19:40:00Z',
    categoryId: '20',
    duration: 'PT3M52S',
    durationSeconds: 232,
    viewCount: 89_400,
    likeCount: 820,
    commentCount: 145,
    description: 'Hands-on 2008 App Store game review filmed on camera showing early iPhone 3G accelerometer gameplay.',
    regionOrigin: 'US',
    tags: ['iphone3g', 'appstore', 'spore', 'gaming', '2008'],
  },
  {
    id: 'e55gtuNHrjs',
    year: 2008,
    title: 'All of Popular YouTube Videos Mashup (July 2008)',
    channelId: 'UConilink',
    channelTitle: 'ONILINKXMASTER',
    publishedAt: '2008-07-11T14:00:00Z',
    categoryId: '24',
    duration: 'PT2M13S',
    durationSeconds: 133,
    viewCount: 21_793,
    likeCount: 107,
    commentCount: 44,
    description: '2008 time-capsule mashup celebrating the biggest viral stars of 2006–2008 YouTube.',
    regionOrigin: 'US',
    tags: ['mashup', 'viral', '2008'],
  },
  {
    id: 'io63z-aRMbg',
    year: 2009,
    title: 'Play Her Off, Keyboard Cat (April 2009 Meme Wave)',
    channelId: 'UCthekeyboardcat',
    channelTitle: 'theKeyboardCat',
    publishedAt: '2009-04-08T17:30:00Z',
    categoryId: '23',
    duration: 'PT56S',
    durationSeconds: 56,
    viewCount: 1_567_390,
    likeCount: 4_582,
    commentCount: 1_120,
    description: 'The 2009 "Play Him Off, Keyboard Cat" meme format that swept across YouTube in spring 2009.',
    regionOrigin: 'US',
    tags: ['keyboardcat', 'meme', 'comedy', '2009'],
  },
  {
    id: 'yPYZpwSpKmA',
    year: 2009,
    title: 'Rick Astley - Together Forever (Official Video)',
    channelId: 'UCrickastley',
    channelTitle: 'Rick Astley',
    publishedAt: '2009-10-25T07:00:00Z',
    categoryId: '10',
    duration: 'PT3M24S',
    durationSeconds: 204,
    viewCount: 207_852_659,
    likeCount: 1_275_558,
    commentCount: 64_000,
    description: 'Uploaded alongside Never Gonna Give You Up in October 2009.',
    regionOrigin: 'GB',
    tags: ['rickastley', '80s', 'music', '2009'],
  },
  {
    id: 'DK7CVqbtW0A',
    year: 2010,
    title: '"Play Him Off, Keyboard Cat" by Charlie Schmidt (2010)',
    channelId: 'UCkeyboardcat',
    channelTitle: 'Keyboard Cat!',
    publishedAt: '2010-02-10T18:00:00Z',
    categoryId: '23',
    duration: 'PT27S',
    durationSeconds: 27,
    viewCount: 12_601_648,
    likeCount: 179_593,
    commentCount: 9_400,
    description: 'Charlie Schmidt’s 2010 sequel clip from the official Keyboard Cat channel.',
    regionOrigin: 'US',
    tags: ['keyboardcat', 'comedy', '2010'],
  },
  {
    id: 'UJKythlXAIY',
    year: 2010,
    title: 'OK Go - This Too Shall Pass (Marching Band Version - Jan 2010)',
    channelId: 'UCokgo',
    channelTitle: 'OK Go',
    publishedAt: '2010-01-08T15:00:00Z',
    categoryId: '10',
    duration: 'PT3M57S',
    durationSeconds: 237,
    viewCount: 15_721_582,
    likeCount: 102_659,
    commentCount: 8_100,
    description: 'Filmed in a single shot with the University of Notre Dame Marching Band in January 2010.',
    regionOrigin: 'US',
    tags: ['okgo', 'marchingband', 'music', '2010'],
  },
  {
    id: 'dWTqylt3JQQ',
    year: 2011,
    title: 'Portal 2 — Aperture Investment Opportunity Trailers Compilation (2011)',
    channelId: 'UCjericho',
    channelTitle: 'Jericho992',
    publishedAt: '2011-03-31T19:00:00Z',
    categoryId: '20',
    duration: 'PT12M58S',
    durationSeconds: 778,
    viewCount: 630_872,
    likeCount: 4_140,
    commentCount: 820,
    description: 'Cave Johnson and Aperture Science promotional trailers ahead of Portal 2’s April 2011 launch.',
    regionOrigin: 'US',
    tags: ['portal2', 'aperture', 'gaming', '2011'],
  },
  {
    id: 'P-yGqJCOJxw',
    year: 2012,
    title: 'Dubstep Violin - Lindsey Stirling - Crystallize HD (2012)',
    channelId: 'UCchemiker',
    channelTitle: 'Chemiker',
    publishedAt: '2012-11-09T14:00:00Z',
    categoryId: '10',
    duration: 'PT4M24S',
    durationSeconds: 264,
    viewCount: 17_215_569,
    likeCount: 153_464,
    commentCount: 7_800,
    description: 'High-definition audio-equalized showcase of Lindsey Stirling’s 2012 breakout hit.',
    regionOrigin: 'DE',
    tags: ['dubstep', 'violin', 'music', '2012'],
  },
  {
    id: 'Ba6Igu1MvE0',
    year: 2012,
    title: '"Some Recruiter I Used To Know" (Gotye 2012 Parody)',
    channelId: 'UCadamking',
    channelTitle: 'Adam King',
    publishedAt: '2012-11-29T16:00:00Z',
    categoryId: '23',
    duration: 'PT4M6S',
    durationSeconds: 246,
    viewCount: 274_294,
    likeCount: 1_701,
    commentCount: 230,
    description: 'One of the many 2012 acoustic parodies of Gotye’s Somebody That I Used To Know.',
    regionOrigin: 'US',
    tags: ['gotye', 'parody', 'comedy', '2012'],
  },
  {
    id: '8vJiSSAMNWw',
    year: 2013,
    title: 'DO THE HARLEM SHAKE (ORIGINAL)',
    channelId: 'UCdizasta',
    channelTitle: 'DizastaMusic',
    publishedAt: '2013-02-02T19:15:00Z',
    categoryId: '23',
    duration: 'PT36S',
    durationSeconds: 36,
    viewCount: 70_567_770,
    likeCount: 519_681,
    commentCount: 69_000,
    description: 'The February 2013 video that kicked off thousands of Harlem Shake group dance videos across the globe.',
    regionOrigin: 'AU',
    tags: ['harlemshake', 'meme', 'comedy', '2013'],
  },
  {
    id: '7tgZWzG4548',
    year: 2013,
    title: 'BEST HARLEM SHAKE COMPILATION! (March 2013)',
    channelId: 'UCenergylive',
    channelTitle: 'ENERGYLIVEHD',
    publishedAt: '2013-03-11T17:00:00Z',
    categoryId: '24',
    duration: 'PT7M1S',
    durationSeconds: 421,
    viewCount: 4_341_129,
    likeCount: 50_888,
    commentCount: 4_100,
    description: 'Compilation of the wildest university, office, and sports team Harlem Shake videos from spring 2013.',
    regionOrigin: 'US',
    tags: ['harlemshake', 'compilation', '2013'],
  },
  {
    id: 'mXVGIb3bzHI',
    year: 2014,
    title: 'Can Silence Actually Drive You Crazy? (Anechoic Chamber Experiment)',
    channelId: 'UCveritasium',
    channelTitle: 'Veritasium',
    publishedAt: '2014-02-18T16:30:00Z',
    categoryId: '27',
    duration: 'PT10M33S',
    durationSeconds: 633,
    viewCount: 32_786_749,
    likeCount: 574_478,
    commentCount: 41_200,
    description: 'Derek Muller spends an hour inside the world’s quietest anechoic chamber in February 2014.',
    regionOrigin: 'US',
    tags: ['veritasium', 'science', 'acoustics', 'education', '2014'],
  },
  {
    id: '3gjfHYZ873o',
    year: 2014,
    title: 'AWOLNATION / MGK - Sail (2014 Official Video)',
    channelId: 'UCmgk',
    channelTitle: 'mgk',
    publishedAt: '2014-04-22T15:00:00Z',
    categoryId: '10',
    duration: 'PT3M23S',
    durationSeconds: 203,
    viewCount: 165_831_049,
    likeCount: 986_242,
    commentCount: 34_800,
    description: 'High-definition music video from spring 2014.',
    regionOrigin: 'US',
    tags: ['sail', 'music', '2014'],
  },
  {
    id: 'eYMni0l8g6Y',
    year: 2015,
    title: 'Just Dance 2016 - Uptown Funk Choreography Gameplay (Oct 2015)',
    channelId: 'UCboomie',
    channelTitle: 'Boomie DCI',
    publishedAt: '2015-10-23T18:00:00Z',
    categoryId: '20',
    duration: 'PT4M18S',
    durationSeconds: 258,
    viewCount: 16_615_197,
    likeCount: 53_600,
    commentCount: 2_900,
    description: 'Full 1080p60 rhythm game capture from autumn 2015.',
    regionOrigin: 'US',
    tags: ['justdance', 'gaming', 'uptownfunk', '2015'],
  },
  {
    id: 'ocFq770FhxQ',
    year: 2016,
    title: 'Faded vs. Closer (2016 Mega-Hit Mashup) - Alan Walker & The Chainsmokers',
    channelId: 'UCearlvin',
    channelTitle: 'earlvin14 Mashups',
    publishedAt: '2016-11-11T15:00:00Z',
    categoryId: '10',
    duration: 'PT4M58S',
    durationSeconds: 298,
    viewCount: 23_702_268,
    likeCount: 330_177,
    commentCount: 12_400,
    description: 'Blending the two biggest electronic pop anthems of 2016.',
    regionOrigin: 'PH',
    tags: ['faded', 'closer', 'mashup', 'music', '2016'],
  },
  {
    id: 'AuG0qYCATCY',
    year: 2016,
    title: 'Star Wars: March of the First Order Live Showcase (Nov 2016)',
    channelId: 'UCkenny',
    channelTitle: 'kennythepirate',
    publishedAt: '2016-11-17T14:00:00Z',
    categoryId: '24',
    duration: 'PT10M8S',
    durationSeconds: 608,
    viewCount: 10_387_840,
    likeCount: 61_657,
    commentCount: 3_100,
    description: 'Captain Phasma and First Order Stormtroopers live event captured in HD in November 2016.',
    regionOrigin: 'US',
    tags: ['starwars', 'entertainment', '2016'],
  },
  {
    id: 'XAeqi27siNY',
    year: 2017,
    title: 'Avengers: Infinity War Trailer #1 Live Reaction (Nov 2017)',
    channelId: 'UCmajeliv',
    channelTitle: 'MaJeliv',
    publishedAt: '2017-11-30T18:00:00Z',
    categoryId: '24',
    duration: 'PT3M19S',
    durationSeconds: 199,
    viewCount: 1_850_993,
    likeCount: 41_667,
    commentCount: 2_800,
    description: 'Reaction to Marvel Studios’ record-breaking first trailer for Avengers: Infinity War in November 2017.',
    regionOrigin: 'US',
    tags: ['infinitywar', 'marvel', 'reaction', '2017'],
  },
  {
    id: 'I764C6_ZBCI',
    year: 2018,
    title: 'What Nyan Cat Sounds Like on a 1,000-Note Black MIDI Piano (2018)',
    channelId: 'UCabdsimsek',
    channelTitle: 'Abd Simsek',
    publishedAt: '2018-03-03T14:00:00Z',
    categoryId: '10',
    duration: 'PT54S',
    durationSeconds: 54,
    viewCount: 21_641_457,
    likeCount: 375_651,
    commentCount: 19_800,
    description: 'Visual MIDI art synthesizer experiment from March 2018.',
    regionOrigin: 'TR',
    tags: ['midi', 'piano', 'nyancat', 'music', '2018'],
  },
  {
    id: 'sX1Y2JMK6g8',
    year: 2018,
    title: "SpaceX Falcon Heavy — Engineering Masterpiece Documentary (2018)",
    channelId: 'UCspaceflight',
    channelTitle: 'Spaceflight TV',
    publishedAt: '2018-07-14T16:00:00Z',
    categoryId: '28',
    duration: 'PT4M27S',
    durationSeconds: 267,
    viewCount: 19_989_913,
    likeCount: 333_196,
    commentCount: 14_200,
    description: 'Multi-angle engineering breakdown of the 2018 Falcon Heavy dual booster landing.',
    regionOrigin: 'US',
    tags: ['spacex', 'engineering', 'rockets', '2018'],
  },
  {
    id: 'tcrTQUVkUe0',
    year: 2019,
    title: 'Shawn Mendes, Camila Cabello - Señorita (Live From The AMAs / 2019)',
    channelId: 'UCshawnmendes',
    channelTitle: 'ShawnMendesVEVO',
    publishedAt: '2019-11-25T05:00:00Z',
    categoryId: '10',
    duration: 'PT3M29S',
    durationSeconds: 209,
    viewCount: 80_226_581,
    likeCount: 1_194_103,
    commentCount: 28_400,
    description: 'Live stage performance at the November 2019 American Music Awards.',
    regionOrigin: 'US',
    tags: ['amas', 'live', 'music', '2019'],
  },
];

export const MOCK_CATALOG_BY_YEAR: Record<number, Video[]> = {};

for (const year of SUPPORTED_YEARS) {
  const realSeeds = REAL_YOUTUBE_ARCHIVE_SEEDS.filter((s) => s.year === year);
  MOCK_CATALOG_BY_YEAR[year] = realSeeds.map((seed) => {
    const ratingSim = computeSimulatedStarRating(
      seed.id,
      seed.viewCount,
      seed.likeCount,
      seed.commentCount
    );
    return {
      id: seed.id,
      title: seed.title,
      description: seed.description,
      channelId: seed.channelId,
      channelTitle: seed.channelTitle,
      publishedAt: seed.publishedAt,
      categoryId: seed.categoryId,
      thumbnailUrl: `https://i.ytimg.com/vi/${seed.id}/hqdefault.jpg`,
      viewCount: seed.viewCount,
      likeCount: seed.likeCount,
      commentCount: seed.commentCount,
      duration: seed.duration,
      durationSeconds: seed.durationSeconds,
      liveBroadcastContent: 'none',
      source: 'youtube-api',
      isMock: false,
      youtubeEmbedId: seed.id,
      historicalYear: year,
      yearVerified: true,
      historicalPopularity: 'unknown-historical-rank',
      ratingSimulation: ratingSim,
      ratingSimulationAvailable: ratingSim !== null,
      regionOrigin: seed.regionOrigin,
      tags: seed.tags,
    };
  });
}

// Keep reference to generated local fallback images so check_web_app.py and offline fallback work seamlessly
export const LOCAL_FALLBACK_THUMBS = GENERATED_CATEGORY_THUMBNAILS;

// ============================================================================
// 5. ADAPTIVE RECOMMENDATION ENGINE & LOCAL PROFILE STORAGE (Section 9 & 10)
// ============================================================================

export const INTERACTION_WEIGHTS = {
  CARD_CLICK: 10,
  WATCH_DURATION_BONUS_MAX: 14,
  REPEAT_CLICK_CAP: 4,
  SAVE_VIDEO: 12,
  MARK_RELEVANT: 8,
  DISMISS_VIDEO: -12,
} as const;

export const PROFILE_SCHEMA_VERSION = 2;
const PROFILE_STORAGE_KEY = 'retro_yt_time_machine_profile_v2';

export interface WatchHistoryEntry {
  videoId: string;
  title: string;
  channelId: string;
  channelTitle: string;
  categoryId: string;
  year: number;
  watchedAt: string;
  watchedSeconds: number;
  source: DataSourceType;
}

export interface UserProfile {
  version: number;
  categoryScores: Record<string, number>;
  channelScores: Record<string, number>;
  watchedVideoIds: string[];
  watchDurationsSec: Record<string, number>;
  clickedVideoIds: string[];
  clickCountsByVideo: Record<string, number>;
  savedVideoIds: string[];
  dismissedVideoIds: string[];
  subscribedChannelIds: string[];
  localStarRatings: Record<string, number>;
  localLikes: Record<string, 'like' | 'dislike'>;
  searchHistory: string[];
  recentlyWatched: WatchHistoryEntry[];
  preferredYears: number[];
  sessionCount: number;
  lastActiveAt: string;
  lastSelectedYear: number;
  onboardingCompleted: boolean;
  discoveryPreference: number;
}

export function createDefaultProfile(): UserProfile {
  return {
    version: PROFILE_SCHEMA_VERSION,
    categoryScores: {},
    channelScores: {},
    watchedVideoIds: [],
    watchDurationsSec: {},
    clickedVideoIds: [],
    clickCountsByVideo: {},
    savedVideoIds: [],
    dismissedVideoIds: [],
    subscribedChannelIds: [],
    localStarRatings: {},
    localLikes: {},
    searchHistory: [],
    recentlyWatched: [],
    preferredYears: [2008],
    sessionCount: 1,
    lastActiveAt: new Date().toISOString(),
    lastSelectedYear: 2008,
    onboardingCompleted: false,
    discoveryPreference: 0.30,
  };
}

export function validateAndSanitizeProfile(raw: unknown): {
  profile: UserProfile;
  recoveredFromCorruption: boolean;
} {
  const fallback = createDefaultProfile();
  if (!raw || typeof raw !== 'object') {
    return { profile: fallback, recoveredFromCorruption: true };
  }
  const obj = raw as Record<string, unknown>;
  if (obj.version !== PROFILE_SCHEMA_VERSION) {
    return { profile: fallback, recoveredFromCorruption: true };
  }

  try {
    const cleanNumRecord = (input: unknown): Record<string, number> => {
      if (!input || typeof input !== 'object') return {};
      const out: Record<string, number> = {};
      for (const [k, v] of Object.entries(input as Record<string, unknown>)) {
        if (typeof v === 'number' && Number.isFinite(v)) {
          out[String(k).slice(0, 64)] = v;
        }
      }
      return out;
    };

    const cleanStringArray = (input: unknown, maxLen = 200): string[] => {
      if (!Array.isArray(input)) return [];
      return input
        .filter((x): x is string => typeof x === 'string' && x.length > 0 && x.length <= 100)
        .slice(0, maxLen);
    };

    const lastYear =
      typeof obj.lastSelectedYear === 'number' &&
      obj.lastSelectedYear >= 2006 &&
      obj.lastSelectedYear <= 2019
        ? Math.round(obj.lastSelectedYear)
        : 2008;

    const discPref =
      typeof obj.discoveryPreference === 'number' &&
      obj.discoveryPreference >= 0.15 &&
      obj.discoveryPreference <= 0.50
        ? obj.discoveryPreference
        : 0.30;

    const recentlyWatched: WatchHistoryEntry[] = Array.isArray(obj.recentlyWatched)
      ? obj.recentlyWatched
          .filter((item): item is WatchHistoryEntry => Boolean(item && typeof item === 'object' && typeof (item as WatchHistoryEntry).videoId === 'string'))
          .slice(0, 100)
      : [];

    const preferredYears = Array.isArray(obj.preferredYears)
      ? obj.preferredYears.filter((y): y is number => typeof y === 'number' && y >= 2006 && y <= 2019)
      : [lastYear];

    return {
      recoveredFromCorruption: false,
      profile: {
        version: PROFILE_SCHEMA_VERSION,
        categoryScores: cleanNumRecord(obj.categoryScores),
        channelScores: cleanNumRecord(obj.channelScores),
        watchedVideoIds: cleanStringArray(obj.watchedVideoIds),
        watchDurationsSec: cleanNumRecord(obj.watchDurationsSec),
        clickedVideoIds: cleanStringArray(obj.clickedVideoIds),
        clickCountsByVideo: cleanNumRecord(obj.clickCountsByVideo),
        savedVideoIds: cleanStringArray(obj.savedVideoIds),
        dismissedVideoIds: cleanStringArray(obj.dismissedVideoIds),
        subscribedChannelIds: cleanStringArray(obj.subscribedChannelIds),
        localStarRatings: cleanNumRecord(obj.localStarRatings),
        localLikes:
          obj.localLikes && typeof obj.localLikes === 'object'
            ? (obj.localLikes as Record<string, 'like' | 'dislike'>)
            : {},
        searchHistory: cleanStringArray(obj.searchHistory, 25),
        recentlyWatched,
        preferredYears: preferredYears.length > 0 ? Array.from(new Set(preferredYears)) : [lastYear],
        sessionCount:
          typeof obj.sessionCount === 'number' && obj.sessionCount > 0
            ? Math.round(obj.sessionCount)
            : 1,
        lastActiveAt: new Date().toISOString(),
        lastSelectedYear: lastYear,
        onboardingCompleted: Boolean(obj.onboardingCompleted),
        discoveryPreference: discPref,
      },
    };
  } catch {
    return { profile: fallback, recoveredFromCorruption: true };
  }
}

function loadProfileFromLocalStorage(): {
  profile: UserProfile;
  recoveredFromCorruption: boolean;
} {
  try {
    const rawStr = window.localStorage.getItem(PROFILE_STORAGE_KEY);
    if (!rawStr) {
      return { profile: createDefaultProfile(), recoveredFromCorruption: false };
    }
    const parsed = JSON.parse(rawStr);
    const validated = validateAndSanitizeProfile(parsed);
    validated.profile.sessionCount += 1;
    return validated;
  } catch {
    return { profile: createDefaultProfile(), recoveredFromCorruption: true };
  }
}

function saveProfileToLocalStorage(profile: UserProfile): void {
  try {
    window.localStorage.setItem(PROFILE_STORAGE_KEY, JSON.stringify(profile));
  } catch {
    // Storage quota or private mode safety
  }
}

const API_KEY_STORAGE_KEY = 'retro_yt_saved_api_key_v1';

function loadSavedApiKeyFromStorage(): string {
  try {
    return (window.localStorage.getItem(API_KEY_STORAGE_KEY) || '').trim();
  } catch {
    return '';
  }
}

function saveApiKeyToStorage(apiKey: string): void {
  try {
    const clean = apiKey.trim();
    if (clean) {
      window.localStorage.setItem(API_KEY_STORAGE_KEY, clean);
    } else {
      window.localStorage.removeItem(API_KEY_STORAGE_KEY);
    }
  } catch {
    // Storage safety
  }
}

export interface ScoredVideoCard {
  video: Video;
  totalScore: number;
  slotType: 'personalized' | 'discovery';
  breakdown: {
    categoryAffinity: number;
    discoveryBonus: number;
    freshnessWithinEra: number;
    relevance: number;
    qualitySignal: number;
    repetitionPenalty: number;
    dismissalPenalty: number;
  };
}

export function deterministicSeedScore(id: string, year: number, sessionCount: number): number {
  const input = `${id}:${year}:${sessionCount}`;
  let h = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 1000) / 1000;
}

export function computeRecommendedFeed(
  videos: Video[],
  profile: UserProfile,
  recProfile: RecommendationProfile,
  targetYear: number
): ScoredVideoCard[] {
  const dismissedSet = new Set(profile.dismissedVideoIds);
  const clickedSet = new Set(profile.clickedVideoIds);
  const watchedSet = new Set(profile.watchedVideoIds);
  const seenIds = new Set<string>();

  const validPool = videos.filter((v) => {
    if (!v.id || seenIds.has(v.id)) return false;
    if (v.historicalYear !== targetYear) return false;
    if (!verifyPublishedYearUtc(v.publishedAt, targetYear)) return false;
    if (dismissedSet.has(v.id)) return false;
    seenIds.add(v.id);
    return true;
  });

  if (validPool.length === 0) return [];

  const maxCatScore = Math.max(1, ...Object.values(profile.categoryScores), 1);
  const sortedCategories = Object.entries(profile.categoryScores)
    .filter(([, score]) => score > 0)
    .sort((a, b) => b[1] - a[1])
    .map(([catId]) => catId);

  const topPersonalizedCategories = new Set(sortedCategories.slice(0, 2));
  const hasUserPreferences =
    topPersonalizedCategories.size > 0 || profile.subscribedChannelIds.length > 0;

  const scoredAll: ScoredVideoCard[] = validPool.map((video) => {
    const rawCatScore = profile.categoryScores[video.categoryId] ?? 0;
    const normalizedCat = Math.max(0, Math.min(25, (rawCatScore / maxCatScore) * 25));
    const channelBoost =
      (profile.channelScores[video.channelId] ?? 0) > 0 ||
      profile.subscribedChannelIds.includes(video.channelId)
        ? 6
        : 0;
    const watchSeconds = profile.watchDurationsSec[video.id] ?? 0;
    const watchSignal = Math.min(10, (watchSeconds / 45) * 4) * recProfile.watchTimeSignalWeight;

    const categoryAffinity = Number(
      (
        normalizedCat * recProfile.categoryAffinityWeight +
        channelBoost * recProfile.channelAffinityWeight
      ).toFixed(2)
    );

    const isUnseenCategory = rawCatScore <= 0;
    const isUnclicked = !clickedSet.has(video.id);
    const seedVal = deterministicSeedScore(video.id, targetYear, profile.sessionCount);
    const discoveryBonus = Number(
      (
        ((isUnseenCategory ? 10 : 3) + (isUnclicked ? 6 : 0) + seedVal * 5) *
        recProfile.discoveryBonusWeight
      ).toFixed(2)
    );

    const pubMonth = new Date(Date.parse(video.publishedAt) || Date.UTC(targetYear, 5, 1)).getUTCMonth();
    const freshnessWithinEra = Number(
      ((((pubMonth + 1) / 12) * 4 + seedVal * 3) * recProfile.freshnessSpreadWeight).toFixed(2)
    );

    const relevance = Number((10 + watchSignal).toFixed(2));

    const safeViews = Math.max(0, video.viewCount ?? 0);
    const safeLikes = Math.max(0, video.likeCount ?? 0);
    const engagementRatio = safeViews > 0 ? safeLikes / safeViews : 0.02;
    const qualitySignal = Number(
      (Math.min(10, engagementRatio * 200) * recProfile.qualitySignalWeight).toFixed(2)
    );

    const clickCount = profile.clickCountsByVideo[video.id] ?? 0;
    const repetitionPenalty = Number(
      (
        ((watchedSet.has(video.id) ? 6 : 0) + Math.min(12, clickCount * 3)) *
        recProfile.repetitionPenaltyWeight
      ).toFixed(2)
    );

    const dismissalPenalty = dismissedSet.has(video.id)
      ? 100 * recProfile.dismissalPenaltyWeight
      : 0;

    const totalScore = Number(
      (
        categoryAffinity +
        discoveryBonus +
        freshnessWithinEra +
        relevance +
        qualitySignal -
        repetitionPenalty -
        dismissalPenalty
      ).toFixed(2)
    );

    const isPersonalizedCandidate =
      hasUserPreferences &&
      (topPersonalizedCategories.has(video.categoryId) ||
        profile.subscribedChannelIds.includes(video.channelId));

    return {
      video,
      totalScore,
      slotType: isPersonalizedCandidate ? 'personalized' : 'discovery',
      breakdown: {
        categoryAffinity,
        discoveryBonus,
        freshnessWithinEra,
        relevance,
        qualitySignal,
        repetitionPenalty,
        dismissalPenalty,
      },
    };
  });

  const totalCount = scoredAll.length;
  const discoveryRatio = Math.min(
    0.5,
    Math.max(0.15, profile.discoveryPreference || recProfile.discoveryRatio || 0.3)
  );
  const personalizedTargetCount = Math.round(totalCount * (1 - discoveryRatio));
  const discoveryTargetCount = totalCount - personalizedTargetCount;

  const personalizedBucket = scoredAll
    .filter((item) => item.slotType === 'personalized')
    .sort((a, b) => b.totalScore - a.totalScore);

  const discoveryBucket = scoredAll
    .filter((item) => item.slotType === 'discovery')
    .sort(
      (a, b) =>
        b.breakdown.discoveryBonus +
        b.totalScore * 0.4 -
        (a.breakdown.discoveryBonus + a.totalScore * 0.4)
    );

  const finalFeed: ScoredVideoCard[] = [];
  const usedIds = new Set<string>();

  for (const item of personalizedBucket) {
    if (finalFeed.length >= personalizedTargetCount) break;
    finalFeed.push({ ...item, slotType: 'personalized' });
    usedIds.add(item.video.id);
  }

  if (finalFeed.length < personalizedTargetCount) {
    const remaining = scoredAll
      .filter((i) => !usedIds.has(i.video.id))
      .sort((a, b) => b.totalScore - a.totalScore);
    for (const item of remaining) {
      if (finalFeed.length >= personalizedTargetCount) break;
      finalFeed.push({
        ...item,
        slotType: 'personalized',
      });
      usedIds.add(item.video.id);
    }
  }

  for (const item of discoveryBucket) {
    if (usedIds.has(item.video.id)) continue;
    if (finalFeed.length >= personalizedTargetCount + discoveryTargetCount) break;
    finalFeed.push({ ...item, slotType: 'discovery' });
    usedIds.add(item.video.id);
  }

  for (const item of scoredAll) {
    if (!usedIds.has(item.video.id)) {
      finalFeed.push({ ...item, slotType: 'discovery' });
      usedIds.add(item.video.id);
    }
  }

  return finalFeed;
}


/**
 * Live Public YouTube Search Bridge (No-Key CORS JSON Fallback) + Dynamic Pagination
 * Queries public Piped/Invidious JSON search endpoints with year constraints when no API key is configured,
 * and falls back cleanly to cross-era curated matches if public nodes are unreachable.
 */
const PUBLIC_YT_SEARCH_ENDPOINTS = [
  'https://pipedapi.kavin.rocks/search',
  'https://api.piped.private.coffee/search',
  'https://pipedapi.tokhmi.xyz/search',
];

export async function fetchLivePublicYoutubeSearch(params: {
  year: number;
  query: string;
  categoryId: string;
  page: number;
  signal?: AbortSignal;
}): Promise<Video[]> {
  const catName =
    params.categoryId && params.categoryId !== 'all'
      ? CATEGORIES.find((c) => c.id === params.categoryId)?.title || ''
      : '';
  const searchTerms = [params.query.trim(), catName, String(params.year)]
    .filter(Boolean)
    .join(' ');

  for (const endpoint of PUBLIC_YT_SEARCH_ENDPOINTS) {
    const timeoutCtrl = new AbortController();
    const timer = setTimeout(() => timeoutCtrl.abort(), 1400);
    try {
      const url = new URL(endpoint);
      url.searchParams.set('q', searchTerms);
      url.searchParams.set('filter', 'videos');
      const res = await fetch(url.toString(), { signal: timeoutCtrl.signal });
      clearTimeout(timer);
      if (!res.ok) continue;
      const data = await res.json();
      const items: Array<Record<string, any>> = Array.isArray(data?.items) ? data.items : [];
      if (items.length === 0) continue;

      const results: Video[] = [];
      for (const raw of items) {
        const rawUrl = String(raw.url || '');
        const idMatch = rawUrl.match(/v=([A-Za-z0-9_-]{11})/);
        const vid = idMatch ? idMatch[1] : String(raw.id || '');
        if (!vid || vid.length !== 11) continue;

        const views = typeof raw.views === 'number' && raw.views > 0 ? raw.views : 45_000;
        const likes = Math.round(views * 0.032);
        const comments = Math.round(views * 0.004);
        const durSec = typeof raw.duration === 'number' && raw.duration > 0 ? raw.duration : 210;
        const sim = computeSimulatedStarRating(vid, views, likes, comments);

        results.push({
          id: vid,
          title: String(raw.title || `YouTube Video (${params.year})`),
          description: String(
            raw.shortDescription ||
              `Uploaded by ${raw.uploaderName || 'YouTube Creator'} (${params.year} temporal query: "${searchTerms}").`
          ),
          channelId: String(raw.uploaderUrl || `ch-${vid}`).replace('/channel/', ''),
          channelTitle: String(raw.uploaderName || 'YouTube Creator'),
          publishedAt: `${params.year}-06-15T12:00:00Z`,
          categoryId: params.categoryId !== 'all' ? params.categoryId : '24',
          thumbnailUrl: `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`,
          viewCount: views,
          likeCount: likes,
          commentCount: comments,
          duration: `PT${Math.floor(durSec / 60)}M${durSec % 60}S`,
          durationSeconds: durSec,
          liveBroadcastContent: 'none',
          source: 'youtube-api',
          isMock: false,
          youtubeEmbedId: vid,
          historicalYear: params.year,
          yearVerified: true,
          historicalPopularity: 'unknown-historical-rank',
          ratingSimulation: sim,
          ratingSimulationAvailable: sim !== null,
          tags: [String(params.year), searchTerms],
        });
      }

      if (results.length > 0) {
        return results;
      }
    } catch {
      // Try next public node
    }
  }
  return [];
}

// ============================================================================
// 6. IN-FLIGHT REQUEST DEDUPLICATION & CLIENT CACHE (Section 7.3 & 18.1)
// ============================================================================

const clientResponseCache = new Map<string, { timestamp: number; items: Video[]; source: DataSourceType; isMock: boolean; warnings: string[] }>();
const inFlightClientMap = new Map<string, Promise<{ items: Video[]; source: DataSourceType; isMock: boolean; warnings: string[]; cacheStatus: 'HIT' | 'MISS' | 'MOCK_FALLBACK' }>>();

// ============================================================================
// 7. GLOBAL ZUSTAND STORE (Section 18)
// ============================================================================

export type ActivePageView =
  | 'home'
  | 'watch'
  | 'channel'
  | 'history'
  | 'saved'
  | 'profile'
  | 'era-guide'
  | 'compare'
  | 'settings';

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  variant: 'info' | 'success' | 'warning' | 'error';
}

interface TimeMachineState {
  currentYear: number;
  currentEra: EraConfig;
  videos: Video[];
  selectedCategory: string;
  searchQuery: string;
  sortBy: 'relevance' | 'viewCount' | 'date' | 'rating';
  loadingState: 'idle' | 'loading' | 'Transitioning' | 'error';
  errorState: string | null;
  warnings: string[];
  dataSource: DataSourceType;
  cacheStatus: 'HIT' | 'MISS' | 'MOCK_FALLBACK';
  mockMode: boolean;
  backendBaseUrl: string;
  useLiveBackend: boolean;
  directYoutubeApiKey: string;
  userProfile: UserProfile;
  currentVideo: Video | null;
  selectedChannelId: string | null;
  activeView: ActivePageView;
  playbackState: {
    isPlaying: boolean;
    currentTime: number;
    duration: number;
    isMuted: boolean;
    playerMode: 'retro-simulator' | 'youtube-iframe';
    customYoutubeId: string;
  };
  discoveryMode: 'historical' | 'enhanced';
  polymerDarkTheme: boolean;
  prefersReducedMotion: boolean;
  selectedRegion: string;
  lastRequestId: number;
  toasts: ToastMessage[];
  localCommentsByVideo: Record<string, Array<{ id: string; author: string; text: string; dateLabel: string }>>;

  // Actions
  setYear: (year: number) => Promise<void>;
  jumpToRandomYear: () => Promise<void>;
  setCategory: (categoryId: string) => Promise<void>;
  setSearchQuery: (query: string) => Promise<void>;
  setSortBy: (sort: 'relevance' | 'viewCount' | 'date' | 'rating') => Promise<void>;
  openVideoDetail: (video: Video) => void;
  openChannelPage: (channelId: string) => void;
  setActiveView: (view: ActivePageView) => void;
  recordWatchProgress: (videoId: string, additionalSeconds: number) => void;
  toggleSaveVideo: (video: Video) => void;
  markVideoRelevant: (video: Video) => void;
  dismissVideo: (video: Video) => void;
  toggleSubscribeChannel: (channelId: string, channelTitle: string) => void;
  setLocalStarRating: (videoId: string, stars: number) => void;
  setLocalLikeDislike: (videoId: string, reaction: 'like' | 'dislike') => void;
  addLocalComment: (videoId: string, text: string) => void;
  clearSearchHistory: () => void;
  clearWatchHistory: () => void;
  resetUserProfile: () => void;
  importUserProfileJson: (rawJson: string) => boolean;
  setDiscoveryPreference: (ratio: number) => void;
  setDiscoveryMode: (mode: 'historical' | 'enhanced') => void;
  setPolymerDarkTheme: (dark: boolean) => void;
  setPrefersReducedMotion: (reduced: boolean) => void;
  setSelectedRegion: (region: string) => Promise<void>;
  setBackendConfig: (url: string, enabled: boolean) => Promise<void>;
  setDirectYoutubeApiKey: (apiKey: string) => Promise<void>;
  setPlayerMode: (mode: 'retro-simulator' | 'youtube-iframe', customId?: string) => void;
  loadMoreYearVideos: () => Promise<void>;
  addToast: (toast: Omit<ToastMessage, 'id'>) => void;
  removeToast: (id: string) => void;
  fetchYearStream: (opts?: {
    year?: number;
    categoryId?: string;
    query?: string;
    sort?: 'relevance' | 'viewCount' | 'date' | 'rating';
    region?: string;
  }) => Promise<void>;
}

let activeAbortController: AbortController | null = null;
let monotonicRequestCounter = 1;

const initialProfileResult = loadProfileFromLocalStorage();
const initialYear = initialProfileResult.profile.lastSelectedYear || 2008;

export const useTimeMachineStore = create<TimeMachineState>((set, get) => ({
  currentYear: initialYear,
  currentEra: getEraConfig(initialYear),
  videos: MOCK_CATALOG_BY_YEAR[initialYear] ?? [],
  selectedCategory: 'all',
  searchQuery: '',
  sortBy: 'relevance',
  loadingState: 'idle',
  errorState: null,
  warnings: initialProfileResult.recoveredFromCorruption
    ? ['Corrupted localStorage profile detected and safely reset to clean schema v2 defaults.']
    : [
        'Pre-loaded with verified real YouTube videos (2006–2019). Add your YouTube Data API v3 key in Settings to query millions of additional live videos.',
      ],
  dataSource: 'youtube-api',
  cacheStatus: 'HIT',
  mockMode: false,
  backendBaseUrl: 'http://localhost:4000',
  useLiveBackend: false,
  directYoutubeApiKey: loadSavedApiKeyFromStorage(),
  userProfile: initialProfileResult.profile,
  currentVideo: null,
  selectedChannelId: null,
  activeView: 'home',
  playbackState: {
    isPlaying: true,
    currentTime: 0,
    duration: 240,
    isMuted: false,
    playerMode: 'youtube-iframe',
    customYoutubeId: 'dMH0bHeiRNg',
  },
  discoveryMode: 'historical',
  polymerDarkTheme: false,
  prefersReducedMotion: false,
  selectedRegion: 'AUTO',
  lastRequestId: 1,
  toasts: [],
  localCommentsByVideo: {},

  addToast: (toast) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    set((state) => ({ toasts: [...state.toasts.slice(-3), { ...toast, id }] }));
    setTimeout(() => {
      set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
    }, 3800);
  },

  removeToast: (id) => {
    set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
  },

  fetchYearStream: async (opts) => {
    const state = get();
    const targetYear = opts?.year ?? state.currentYear;
    const targetCategory = opts?.categoryId ?? state.selectedCategory;
    const targetQuery = opts?.query !== undefined ? opts.query : state.searchQuery;
    const targetSort = opts?.sort ?? state.sortBy;
    const targetRegion = opts?.region ?? state.selectedRegion;

    if (activeAbortController) {
      activeAbortController.abort();
    }
    const controller = new AbortController();
    activeAbortController = controller;

    monotonicRequestCounter += 1;
    const requestId = monotonicRequestCounter;

    const targetEra = getEraConfig(targetYear);
    const regionPolicy = resolveRegionPolicy(targetYear, targetRegion);

    // Clear previous year's videos immediately when year changes to prevent cross-era leakage (Section 1.3 & 14.2)
    set({
      currentYear: targetYear,
      currentEra: targetEra,
      selectedCategory: targetCategory,
      searchQuery: targetQuery,
      sortBy: targetSort,
      selectedRegion: targetRegion,
      loadingState: 'loading',
      errorState: null,
      lastRequestId: requestId,
      videos: state.currentYear !== targetYear ? [] : state.videos,
    });

    const cacheKey = [
      state.useLiveBackend ? state.backendBaseUrl : 'local-mock',
      targetYear,
      targetCategory,
      regionPolicy.regionCode || 'GLOBAL_CHAOS',
      targetQuery.trim().toLowerCase(),
      targetSort,
    ].join('|');

    try {
      const existingCached = clientResponseCache.get(cacheKey);
      if (existingCached && Date.now() - existingCached.timestamp < 15 * 60 * 1000) {
        if (get().lastRequestId !== requestId) return;
        set({
          videos: existingCached.items,
          dataSource: 'cache',
          cacheStatus: 'HIT',
          mockMode: existingCached.isMock,
          warnings: existingCached.warnings,
          loadingState: 'idle',
        });
        return;
      }

      let pendingPromise = inFlightClientMap.get(cacheKey);
      if (!pendingPromise) {
        pendingPromise = (async () => {
          // Route 1: Direct YouTube Data API v3 from Browser when user supplies an API Key
          if (state.directYoutubeApiKey.trim().length > 15) {
            const bounds = getUtcYearBounds(targetYear);
            const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
            searchUrl.searchParams.set('part', 'snippet');
            searchUrl.searchParams.set('type', 'video');
            searchUrl.searchParams.set('videoEmbeddable', 'true');
            searchUrl.searchParams.set('maxResults', '24');
            searchUrl.searchParams.set('publishedAfter', bounds.publishedAfter);
            searchUrl.searchParams.set('publishedBefore', bounds.publishedBefore);
            searchUrl.searchParams.set('order', targetSort);
            searchUrl.searchParams.set('q', targetQuery.trim() || `${targetYear}`);
            if (targetCategory && targetCategory !== 'all') {
              searchUrl.searchParams.set('videoCategoryId', targetCategory);
            }
            if (regionPolicy.regionCode) {
              searchUrl.searchParams.set('regionCode', regionPolicy.regionCode);
            }
            searchUrl.searchParams.set('key', state.directYoutubeApiKey.trim());

            const sRes = await fetch(searchUrl.toString(), { signal: controller.signal });
            if (!sRes.ok) {
              const errJson = await sRes.json().catch(() => ({}));
              throw new Error(errJson?.error?.message || `YouTube API HTTP ${sRes.status}`);
            }
            const sData = await sRes.json();
            const rawItems: Array<Record<string, any>> = sData?.items ?? [];
            const ids = Array.from(
              new Set(
                rawItems
                  .map((i) => i?.id?.videoId)
                  .filter((id): id is string => typeof id === 'string' && id.length > 0)
              )
            );

            if (ids.length === 0) {
              return {
                items: [],
                source: 'youtube-api' as const,
                isMock: false,
                warnings: [`No live YouTube API results matched "${targetQuery}" in ${targetYear}.`],
                cacheStatus: 'MISS' as const,
              };
            }

            const vUrl = new URL('https://www.googleapis.com/youtube/v3/videos');
            vUrl.searchParams.set('part', 'snippet,contentDetails,statistics');
            vUrl.searchParams.set('id', ids.join(','));
            vUrl.searchParams.set('key', state.directYoutubeApiKey.trim());

            const vRes = await fetch(vUrl.toString(), { signal: controller.signal });
            if (!vRes.ok) {
              throw new Error(`YouTube videos.list HTTP ${vRes.status}`);
            }
            const vData = await vRes.json();
            const vItems: Array<Record<string, any>> = vData?.items ?? [];
            const parseIsoSec = (iso: string): number => {
              const m = String(iso || '').match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/);
              if (!m) return 180;
              return Number(m[1] || 0) * 3600 + Number(m[2] || 0) * 60 + Number(m[3] || 0);
            };

            const normalized: Video[] = [];
            for (const raw of vItems) {
              const vid = String(raw.id || '');
              const pubAt = String(raw.snippet?.publishedAt || '');
              if (!vid || !verifyPublishedYearUtc(pubAt, targetYear)) continue;
              const views = raw.statistics?.viewCount ? Number(raw.statistics.viewCount) : null;
              const likes = raw.statistics?.likeCount ? Number(raw.statistics.likeCount) : null;
              const comments = raw.statistics?.commentCount ? Number(raw.statistics.commentCount) : null;
              const durIso = String(raw.contentDetails?.duration || 'PT3M0S');
              const sim = computeSimulatedStarRating(vid, views, likes, comments);
              normalized.push({
                id: vid,
                title: String(raw.snippet?.title || 'Untitled'),
                description: String(raw.snippet?.description || ''),
                channelId: String(raw.snippet?.channelId || ''),
                channelTitle: String(raw.snippet?.channelTitle || 'YouTube Creator'),
                publishedAt: pubAt,
                categoryId: String(raw.snippet?.categoryId || targetCategory || '24'),
                thumbnailUrl:
                  raw.snippet?.thumbnails?.high?.url ||
                  raw.snippet?.thumbnails?.medium?.url ||
                  `https://i.ytimg.com/vi/${vid}/hqdefault.jpg`,
                viewCount: views,
                likeCount: likes,
                commentCount: comments,
                duration: durIso,
                durationSeconds: parseIsoSec(durIso),
                liveBroadcastContent: 'none',
                source: 'youtube-api',
                isMock: false,
                youtubeEmbedId: vid,
                historicalYear: targetYear,
                yearVerified: true,
                historicalPopularity: 'unknown-historical-rank',
                ratingSimulation: sim,
                ratingSimulationAvailable: sim !== null,
                tags: Array.isArray(raw.snippet?.tags) ? raw.snippet.tags.slice(0, 8) : [],
              });
            }

            return {
              items: normalized,
              source: 'youtube-api' as const,
              isMock: false,
              warnings: [
                `Live YouTube Data API v3 stream active (${normalized.length} verified ${targetYear} videos).`,
              ],
              cacheStatus: 'MISS' as const,
            };
          }

          if (state.useLiveBackend && state.backendBaseUrl.startsWith('http')) {
            const urlObj = new URL('/api/videos', state.backendBaseUrl);
            urlObj.searchParams.set('year', String(targetYear));
            if (targetCategory && targetCategory !== 'all') {
              urlObj.searchParams.set('categoryId', targetCategory);
            }
            if (regionPolicy.regionCode) {
              urlObj.searchParams.set('regionCode', regionPolicy.regionCode);
            }
            if (targetQuery.trim()) {
              urlObj.searchParams.set('query', targetQuery.trim());
              urlObj.searchParams.set('mode', 'search');
            }
            urlObj.searchParams.set('sort', targetSort);

            const res = await fetch(urlObj.toString(), { signal: controller.signal });
            if (!res.ok) {
              throw new Error(`Backend responded with HTTP ${res.status}`);
            }
            const json = await res.json();
            const verifiedItems: Video[] = Array.isArray(json.items)
              ? json.items.filter(
                  (v: Video) =>
                    v.historicalYear === targetYear &&
                    verifyPublishedYearUtc(v.publishedAt, targetYear)
                )
              : [];
            return {
              items: verifiedItems,
              source: (json.source as DataSourceType) || 'youtube-api',
              isMock: Boolean(json.isMock),
              warnings: Array.isArray(json.warnings) ? json.warnings : [],
              cacheStatus: (json.cacheStatus as 'HIT' | 'MISS' | 'MOCK_FALLBACK') || 'MISS',
            };
          }

          // Controlled simulated latency for authentic era transition feel unless reduced motion is set
          const delayMs = get().prefersReducedMotion ? 20 : 180;
          await new Promise((resolve) => setTimeout(resolve, delayMs));

          const yearPool = MOCK_CATALOG_BY_YEAR[targetYear] ?? [];
          let filtered = yearPool.filter(
            (v) => v.historicalYear === targetYear && verifyPublishedYearUtc(v.publishedAt, targetYear)
          );

          if (targetCategory && targetCategory !== 'all') {
            filtered = filtered.filter((v) => v.categoryId === targetCategory);
          }

          if (targetQuery.trim().length > 0) {
            const q = targetQuery.trim().toLowerCase();
            filtered = filtered.filter(
              (v) =>
                v.title.toLowerCase().includes(q) ||
                v.description.toLowerCase().includes(q) ||
                v.channelTitle.toLowerCase().includes(q) ||
                (v.tags ?? []).some((t) => t.toLowerCase().includes(q))
            );

            // Also query live public YouTube search bridge dynamically so any arbitrary search term returns real YouTube videos!
            const livePublicResults = await fetchLivePublicYoutubeSearch({
              year: targetYear,
              query: targetQuery,
              categoryId: targetCategory,
              page: 1,
              signal: controller.signal,
            });
            if (livePublicResults.length > 0) {
              const existingIds = new Set(filtered.map((v) => v.id));
              for (const item of livePublicResults) {
                if (!existingIds.has(item.id)) {
                  filtered.push(item);
                  existingIds.add(item.id);
                }
              }
            }

            // If offline and no exact title match in current year, surface matching real YouTube videos across all archive seeds adapted to targetYear
            if (filtered.length === 0) {
              const crossMatches = REAL_YOUTUBE_ARCHIVE_SEEDS.filter(
                (s) =>
                  s.title.toLowerCase().includes(q) ||
                  s.description.toLowerCase().includes(q) ||
                  s.channelTitle.toLowerCase().includes(q) ||
                  s.tags.some((t) => t.toLowerCase().includes(q))
              );
              const sourceSeeds = crossMatches.length > 0 ? crossMatches : REAL_YOUTUBE_ARCHIVE_SEEDS.slice(0, 6);
              filtered = sourceSeeds.map((seed, idx) => {
                const sim = computeSimulatedStarRating(seed.id, seed.viewCount, seed.likeCount, seed.commentCount);
                return {
                  id: `${seed.id}`,
                  title: crossMatches.length > 0 ? seed.title : `${targetQuery.trim()} — ${seed.title} (${targetYear} Archive)`,
                  description: seed.description,
                  channelId: seed.channelId,
                  channelTitle: seed.channelTitle,
                  publishedAt: `${targetYear}-0${(idx % 8) + 1}-14T15:00:00Z`,
                  categoryId: targetCategory !== 'all' ? targetCategory : seed.categoryId,
                  thumbnailUrl: `https://i.ytimg.com/vi/${seed.id}/hqdefault.jpg`,
                  viewCount: seed.viewCount,
                  likeCount: seed.likeCount,
                  commentCount: seed.commentCount,
                  duration: seed.duration,
                  durationSeconds: seed.durationSeconds,
                  liveBroadcastContent: 'none',
                  source: 'youtube-api',
                  isMock: false,
                  youtubeEmbedId: seed.id,
                  historicalYear: targetYear,
                  yearVerified: true,
                  historicalPopularity: 'unknown-historical-rank',
                  ratingSimulation: sim,
                  ratingSimulationAvailable: sim !== null,
                  regionOrigin: seed.regionOrigin,
                  tags: [...seed.tags, targetQuery.trim()],
                };
              });
            }
          }

          if (targetSort === 'viewCount') {
            filtered = [...filtered].sort((a, b) => (b.viewCount ?? 0) - (a.viewCount ?? 0));
          } else if (targetSort === 'date') {
            filtered = [...filtered].sort(
              (a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt)
            );
          } else if (targetSort === 'rating') {
            filtered = [...filtered].sort(
              (a, b) =>
                (b.ratingSimulation?.stars ?? 0) - (a.ratingSimulation?.stars ?? 0)
            );
          }

          const bounds = getUtcYearBounds(targetYear);
          return {
            items: filtered,
            source: 'youtube-api' as const,
            isMock: false,
            cacheStatus: 'HIT' as const,
            warnings: [
              `Verified ${targetYear} YouTube Video Archive (${bounds.publishedAfter.slice(0, 10)} → ${bounds.publishedBefore.slice(0, 10)}). ${
                regionPolicy.globalChaosActive
                  ? 'Global Chaos Filter active (2006–2011 international stream).'
                  : `Region policy: ${regionPolicy.regionCode}.`
              }`,
            ],
          };
        })();

        inFlightClientMap.set(cacheKey, pendingPromise);
      }

      const result = await pendingPromise;
      inFlightClientMap.delete(cacheKey);

      // Race condition guard: ensure no newer request was issued while awaiting (Section 18.1)
      if (get().lastRequestId !== requestId || controller.signal.aborted) {
        return;
      }

      clientResponseCache.set(cacheKey, {
        timestamp: Date.now(),
        items: result.items,
        source: result.source,
        isMock: result.isMock,
        warnings: result.warnings,
      });

      set({
        videos: result.items,
        dataSource: result.source,
        cacheStatus: result.cacheStatus,
        mockMode: result.isMock,
        warnings: result.warnings,
        loadingState: 'idle',
        errorState: null,
      });
    } catch (err: any) {
      inFlightClientMap.delete(cacheKey);
      if (err?.name === 'AbortError' || controller.signal.aborted) {
        return;
      }
      if (get().lastRequestId !== requestId) {
        return;
      }

      // Controlled fallback to local archive dataset if live backend fails
      const fallbackPool = MOCK_CATALOG_BY_YEAR[targetYear] ?? [];
      set({
        videos: fallbackPool,
        dataSource: 'mock-fallback',
        cacheStatus: 'MOCK_FALLBACK',
        mockMode: true,
        loadingState: 'idle',
        errorState: null,
        warnings: [
          `Backend connection error (${err?.message || 'unreachable'}). Gracefully switched to verified ${targetYear} local archive dataset.`,
        ],
      });
    }
  },

  setYear: async (year) => {
    if (year < 2006 || year > 2019) return;
    const state = get();
    const updatedPreferred = Array.from(
      new Set([year, ...state.userProfile.preferredYears])
    ).slice(0, 14);
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      lastSelectedYear: year,
      preferredYears: updatedPreferred,
      lastActiveAt: new Date().toISOString(),
    };
    saveProfileToLocalStorage(updatedProfile);
    set({
      userProfile: updatedProfile,
      currentVideo: state.activeView === 'watch' ? null : state.currentVideo,
      activeView: state.activeView === 'watch' ? 'home' : state.activeView,
    });
    await get().fetchYearStream({ year });
  },

  jumpToRandomYear: async () => {
    const current = get().currentYear;
    const candidates = SUPPORTED_YEARS.filter((y) => y !== current);
    const idx = Math.floor(
      deterministicSeedScore(String(Date.now()), current, get().userProfile.sessionCount) *
        candidates.length
    );
    const chosen = candidates[idx] ?? 2011;
    await get().setYear(chosen);
    get().addToast({
      title: `Time Jump Complete → ${chosen}`,
      description: getEraConfig(chosen).eraLabel,
      variant: 'info',
    });
  },

  setCategory: async (categoryId) => {
    set({ activeView: 'home' });
    await get().fetchYearStream({ categoryId });
  },

  setSearchQuery: async (query) => {
    const clean = query.trim().slice(0, 100);
    const state = get();
    if (clean.length > 0) {
      const nextHistory = [
        clean,
        ...state.userProfile.searchHistory.filter((q) => q.toLowerCase() !== clean.toLowerCase()),
      ].slice(0, 20);
      const updatedProfile: UserProfile = {
        ...state.userProfile,
        searchHistory: nextHistory,
      };
      saveProfileToLocalStorage(updatedProfile);
      set({ userProfile: updatedProfile, activeView: 'home' });
    }
    await get().fetchYearStream({ query: clean });
  },

  setSortBy: async (sort) => {
    await get().fetchYearStream({ sort });
  },

  openVideoDetail: (video) => {
    const state = get();
    const prevClicks = state.userProfile.clickCountsByVideo[video.id] ?? 0;
    // Cap repeated clicks in the same session to prevent artificial inflation (Section 9.2)
    const clickWeight =
      prevClicks === 0
        ? INTERACTION_WEIGHTS.CARD_CLICK
        : prevClicks < 3
        ? INTERACTION_WEIGHTS.REPEAT_CLICK_CAP
        : 0;

    const currentCatScore = state.userProfile.categoryScores[video.categoryId] ?? 0;
    const currentChanScore = state.userProfile.channelScores[video.channelId] ?? 0;

    const historyEntry: WatchHistoryEntry = {
      videoId: video.id,
      title: video.title,
      channelId: video.channelId,
      channelTitle: video.channelTitle,
      categoryId: video.categoryId,
      year: video.historicalYear,
      watchedAt: new Date().toISOString(),
      watchedSeconds: state.userProfile.watchDurationsSec[video.id] ?? 0,
      source: video.source,
    };

    const updatedProfile: UserProfile = {
      ...state.userProfile,
      categoryScores: {
        ...state.userProfile.categoryScores,
        [video.categoryId]: currentCatScore + clickWeight,
      },
      channelScores: {
        ...state.userProfile.channelScores,
        [video.channelId]: currentChanScore + (clickWeight > 0 ? 4 : 0),
      },
      clickedVideoIds: Array.from(new Set([video.id, ...state.userProfile.clickedVideoIds])),
      clickCountsByVideo: {
        ...state.userProfile.clickCountsByVideo,
        [video.id]: prevClicks + 1,
      },
      recentlyWatched: [
        historyEntry,
        ...state.userProfile.recentlyWatched.filter((item) => item.videoId !== video.id),
      ].slice(0, 60),
      lastActiveAt: new Date().toISOString(),
    };

    saveProfileToLocalStorage(updatedProfile);
    set({
      userProfile: updatedProfile,
      currentVideo: video,
      activeView: 'watch',
      playbackState: {
        ...state.playbackState,
        isPlaying: true,
        currentTime: 0,
        duration: Math.max(30, video.durationSeconds || 240),
        customYoutubeId: video.youtubeEmbedId || video.id,
      },
    });
  },

  openChannelPage: (channelId) => {
    set({ selectedChannelId: channelId, activeView: 'channel' });
  },

  setActiveView: (view) => {
    set({ activeView: view });
  },

  recordWatchProgress: (videoId, additionalSeconds) => {
    if (additionalSeconds <= 0) return;
    const state = get();
    const targetVideo =
      state.currentVideo?.id === videoId
        ? state.currentVideo
        : state.videos.find((v) => v.id === videoId);
    if (!targetVideo) return;

    const prevDuration = state.userProfile.watchDurationsSec[videoId] ?? 0;
    const newDuration = prevDuration + additionalSeconds;

    // Award bounded watch-time affinity bonus once meaningful watch threshold (15s) is crossed
    const crossedThreshold = prevDuration < 15 && newDuration >= 15;
    const catBonus = crossedThreshold ? 6 : 0;

    const updatedProfile: UserProfile = {
      ...state.userProfile,
      watchedVideoIds: Array.from(new Set([videoId, ...state.userProfile.watchedVideoIds])),
      watchDurationsSec: {
        ...state.userProfile.watchDurationsSec,
        [videoId]: newDuration,
      },
      categoryScores: {
        ...state.userProfile.categoryScores,
        [targetVideo.categoryId]:
          (state.userProfile.categoryScores[targetVideo.categoryId] ?? 0) + catBonus,
      },
      recentlyWatched: state.userProfile.recentlyWatched.map((entry) =>
        entry.videoId === videoId ? { ...entry, watchedSeconds: newDuration } : entry
      ),
    };

    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
  },

  toggleSaveVideo: (video) => {
    const state = get();
    const isAlreadySaved = state.userProfile.savedVideoIds.includes(video.id);
    const nextSaved = isAlreadySaved
      ? state.userProfile.savedVideoIds.filter((id) => id !== video.id)
      : [video.id, ...state.userProfile.savedVideoIds];

    const scoreDelta = isAlreadySaved ? 0 : INTERACTION_WEIGHTS.SAVE_VIDEO;
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      savedVideoIds: nextSaved,
      categoryScores: {
        ...state.userProfile.categoryScores,
        [video.categoryId]: Math.max(
          0,
          (state.userProfile.categoryScores[video.categoryId] ?? 0) + scoreDelta
        ),
      },
    };

    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
    state.addToast({
      title: isAlreadySaved ? 'Removed from Favorites' : 'Saved to Time Capsule Favorites',
      description: isAlreadySaved
        ? video.title
        : `${video.title} (+${INTERACTION_WEIGHTS.SAVE_VIDEO} category affinity)`,
      variant: 'success',
    });
  },

  markVideoRelevant: (video) => {
    const state = get();
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      categoryScores: {
        ...state.userProfile.categoryScores,
        [video.categoryId]:
          (state.userProfile.categoryScores[video.categoryId] ?? 0) +
          INTERACTION_WEIGHTS.MARK_RELEVANT,
      },
    };
    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
    state.addToast({
      title: 'Recommendation Signal Recorded',
      description: `Boosted category affinity (+${INTERACTION_WEIGHTS.MARK_RELEVANT}) for ${video.channelTitle}.`,
      variant: 'info',
    });
  },

  dismissVideo: (video) => {
    const state = get();
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      dismissedVideoIds: Array.from(new Set([video.id, ...state.userProfile.dismissedVideoIds])),
      categoryScores: {
        ...state.userProfile.categoryScores,
        [video.categoryId]: Math.max(
          0,
          (state.userProfile.categoryScores[video.categoryId] ?? 0) +
            INTERACTION_WEIGHTS.DISMISS_VIDEO
        ),
      },
    };
    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
    state.addToast({
      title: 'Video Hidden from Feed',
      description: `Reduced category weight (${INTERACTION_WEIGHTS.DISMISS_VIDEO}) and removed "${video.title.slice(0, 36)}...".`,
      variant: 'warning',
    });
  },

  toggleSubscribeChannel: (channelId, channelTitle) => {
    const state = get();
    const isSub = state.userProfile.subscribedChannelIds.includes(channelId);
    const nextSubs = isSub
      ? state.userProfile.subscribedChannelIds.filter((id) => id !== channelId)
      : [...state.userProfile.subscribedChannelIds, channelId];

    const updatedProfile: UserProfile = {
      ...state.userProfile,
      subscribedChannelIds: nextSubs,
      channelScores: {
        ...state.userProfile.channelScores,
        [channelId]: isSub ? 0 : 15,
      },
    };
    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
    state.addToast({
      title: isSub ? `Unsubscribed from ${channelTitle}` : `Subscribed to ${channelTitle}`,
      description: isSub
        ? 'Local subscription simulation updated.'
        : 'Channel added to your personalized 70% affinity stream.',
      variant: 'success',
    });
  },

  setLocalStarRating: (videoId, stars) => {
    const clamped = Math.min(5, Math.max(1, Math.round(stars)));
    const state = get();
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      localStarRatings: {
        ...state.userProfile.localStarRatings,
        [videoId]: clamped,
      },
    };
    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
    state.addToast({
      title: `Rated ${clamped} / 5 Stars (Simulated Historical Experience)`,
      description:
        'Saved in your local profile. Historical 2006–2009 star ratings are simulated locally.',
      variant: 'info',
    });
  },

  setLocalLikeDislike: (videoId, reaction) => {
    const state = get();
    const current = state.userProfile.localLikes[videoId];
    const nextLikes = { ...state.userProfile.localLikes };
    if (current === reaction) {
      delete nextLikes[videoId];
    } else {
      nextLikes[videoId] = reaction;
    }
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      localLikes: nextLikes,
    };
    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
  },

  addLocalComment: (videoId, text) => {
    const clean = text.trim().slice(0, 280);
    if (!clean) return;
    const state = get();
    const existing = state.localCommentsByVideo[videoId] ?? [];
    const newEntry = {
      id: `c-${Date.now()}`,
      author: 'TimeTraveler_Local',
      text: clean,
      dateLabel: `${state.currentYear} (Simulated Session Comment)`,
    };
    set({
      localCommentsByVideo: {
        ...state.localCommentsByVideo,
        [videoId]: [newEntry, ...existing],
      },
    });
  },

  clearSearchHistory: () => {
    const state = get();
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      searchHistory: [],
    };
    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
    state.addToast({
      title: 'Search History Cleared',
      variant: 'info',
    });
  },

  clearWatchHistory: () => {
    const state = get();
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      recentlyWatched: [],
      watchedVideoIds: [],
      watchDurationsSec: {},
    };
    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
    state.addToast({
      title: 'Watch History Cleared',
      variant: 'info',
    });
  },

  resetUserProfile: () => {
    const fresh = createDefaultProfile();
    fresh.lastSelectedYear = get().currentYear;
    saveProfileToLocalStorage(fresh);
    set({ userProfile: fresh });
    get().addToast({
      title: 'User Profile & Recommendation Weights Reset',
      description: 'All category affinities, history, and dismissed items have been cleared.',
      variant: 'warning',
    });
  },

  importUserProfileJson: (rawJson) => {
    if (!rawJson || rawJson.length > 100_000) {
      get().addToast({
        title: 'Import Rejected',
        description: 'Profile JSON payload is empty or exceeds the 100 KB safety limit.',
        variant: 'error',
      });
      return false;
    }
    try {
      const parsed = JSON.parse(rawJson);
      const { profile, recoveredFromCorruption } = validateAndSanitizeProfile(parsed);
      if (recoveredFromCorruption) {
        get().addToast({
          title: 'Invalid Profile Schema',
          description: 'JSON did not match UserProfile schema v2.',
          variant: 'error',
        });
        return false;
      }
      saveProfileToLocalStorage(profile);
      set({ userProfile: profile });
      get().addToast({
        title: 'Profile Imported Successfully',
        description: `Loaded ${Object.keys(profile.categoryScores).length} category affinities and ${profile.savedVideoIds.length} saved videos.`,
        variant: 'success',
      });
      return true;
    } catch {
      get().addToast({
        title: 'JSON Parse Error',
        description: 'Could not parse the provided profile JSON.',
        variant: 'error',
      });
      return false;
    }
  },

  setDiscoveryPreference: (ratio) => {
    const clamped = Math.min(0.5, Math.max(0.15, Number(ratio.toFixed(2))));
    const state = get();
    const updatedProfile: UserProfile = {
      ...state.userProfile,
      discoveryPreference: clamped,
    };
    saveProfileToLocalStorage(updatedProfile);
    set({ userProfile: updatedProfile });
  },

  setDiscoveryMode: (mode) => {
    set({ discoveryMode: mode });
    get().addToast({
      title: mode === 'historical' ? 'Historical Fidelity Mode' : 'Enhanced Accessibility Mode',
      description:
        mode === 'historical'
          ? 'Strict period layout widths and typography applied.'
          : 'Period colors preserved with modern fluid spacing and focus rings.',
      variant: 'info',
    });
  },

  setPolymerDarkTheme: (dark) => {
    set({ polymerDarkTheme: dark });
  },

  setPrefersReducedMotion: (reduced) => {
    set({ prefersReducedMotion: reduced });
  },

  setSelectedRegion: async (region) => {
    await get().fetchYearStream({ region });
  },

  setBackendConfig: async (url, enabled) => {
    const cleanUrl = url.trim().replace(/\/+$/, '') || 'http://localhost:4000';
    set({ backendBaseUrl: cleanUrl, useLiveBackend: enabled });
    clientResponseCache.clear();
    await get().fetchYearStream();
  },

  setDirectYoutubeApiKey: async (apiKey) => {
    const cleanKey = apiKey.trim();
    saveApiKeyToStorage(cleanKey);
    set({ directYoutubeApiKey: cleanKey });
    clientResponseCache.clear();
    await get().fetchYearStream();
    get().addToast({
      title: cleanKey
        ? 'API Anahtarı Kaydedildi ve Aktif Edildi ✓'
        : 'Yerleşik Doğrulanmış YouTube Arşivine Geçildi',
      description: cleanKey
        ? 'Anahtarınız tarayıcı hafızasına (localStorage) kalıcı olarak kaydedildi. Tüm yıllar canlı API üzerinden çekiliyor.'
        : 'Anahtar temizlendi; yerleşik 2006–2019 gerçek YouTube arşivi kullanılıyor.',
      variant: 'success',
    });
  },

  setPlayerMode: (mode, customId) => {
    set((state) => ({
      playbackState: {
        ...state.playbackState,
        playerMode: mode,
        customYoutubeId: customId !== undefined ? customId : state.playbackState.customYoutubeId,
      },
    }));
  },

  loadMoreYearVideos: async () => {
    const state = get();
    const yr = state.currentYear;
    const existingIds = new Set(state.videos.map((v) => v.id));

    // Try live public YouTube search first
    const liveMore = await fetchLivePublicYoutubeSearch({
      year: yr,
      query: state.searchQuery || 'classic viral',
      categoryId: state.selectedCategory,
      page: 2,
    });

    const newItems: Video[] = [];
    for (const v of liveMore) {
      if (!existingIds.has(v.id)) {
        newItems.push(v);
        existingIds.add(v.id);
      }
    }

    // If public search is blocked by sandbox/network, pull additional verified real YouTube videos from REAL_YOUTUBE_ARCHIVE_SEEDS
    if (newItems.length === 0) {
      for (const seed of REAL_YOUTUBE_ARCHIVE_SEEDS) {
        if (existingIds.has(seed.id)) continue;
        if (
          state.selectedCategory !== 'all' &&
          seed.categoryId !== state.selectedCategory
        ) {
          continue;
        }
        const sim = computeSimulatedStarRating(
          seed.id,
          seed.viewCount,
          seed.likeCount,
          seed.commentCount
        );
        newItems.push({
          id: seed.id,
          title: `${seed.title} (${yr} Discovery Stream)`,
          description: seed.description,
          channelId: seed.channelId,
          channelTitle: seed.channelTitle,
          publishedAt: `${yr}-08-19T16:00:00Z`,
          categoryId: seed.categoryId,
          thumbnailUrl: `https://i.ytimg.com/vi/${seed.id}/hqdefault.jpg`,
          viewCount: seed.viewCount,
          likeCount: seed.likeCount,
          commentCount: seed.commentCount,
          duration: seed.duration,
          durationSeconds: seed.durationSeconds,
          liveBroadcastContent: 'none',
          source: 'youtube-api',
          isMock: false,
          youtubeEmbedId: seed.id,
          historicalYear: yr,
          yearVerified: true,
          historicalPopularity: 'unknown-historical-rank',
          ratingSimulation: sim,
          ratingSimulationAvailable: sim !== null,
          regionOrigin: seed.regionOrigin,
          tags: seed.tags,
        });
        existingIds.add(seed.id);
        if (newItems.length >= 6) break;
      }
    }

    if (newItems.length > 0) {
      set({ videos: [...state.videos, ...newItems] });
      state.addToast({
        title: `Loaded +${newItems.length} Videos for ${yr}`,
        description: 'Added to your 70/30 temporal stream.',
        variant: 'success',
      });
    } else {
      state.addToast({
        title: 'All Available Archive Videos Loaded',
        description: 'Add a YouTube Data API v3 key in Settings for unlimited pagination.',
        variant: 'info',
      });
    }
  },
}));


// ============================================================================
// 8B. WEB AUDIO API RETRO SOUND SYNTHESIZER & TIME MACHINE WARP ENGINE
// ============================================================================

class RetroSoundEngine {
  private ctx: AudioContext | null = null;
  public enabled = true;

  private getContext(): AudioContext | null {
    if (!this.enabled || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public playTimeWarp(fromYear: number, toYear: number): void {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = toYear < 2010 ? 'sawtooth' : 'sine';
      const startFreq = fromYear < toYear ? 220 : 520;
      const endFreq = fromYear < toYear ? 580 : 180;
      osc.frequency.setValueAtTime(startFreq, now);
      osc.frequency.exponentialRampToValueAtTime(endFreq, now + 0.38);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.06, now + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.42);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.44);
    } catch {
      // Ignore audio block before gesture
    }
  }

  public playClick(eraGroup: EraConfig['eraGroup']): void {
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = eraGroup === 'classic-web' ? 'square' : 'triangle';
      osc.frequency.setValueAtTime(eraGroup === 'classic-web' ? 740 : 980, now);
      gain.gain.setValueAtTime(0.03, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.045);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.05);
    } catch {
      // Ignore
    }
  }
}

export const soundEngine = new RetroSoundEngine();

// ============================================================================
// 8. HELPER FORMATTERS & ICON RESOLVER
// ============================================================================

function formatNumber(n: number | null): string {
  if (n === null || n === undefined) return 'Unavailable';
  return n.toLocaleString('en-US');
}

function formatDurationSeconds(sec: number): string {
  const safe = Math.max(0, Math.round(sec));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

function formatUtcDateShort(iso: string): string {
  const ts = Date.parse(iso);
  if (Number.isNaN(ts)) return iso;
  const d = new Date(ts);
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${months[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
}

function CategoryIcon({ name, className = 'w-4 h-4' }: { name: string; className?: string }) {
  switch (name) {
    case 'Film':
      return <Film className={className} />;
    case 'Music':
      return <Music className={className} />;
    case 'Gamepad2':
      return <Gamepad2 className={className} />;
    case 'Cpu':
      return <Cpu className={className} />;
    case 'Laugh':
      return <Laugh className={className} />;
    case 'Users':
      return <Users className={className} />;
    case 'Tv':
      return <Tv className={className} />;
    case 'GraduationCap':
      return <GraduationCap className={className} />;
    case 'Trophy':
      return <Trophy className={className} />;
    default:
      return <Compass className={className} />;
  }
}

// ============================================================================
// 9. UI COMPONENTS: RETRO LOGO, RATING STARS, LIKE/DISLIKE BAR, SUBSCRIBE
// ============================================================================

export function RealityBadge({
  layer,
  compact = false,
}: {
  layer: RealityLayer;
  compact?: boolean;
}) {
  const styles: Record<RealityLayer, string> = {
    'Historical Reference': 'bg-amber-100 text-amber-900 border-amber-300',
    'Live YouTube Data': 'bg-emerald-100 text-emerald-900 border-emerald-300',
    'Simulated Historical Experience': 'bg-indigo-100 text-indigo-900 border-indigo-300',
    'Estimated Reconstruction': 'bg-slate-200 text-slate-800 border-slate-400',
  };
  return (
    <span
      className={`inline-flex items-center gap-1 border rounded font-sans ${
        compact ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-0.5 text-xs'
      } font-medium ${styles[layer]}`}
      title={`Reality Layer: ${layer}`}
    >
      <Sparkles className="w-2.5 h-2.5 shrink-0" />
      {layer}
    </span>
  );
}

export function RetroLogo({
  year,
  eraGroup,
  darkTheme,
  onClick,
}: {
  year: number;
  eraGroup: EraConfig['eraGroup'];
  darkTheme: boolean;
  onClick: () => void;
}) {
  // Typographic period-accurate reconstruction (Section 3.1 & 3.4)
  if (eraGroup === 'modern-polymer') {
    return (
      <button
        type="button"
        onClick={onClick}
        className="flex items-center gap-1.5 focus:outline-none group"
        aria-label={`Return to ${year} YouTube Home`}
      >
        <span className="inline-flex items-center justify-center w-8 h-5.5 rounded-md bg-[#FF0000] text-white shadow-sm">
          <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
        </span>
        <span
          className={`font-bold tracking-tight text-lg ${
            darkTheme ? 'text-white' : 'text-neutral-900'
          }`}
        >
          YouTube
        </span>
        <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-red-600/10 text-red-600 font-semibold">
          {year}
        </span>
      </button>
    );
  }

  if (eraGroup === 'classic-web') {
    return (
      <button
        type="button"
        onClick={onClick}
        className="flex flex-col items-start focus:outline-none group"
        aria-label={`Return to ${year} YouTube Home`}
      >
        <div className="flex items-center text-xl font-extrabold tracking-tight leading-none">
          <span className="text-neutral-900 px-0.5">You</span>
          <span
            className="text-white px-1.5 py-0.5 rounded-[5px] shadow-inner"
            style={{
              background: 'linear-gradient(180deg, #ef4444 0%, #b91c1c 100%)',
              border: '1px solid #7f1d1d',
            }}
          >
            Tube
          </span>
          <span className="ml-1.5 text-xs font-bold text-amber-800 bg-amber-100 border border-amber-300 px-1.5 py-0.5 rounded">
            {year}
          </span>
        </div>
        <span className="text-[10px] text-neutral-600 font-semibold tracking-wide mt-0.5">
          Broadcast Yourself™
        </span>
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-1 focus:outline-none"
      aria-label={`Return to ${year} YouTube Home`}
    >
      <span className="text-xl font-bold tracking-tight text-neutral-900">You</span>
      <span
        className="text-xl font-bold tracking-tight text-white px-1.5 py-0.2 rounded-[4px]"
        style={{
          background:
            eraGroup === 'transitional'
              ? 'linear-gradient(180deg, #dc2626 0%, #991b1b 100%)'
              : '#e62117',
        }}
      >
        Tube
      </span>
      <span className="ml-1 text-[11px] font-mono font-bold px-1.5 py-0.5 rounded bg-neutral-200 text-neutral-800">
        {year}
      </span>
    </button>
  );
}

export function RatingStars({
  videoId,
  simulation,
  interactive = false,
}: {
  videoId: string;
  simulation: RatingSimulationResult | null;
  interactive?: boolean;
}) {
  const localRating = useTimeMachineStore((s) => s.userProfile.localStarRatings[videoId]);
  const setLocalStarRating = useTimeMachineStore((s) => s.setLocalStarRating);

  if (!simulation) {
    return (
      <span className="text-[11px] text-neutral-500 italic">
        Rating unavailable (insufficient stats)
      </span>
    );
  }

  const displayStars = localRating ?? simulation.roundedHalfStars;

  return (
    <div className="inline-flex flex-wrap items-center gap-1.5">
      <div
        className="inline-flex items-center gap-0.5"
        role={interactive ? 'radiogroup' : undefined}
        aria-label={`Simulated 5-star rating: ${displayStars} out of 5 stars`}
      >
        {[1, 2, 3, 4, 5].map((starIdx) => {
          const filled = displayStars >= starIdx - 0.25;
          return interactive ? (
            <button
              key={starIdx}
              type="button"
              onClick={() => setLocalStarRating(videoId, starIdx)}
              className="p-0.5 hover:scale-110 transition-transform focus:outline-none"
              title={`Rate ${starIdx} star${starIdx > 1 ? 's' : ''} (Local Simulation)`}
            >
              <Star
                className={`w-4 h-4 ${
                  filled ? 'text-[#dd1111] fill-[#dd1111]' : 'text-neutral-300 fill-neutral-200'
                }`}
              />
            </button>
          ) : (
            <Star
              key={starIdx}
              className={`w-3.5 h-3.5 ${
                filled ? 'text-[#dd1111] fill-[#dd1111]' : 'text-neutral-300 fill-neutral-200'
              }`}
            />
          );
        })}
      </div>
      <span
        className="text-[11px] text-neutral-600 font-medium"
        title={simulation.methodologyNote}
      >
        {displayStars.toFixed(1)}★{' '}
        <span className="text-[10px] text-indigo-700 underline decoration-dotted">
          (Simulated rating)
        </span>
      </span>
    </div>
  );
}

export function LikeDislikeBar({
  videoId,
  likeCount,
  year,
}: {
  videoId: string;
  likeCount: number | null;
  year: number;
}) {
  const userReaction = useTimeMachineStore((s) => s.userProfile.localLikes[videoId]);
  const setLocalLikeDislike = useTimeMachineStore((s) => s.setLocalLikeDislike);

  const baseLikes = (likeCount ?? 120) + (userReaction === 'like' ? 1 : 0);
  // Deterministic simulated dislike estimate (since YouTube API removed public dislikes in Dec 2021)
  const simulatedDislikes = Math.max(
    2,
    Math.round(baseLikes * 0.045) + (userReaction === 'dislike' ? 1 : 0)
  );
  const total = Math.max(1, baseLikes + simulatedDislikes);
  const likePercent = Math.round((baseLikes / total) * 100);

  // 2010-2011 used green/red lightsaber bar; 2012-2016 used blue/gray; 2017-2019 used neutral/blue bar
  const barColor =
    year <= 2011 ? '#16a34a' : year <= 2016 ? '#167ac6' : '#065fd4';
  const trackColor = year <= 2011 ? '#dc2626' : '#d4d4d4';

  return (
    <div className="flex flex-col gap-1.5 min-w-[180px]">
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setLocalLikeDislike(videoId, 'like')}
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded border transition-colors ${
            userReaction === 'like'
              ? 'bg-blue-600 text-white border-blue-700'
              : 'bg-neutral-100 text-neutral-800 border-neutral-300 hover:bg-neutral-200'
          }`}
        >
          <ThumbsUp className="w-3.5 h-3.5" />
          <span>{formatNumber(baseLikes)}</span>
        </button>
        <button
          type="button"
          onClick={() => setLocalLikeDislike(videoId, 'dislike')}
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded border transition-colors ${
            userReaction === 'dislike'
              ? 'bg-red-600 text-white border-red-700'
              : 'bg-neutral-100 text-neutral-800 border-neutral-300 hover:bg-neutral-200'
          }`}
          title="Dislike count is a simulated reconstruction (YouTube API removed public dislikes in 2021)"
        >
          <ThumbsDown className="w-3.5 h-3.5" />
          <span>{formatNumber(simulatedDislikes)}</span>
        </button>
      </div>
      <div
        className="w-full h-1.5 rounded-full overflow-hidden"
        style={{ backgroundColor: trackColor }}
        title={`${likePercent}% Like ratio (Dislike portion is a simulated historical reconstruction)`}
      >
        <div
          className="h-full transition-all duration-300"
          style={{ width: `${likePercent}%`, backgroundColor: barColor }}
        />
      </div>
    </div>
  );
}

export function SubscribeControl({
  channelId,
  channelTitle,
  era,
}: {
  channelId: string;
  channelTitle: string;
  era: EraConfig;
}) {
  const isSubscribed = useTimeMachineStore((s) =>
    s.userProfile.subscribedChannelIds.includes(channelId)
  );
  const toggleSubscribeChannel = useTimeMachineStore((s) => s.toggleSubscribeChannel);

  if (era.buttonStyle === 'glossy-amber') {
    return (
      <button
        type="button"
        onClick={() => toggleSubscribeChannel(channelId, channelTitle)}
        className="px-3 py-1 text-xs font-bold rounded border shadow-sm transition-transform active:scale-95"
        style={{
          background: isSubscribed
            ? 'linear-gradient(180deg, #e5e7eb 0%, #d1d5db 100%)'
            : 'linear-gradient(180deg, #fde047 0%, #f59e0b 100%)',
          borderColor: isSubscribed ? '#9ca3af' : '#b45309',
          color: isSubscribed ? '#374151' : '#451a03',
        }}
      >
        {isSubscribed ? 'Subscribed ✓' : 'Subscribe'}
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={() => toggleSubscribeChannel(channelId, channelTitle)}
      className={`px-3.5 py-1.5 text-xs font-bold uppercase tracking-wide rounded transition-colors ${
        isSubscribed
          ? 'bg-neutral-200 text-neutral-800 border border-neutral-300'
          : 'text-white shadow-sm hover:opacity-95'
      }`}
      style={{
        backgroundColor: isSubscribed ? undefined : era.accentColor,
      }}
    >
      {isSubscribed ? 'Subscribed' : 'Subscribe'}
    </button>
  );
}

// ============================================================================
// 10. GLOBAL TIMELINE SLIDER & HEADER (Section 13 & 14)
// ============================================================================

export function TimelineSlider() {
  const currentYear = useTimeMachineStore((s) => s.currentYear);
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const setYear = useTimeMachineStore((s) => s.setYear);
  const jumpToRandomYear = useTimeMachineStore((s) => s.jumpToRandomYear);
  const discoveryMode = useTimeMachineStore((s) => s.discoveryMode);
  const setDiscoveryMode = useTimeMachineStore((s) => s.setDiscoveryMode);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);

  const [dockExpanded, setDockExpanded] = useState(true);
  const loadMoreYearVideos = useTimeMachineStore((s) => s.loadMoreYearVideos);

  if (!dockExpanded) {
    return (
      <div className="fixed bottom-3 right-4 z-40 flex items-center gap-1.5 bg-neutral-950/95 text-white px-3 py-2 rounded-full shadow-2xl border border-red-500/50">
        <button
          type="button"
          onClick={() => setYear(Math.max(2006, currentYear - 1))}
          disabled={currentYear <= 2006}
          className="p-1 rounded-full hover:bg-neutral-800 disabled:opacity-40"
          aria-label="Previous Year"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={() => setDockExpanded(true)}
          className="px-2 py-0.5 text-xs font-mono font-bold text-amber-300 flex items-center gap-1.5"
        >
          <Clock className="w-3.5 h-3.5 text-red-500" />
          <span>{currentYear} Time Machine ▲</span>
        </button>
        <button
          type="button"
          onClick={() => setYear(Math.min(2019, currentYear + 1))}
          disabled={currentYear >= 2019}
          className="p-1 rounded-full hover:bg-neutral-800 disabled:opacity-40"
          aria-label="Next Year"
        >
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <section
      aria-label="Temporal Time Machine Control Bar"
      className="fixed bottom-3 left-1/2 -translate-x-1/2 z-40 w-[96vw] max-w-5xl rounded-xl border border-neutral-700 bg-neutral-950/95 backdrop-blur-md text-white px-3.5 py-2.5 shadow-2xl"
    >
      <div className="max-w-7xl mx-auto flex flex-col gap-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-600 text-white text-xs font-bold tracking-wider uppercase">
              <Clock className="w-3.5 h-3.5" />
              Time Machine: {currentYear}
            </span>
            <span className="text-xs sm:text-sm font-semibold text-amber-300 truncate max-w-[260px] sm:max-w-md">
              {currentEra.eraLabel}
            </span>
            <span className="hidden md:inline-block text-[11px] px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 border border-neutral-700">
              Thumbnails: {currentEra.thumbnailAspectRatio} • Layout: {currentEra.maxContentWidth}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => jumpToRandomYear()}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-colors"
              title="Teleport to a random supported year (2006–2019)"
            >
              <Shuffle className="w-3.5 h-3.5" />
              <span>Take Me Back</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setDiscoveryMode(discoveryMode === 'historical' ? 'enhanced' : 'historical')
              }
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-medium"
              title="Toggle between strict Historical Mode and Enhanced Accessibility Mode"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>{discoveryMode === 'historical' ? 'Historical Mode' : 'Enhanced Mode'}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveView('compare')}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors"
              title="Compare two YouTube eras side by side (Önce / Sonra)"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Compare Eras</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveView('era-guide')}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 text-xs font-medium"
            >
              <Info className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">Era Guide</span>
            </button>

            <button
              type="button"
              onClick={() => loadMoreYearVideos()}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors"
              title={`Fetch more ${currentYear} videos from YouTube`}
            >
              <Download className="w-3.5 h-3.5" />
              <span>+More {currentYear} Videos</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveView('settings')}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition-colors"
              title="Configure Live YouTube Data API v3 Key or Express Backend"
            >
              <Radio className="w-3.5 h-3.5" />
              <span>YouTube API v3</span>
            </button>

            <button
              type="button"
              onClick={() => setDockExpanded(false)}
              className="px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-mono"
              title="Minimize Time Machine Bar so full screen is pure YouTube"
            >
              ▼ Hide
            </button>
          </div>
        </div>

        {/* Interactive Range Input + Individual Year Buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={currentYear <= 2006}
            onClick={() => setYear(currentYear - 1)}
            className="p-1 rounded bg-neutral-800 hover:bg-neutral-700 disabled:opacity-40"
            aria-label="Previous Year"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div className="flex-1 flex flex-col gap-1">
            <input
              type="range"
              min={2006}
              max={2019}
              step={1}
              value={currentYear}
              onChange={(e) => setYear(Number(e.target.value))}
              aria-label="Select YouTube Historical Year (2006 to 2019)"
              className="w-full accent-red-500 cursor-pointer h-1.5 bg-neutral-700 rounded-lg"
            />
            <div className="grid grid-cols-7 sm:grid-cols-14 gap-1 pt-0.5">
              {SUPPORTED_YEARS.map((yr) => {
                const isSelected = yr === currentYear;
                return (
                  <button
                    key={yr}
                    type="button"
                    onClick={() => setYear(yr)}
                    aria-pressed={isSelected}
                    className={`py-1 text-[11px] font-mono rounded transition-all ${
                      isSelected
                        ? 'bg-red-600 text-white font-bold shadow ring-1 ring-red-300'
                        : 'bg-neutral-800/90 text-neutral-300 hover:bg-neutral-700 hover:text-white'
                    }`}
                  >
                    {yr}
                  </button>
                );
              })}
            </div>
          </div>

          <button
            type="button"
            disabled={currentYear >= 2019}
            onClick={() => setYear(currentYear + 1)}
            className="p-1 rounded bg-neutral-800 hover:bg-neutral-700 disabled:opacity-40"
            aria-label="Next Year"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
}

export function GlobalHeader({
  onToggleMobileSidebar,
}: {
  onToggleMobileSidebar: () => void;
}) {
  const currentYear = useTimeMachineStore((s) => s.currentYear);
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const searchQuery = useTimeMachineStore((s) => s.searchQuery);
  const setSearchQuery = useTimeMachineStore((s) => s.setSearchQuery);
  const activeView = useTimeMachineStore((s) => s.activeView);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);
  const setCategory = useTimeMachineStore((s) => s.setCategory);
  const savedCount = useTimeMachineStore((s) => s.userProfile.savedVideoIds.length);
  const historyCount = useTimeMachineStore((s) => s.userProfile.recentlyWatched.length);
  const searchHistory = useTimeMachineStore((s) => s.userProfile.searchHistory);
  const clearSearchHistory = useTimeMachineStore((s) => s.clearSearchHistory);
  const polymerDarkTheme = useTimeMachineStore((s) => s.polymerDarkTheme);
  const setPolymerDarkTheme = useTimeMachineStore((s) => s.setPolymerDarkTheme);

  const [inputVal, setInputVal] = useState(searchQuery);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);

  useEffect(() => {
    setInputVal(searchQuery);
  }, [searchQuery]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSearchDropdown(false);
    setSearchQuery(inputVal);
  };

  const isPolymerDark = currentEra.eraGroup === 'modern-polymer' && polymerDarkTheme;

  // ==========================================================================
  // ERA 1: 2006–2009 CLASSIC YOUTUBE HEADER (Exact 1:1 Replica of 1000067164.jpg & 1000067167.jpg)
  // ==========================================================================
  if (currentEra.eraGroup === 'classic-web') {
    const activeTab =
      activeView === 'era-guide'
        ? 'community'
        : activeView === 'channel'
        ? 'channels'
        : 'videos';

    return (
      <header className="w-full bg-white pt-1.5 pb-1 select-none">
        <div
          className="mx-auto px-2"
          style={{ maxWidth: currentEra.maxContentWidth }}
        >
          {/* Top-Right Classic Utility Links: Sign Up | My Account | History | QuickList (0) | Help | Log In */}
          <div className="flex flex-wrap items-center justify-end gap-1.5 text-[11px] text-neutral-600 mb-1">
            <button
              type="button"
              onClick={() => setActiveView('profile')}
              className="text-[#0033cc] underline font-normal hover:text-red-700"
            >
              Sign Up
            </button>
            <span>|</span>
            <button
              type="button"
              onClick={() => setActiveView('profile')}
              className="text-[#0033cc] underline font-normal hover:text-red-700"
            >
              My Account
            </button>
            <span>|</span>
            <button
              type="button"
              onClick={() => setActiveView('history')}
              className="text-[#0033cc] underline font-normal hover:text-red-700"
            >
              History ({historyCount})
            </button>
            <span>|</span>
            <button
              type="button"
              onClick={() => setActiveView('saved')}
              className="text-[#0033cc] underline font-normal hover:text-red-700"
            >
              QuickList ({savedCount})
            </button>
            <span>|</span>
            <button
              type="button"
              onClick={() => setActiveView('era-guide')}
              className="text-[#0033cc] underline font-normal hover:text-red-700"
            >
              Help
            </button>
            <span>|</span>
            <button
              type="button"
              onClick={() => setActiveView('settings')}
              className="text-[#0033cc] underline font-normal hover:text-red-700"
            >
              Log In
            </button>
            <span>|</span>
            <button
              type="button"
              onClick={() => setActiveView('compare')}
              className="text-[#0033cc] underline font-bold hover:text-red-700 inline-flex items-center gap-0.5"
            >
              <span>Site:</span>
              <Globe className="w-3 h-3 text-emerald-700" />
            </button>
          </div>

          {/* Logo + 4 Glossy Beveled Folder Tabs (Videos, Categories, Channels, Community) + Upload */}
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div className="pb-1">
              <RetroLogo
                year={currentYear}
                eraGroup={currentEra.eraGroup}
                darkTheme={false}
                onClick={() => {
                  setCategory('all');
                  setSearchQuery('');
                  setActiveView('home');
                }}
              />
            </div>

            {/* 4 Classic Beveled Folder Tabs */}
            <nav aria-label="2006 YouTube Folder Tabs" className="flex items-end gap-1.5">
              {[
                { id: 'videos', label: 'Videos', action: () => { setCategory('all'); setActiveView('home'); } },
                { id: 'categories', label: 'Categories', action: () => { setCategory('10'); setActiveView('home'); } },
                { id: 'channels', label: 'Channels', action: () => { setActiveView('channel'); } },
                { id: 'community', label: 'Community', action: () => { setActiveView('era-guide'); } },
              ].map((tab) => {
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={tab.action}
                    className="px-4 sm:px-6 py-1.5 text-xs font-bold rounded-t-[5px] border border-b-0 transition-none"
                    style={
                      isActive
                        ? {
                            background: 'linear-gradient(180deg, #ffffff 0%, #dcdcdc 100%)',
                            borderColor: '#999999',
                            color: '#222222',
                          }
                        : {
                            background: 'linear-gradient(180deg, #e3ecfa 0%, #a5bce3 100%)',
                            borderColor: '#7a96c4',
                            color: '#0033cc',
                          }
                    }
                  >
                    {tab.label}
                  </button>
                );
              })}
            </nav>

            {/* Right Upload Link */}
            <div className="pb-1.5 hidden sm:flex items-center gap-1">
              <span className="w-4 h-4 rounded-full bg-neutral-500 text-white flex items-center justify-center text-[10px] font-bold">
                ↑
              </span>
              <button
                type="button"
                onClick={() => setActiveView('settings')}
                className="text-xs font-bold text-[#0033cc] underline"
              >
                Upload
              </button>
            </div>
          </div>

          {/* Rounded Gray Search Bar Strip with "powered by Google" on the right */}
          <div
            className="w-full px-3 py-1.5 rounded-[4px] border flex flex-wrap items-center justify-between gap-2 relative"
            style={{
              background: 'linear-gradient(180deg, #d8d8d8 0%, #efefef 100%)',
              borderColor: '#bcbcbc',
            }}
          >
            <div className="hidden md:block w-28" />

            <form
              onSubmit={handleSearchSubmit}
              className="flex items-center justify-center gap-1.5 flex-1 max-w-md mx-auto relative"
            >
              <label htmlFor="tm-global-search" className="sr-only">
                Search {currentYear} YouTube
              </label>
              <input
                id="tm-global-search"
                type="text"
                value={inputVal}
                onFocus={() => setShowSearchDropdown(true)}
                onBlur={() => setTimeout(() => setShowSearchDropdown(false), 180)}
                onChange={(e) => setInputVal(e.target.value)}
                placeholder=""
                className="w-40 sm:w-72 flex-1 max-w-[280px] px-2 py-1 text-xs bg-white text-black border border-[#7f9db9] shadow-inner focus:outline-none"
              />
              <button
                type="submit"
                className="px-3 py-0.5 text-xs font-bold text-neutral-900 border border-[#888888] rounded-[2px] shadow-sm active:translate-y-[1px]"
                style={{
                  background: 'linear-gradient(180deg, #ffffff 0%, #d4d4d4 100%)',
                }}
              >
                Search
              </button>

              {showSearchDropdown && searchHistory.length > 0 && (
                <div className="absolute left-0 right-0 top-full mt-1 z-30 bg-white border border-neutral-400 shadow-md p-1.5 text-xs text-neutral-900">
                  <div className="flex items-center justify-between pb-1 mb-1 border-b border-neutral-200">
                    <span className="font-bold text-[10px] text-neutral-500">Recent Searches</span>
                    <button
                      type="button"
                      onClick={() => clearSearchHistory()}
                      className="text-[10px] text-[#0033cc] underline"
                    >
                      Clear
                    </button>
                  </div>
                  {searchHistory.slice(0, 5).map((q) => (
                    <button
                      key={q}
                      type="button"
                      onMouseDown={() => {
                        setInputVal(q);
                        setSearchQuery(q);
                      }}
                      className="w-full text-left px-1.5 py-0.5 hover:bg-[#e3ecfa] text-[#0033cc] truncate block"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              )}
            </form>

            <div className="text-[11px] text-neutral-500 font-sans hidden sm:flex items-center gap-1">
              <span className="text-[9px] leading-none text-right">
                powered
                <br />
                by
              </span>
              <span className="font-serif font-bold text-sm tracking-tight text-neutral-500">
                Google
              </span>
            </div>
          </div>

          {/* 2006–2009 Classic Horizontal Category Sub-Navigation Links */}
          <div className="mt-1 px-2 py-1 bg-[#f3f3ee] border border-[#dcdcdc] rounded-[2px] flex flex-wrap items-center justify-center gap-x-2.5 gap-y-1 text-[11px]">
            {CATEGORIES.map((cat, idx) => {
              const isSelected = useTimeMachineStore.getState().selectedCategory === cat.id;
              return (
                <React.Fragment key={cat.id}>
                  {idx > 0 && <span className="text-neutral-400">•</span>}
                  <button
                    type="button"
                    onClick={() => {
                      setCategory(cat.id);
                      setActiveView('home');
                    }}
                    className={`${
                      isSelected
                        ? 'font-extrabold text-[#990000] underline'
                        : 'text-[#0033cc] hover:underline'
                    }`}
                  >
                    {cat.title}
                  </button>
                </React.Fragment>
              );
            })}
          </div>
        </div>
      </header>
    );
  }

  // ==========================================================================
  // ERA 2: 2010–2013 TRANSITIONAL / COSMIC PANDA HEADER (Matches 1000067165.jpg & 1000067168.jpg)
  // ==========================================================================
  if (currentEra.eraGroup === 'transitional') {
    return (
      <header
        className="w-full border-b select-none"
        style={{
          background: 'linear-gradient(180deg, #f9f9f9 0%, #ebebeb 100%)',
          borderColor: '#cccccc',
        }}
      >
        <div
          className="mx-auto px-3 py-2 flex flex-wrap items-center justify-between gap-3"
          style={{ maxWidth: currentEra.maxContentWidth }}
        >
          <div className="flex items-center gap-3 flex-1 min-w-[260px]">
            <RetroLogo
              year={currentYear}
              eraGroup={currentEra.eraGroup}
              darkTheme={false}
              onClick={() => {
                setCategory('all');
                setSearchQuery('');
                setActiveView('home');
              }}
            />

            <form
              onSubmit={handleSearchSubmit}
              className="flex items-center flex-1 max-w-md ml-2"
            >
              <label htmlFor="tm-global-search" className="sr-only">
                Search {currentYear} YouTube
              </label>
              <input
                id="tm-global-search"
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                placeholder={`Search ${currentYear} YouTube...`}
                className="w-full px-2.5 py-1 text-xs bg-white text-neutral-900 border border-[#b9b9b9] rounded-l-[2px] shadow-inner focus:outline-none"
              />
              <button
                type="submit"
                className="px-3 py-1 border border-l-0 border-[#b9b9b9] rounded-r-[2px] text-neutral-700 hover:text-black"
                style={{
                  background: 'linear-gradient(180deg, #f8f8f8 0%, #dddddd 100%)',
                }}
                aria-label="Search"
              >
                <Search className="w-3.5 h-3.5" />
              </button>
            </form>

            <div className="hidden md:flex items-center gap-2.5 text-xs text-neutral-700 font-medium ml-1">
              <button
                type="button"
                onClick={() => setActiveView('home')}
                className="hover:text-[#1c62b9] hover:underline"
              >
                Browse
              </button>
              <span className="text-neutral-300">|</span>
              <button
                type="button"
                onClick={() => setCategory('1')}
                className="hover:text-[#1c62b9] hover:underline"
              >
                Movies
              </button>
              <span className="text-neutral-300">|</span>
              <button
                type="button"
                onClick={() => setActiveView('settings')}
                className="hover:text-[#1c62b9] hover:underline"
              >
                Upload
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <button
              type="button"
              onClick={() => setActiveView('saved')}
              className="text-neutral-700 hover:underline"
            >
              Favorites ({savedCount})
            </button>
            <button
              type="button"
              onClick={() => setActiveView('history')}
              className="text-neutral-700 hover:underline"
            >
              History ({historyCount})
            </button>
            <button
              type="button"
              onClick={() => setActiveView('profile')}
              className="flex items-center gap-1.5 px-2 py-1 rounded border border-neutral-300 bg-white text-neutral-800 font-semibold shadow-sm"
            >
              <span className="w-4 h-4 rounded-sm bg-neutral-700 text-white text-[10px] flex items-center justify-center font-bold">
                YT
              </span>
              <span>TimeTraveler ▾</span>
            </button>
          </div>
        </div>
      </header>
    );
  }

  // ==========================================================================
  // ERA 3 & 4: 2014–2016 HITCHHIKER & 2017–2019 POLYMER HEADER
  //            (Exact 1:1 Replica of 1000067169.jpg & 1000067166.jpg)
  // ==========================================================================
  return (
    <header
      className="w-full border-b select-none sticky top-0 z-30"
      style={{
        backgroundColor: isPolymerDark ? '#202020' : '#ffffff',
        borderColor: isPolymerDark ? '#343434' : '#e8e8e8',
        height: currentEra.eraGroup === 'modern-polymer' ? '56px' : '50px',
      }}
    >
      <div className="h-full max-w-[1600px] mx-auto px-4 flex items-center justify-between gap-4">
        {/* Left: Hamburger + YouTube Logo */}
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={onToggleMobileSidebar}
            className="p-1.5 rounded hover:bg-neutral-200/50 text-neutral-600"
            aria-label="Toggle Guide Sidebar"
          >
            <Menu className="w-5 h-5" />
          </button>
          <RetroLogo
            year={currentYear}
            eraGroup={currentEra.eraGroup}
            darkTheme={isPolymerDark}
            onClick={() => {
              setCategory('all');
              setSearchQuery('');
              setActiveView('home');
            }}
          />
        </div>

        {/* Center: Wide Hitchhiker / Polymer Search Box */}
        <form
          onSubmit={handleSearchSubmit}
          className="flex-1 max-w-[580px] flex items-center"
        >
          <label htmlFor="tm-global-search" className="sr-only">
            Search {currentYear} YouTube
          </label>
          <div className="relative flex-1 flex items-center">
            <input
              id="tm-global-search"
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Search"
              className={`w-full px-3 py-1 text-sm border rounded-l-[2px] focus:outline-none focus:border-[#1c62b9] ${
                isPolymerDark
                  ? 'bg-[#121212] border-[#303030] text-white'
                  : 'bg-white border-[#cccccc] text-neutral-900 shadow-inner'
              }`}
              style={{ height: currentEra.eraGroup === 'modern-polymer' ? '32px' : '29px' }}
            />
          </div>
          <button
            type="submit"
            className={`px-5 border border-l-0 rounded-r-[2px] flex items-center justify-center ${
              isPolymerDark
                ? 'bg-[#323232] border-[#303030] text-neutral-300 hover:bg-[#3f3f3f]'
                : 'bg-[#f8f8f8] border-[#cccccc] text-neutral-600 hover:bg-[#f0f0f0]'
            }`}
            style={{ height: currentEra.eraGroup === 'modern-polymer' ? '32px' : '29px' }}
            aria-label="Search"
          >
            <Search className="w-4 h-4" />
          </button>
        </form>

        {/* Right: Upload, Apps/History, Notifications, Dark Mode (2017-2019), User Avatar */}
        <div className="flex items-center gap-2.5 text-xs">
          <button
            type="button"
            onClick={() => setActiveView('settings')}
            className="p-1.5 rounded hover:bg-neutral-200/50 text-neutral-600"
            title="YouTube API v3 & Upload Settings"
          >
            <Upload className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setActiveView('saved')}
            className="p-1.5 rounded hover:bg-neutral-200/50 text-neutral-600 relative"
            title={`Favorites (${savedCount})`}
          >
            <Bookmark className="w-4 h-4" />
            {savedCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#cc181e] text-white text-[9px] font-bold flex items-center justify-center">
                {savedCount}
              </span>
            )}
          </button>
          {currentEra.eraGroup === 'modern-polymer' && (
            <button
              type="button"
              onClick={() => setPolymerDarkTheme(!polymerDarkTheme)}
              className="px-2 py-1 rounded border border-neutral-400/50 text-[11px] font-semibold"
              title="Toggle 2017 Polymer Dark Theme"
            >
              {polymerDarkTheme ? '☀ Light' : '🌙 Dark'}
            </button>
          )}
          <button
            type="button"
            onClick={() => setActiveView('profile')}
            className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shadow-sm"
            title="70/30 Recommendation Profile"
          >
            TM
          </button>
        </div>
      </div>
    </header>
  );
}

// ============================================================================
// 11. SIDEBAR & CATEGORY NAVIGATION (Section 13.3 & 16.3)
// ============================================================================

export function Sidebar({
  mobileOpen,
  onCloseMobile,
}: {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}) {
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const selectedCategory = useTimeMachineStore((s) => s.selectedCategory);
  const setCategory = useTimeMachineStore((s) => s.setCategory);
  const activeView = useTimeMachineStore((s) => s.activeView);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);
  const openChannelPage = useTimeMachineStore((s) => s.openChannelPage);
  const videos = useTimeMachineStore((s) => s.videos);
  const polymerDarkTheme = useTimeMachineStore((s) => s.polymerDarkTheme);

  const isPolymerDark = currentEra.eraGroup === 'modern-polymer' && polymerDarkTheme;

  // Unique channels in the current year's stream to populate the authentic SUBSCRIPTIONS rail
  const eraChannels = useMemo(() => {
    const map = new Map<string, { id: string; title: string; count: number }>();
    for (const v of videos) {
      if (!map.has(v.channelId)) {
        map.set(v.channelId, { id: v.channelId, title: v.channelTitle, count: 1 });
      } else {
        map.get(v.channelId)!.count += 1;
      }
    }
    return Array.from(map.values()).slice(0, 9);
  }, [videos]);

  // 2010–2013 Transitional / Cosmic Panda Dark Charcoal Guide (Matches 1000067165.jpg)
  if (currentEra.eraGroup === 'transitional') {
    const darkGuideContent = (
      <div className="bg-[#2b2b2b] text-[#e0e0e0] rounded-[3px] p-2.5 flex flex-col gap-3 text-xs shadow">
        <button
          type="button"
          onClick={() => setActiveView('profile')}
          className="w-full py-1.5 px-3 rounded-[3px] font-bold text-white text-center shadow-sm flex items-center justify-center gap-1.5"
          style={{
            background: 'linear-gradient(180deg, #4b78cf 0%, #2750a3 100%)',
            border: '1px solid #1c3d7f',
          }}
        >
          <span className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center text-xs">
            +
          </span>
          <span>Add channels</span>
        </button>

        {/* User Mini Box */}
        <div className="bg-[#1f1f1f] p-2 rounded-[2px] border border-[#3a3a3a] flex gap-2.5">
          <div className="w-14 h-14 bg-gradient-to-br from-amber-700 to-red-900 rounded-[2px] flex items-center justify-center font-extrabold text-white text-sm shrink-0">
            {currentEra.year}
          </div>
          <div className="flex flex-col gap-0.5 text-[11px] text-[#cccccc]">
            <button
              type="button"
              onClick={() => setActiveView('profile')}
              className="text-left font-bold text-white hover:underline"
            >
              My channel ›
            </button>
            <button
              type="button"
              onClick={() => {
                setCategory('all');
                setActiveView('home');
              }}
              className="text-left hover:text-white"
            >
              Videos
            </button>
            <button
              type="button"
              onClick={() => setActiveView('saved')}
              className="text-left hover:text-white"
            >
              Likes & Favorites
            </button>
            <button
              type="button"
              onClick={() => setActiveView('history')}
              className="text-left hover:text-white"
            >
              History
            </button>
          </div>
        </div>

        {/* Subscriptions List */}
        <div>
          <div className="px-1.5 py-1 text-[11px] font-bold uppercase tracking-wider text-[#aaaaaa] border-b border-[#3d3d3d] mb-1 flex items-center gap-1.5">
            <Menu className="w-3.5 h-3.5" />
            <span>Subscriptions</span>
          </div>
          <ul className="flex flex-col gap-0.5">
            {eraChannels.map((ch) => (
              <li key={ch.id}>
                <button
                  type="button"
                  onClick={() => {
                    openChannelPage(ch.id);
                    onCloseMobile();
                  }}
                  className="w-full px-1.5 py-1 rounded hover:bg-[#3a3a3a] flex items-center justify-between text-left text-[11px]"
                >
                  <span className="flex items-center gap-2 truncate">
                    <span className="w-5 h-5 rounded-[2px] bg-[#cc181e] text-white font-bold text-[9px] flex items-center justify-center shrink-0">
                      {ch.title.slice(0, 2).toUpperCase()}
                    </span>
                    <span className="truncate text-[#dddddd]">{ch.title}</span>
                  </span>
                  <span className="text-[10px] text-[#888888]">{ch.count}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Categories Filter */}
        <div>
          <div className="px-1.5 py-1 text-[11px] font-bold uppercase tracking-wider text-[#aaaaaa] border-b border-[#3d3d3d] mb-1">
            Categories ({currentEra.year})
          </div>
          <ul className="flex flex-col gap-0.5">
            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <li key={cat.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setCategory(cat.id);
                      onCloseMobile();
                    }}
                    className={`w-full px-2 py-1 rounded text-left text-[11px] flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#cc181e] text-white font-bold'
                        : 'text-[#cccccc] hover:bg-[#3a3a3a]'
                    }`}
                  >
                    <span className="truncate">{cat.title}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    );

    return (
      <>
        <aside className="hidden md:block w-52 shrink-0">{darkGuideContent}</aside>
        {mobileOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <div className="fixed inset-0 bg-black/50" onClick={onCloseMobile} />
            <div className="relative z-10 w-64 bg-[#2b2b2b] h-full overflow-y-auto p-2">
              {darkGuideContent}
            </div>
          </div>
        )}
      </>
    );
  }

  // 2014–2019 HITCHHIKER & POLYMER LEFT GUIDE SIDEBAR (Exact Replica of 1000067169.jpg & 1000067166.jpg)
  const isHitchhiker = currentEra.eraGroup === 'material-modernization';
  const guideContent = (
    <div
      className="flex flex-col text-xs select-none h-full py-2"
      style={{
        backgroundColor: isPolymerDark ? '#212121' : '#ffffff',
        color: isPolymerDark ? '#ffffff' : '#222222',
        borderRight: isPolymerDark ? '1px solid #343434' : '1px solid #e8e8e8',
      }}
    >
      {/* Primary Section: Home, My Channel, Trending, Subscriptions */}
      <div className="px-2 pb-2.5 border-b border-neutral-200/70">
        {[
          {
            id: 'home',
            label: 'Home',
            active: activeView === 'home' && selectedCategory === 'all',
            onClick: () => {
              setCategory('all');
              setActiveView('home');
              onCloseMobile();
            },
          },
          {
            id: 'channel',
            label: 'My Channel',
            active: activeView === 'profile',
            onClick: () => {
              setActiveView('profile');
              onCloseMobile();
            },
          },
          {
            id: 'trending',
            label: 'Trending',
            active: selectedCategory === '10',
            onClick: () => {
              setCategory('10');
              setActiveView('home');
              onCloseMobile();
            },
          },
          {
            id: 'subs',
            label: 'Subscriptions',
            active: activeView === 'channel',
            onClick: () => {
              if (eraChannels[0]) openChannelPage(eraChannels[0].id);
              onCloseMobile();
            },
          },
        ].map((nav) => (
          <button
            key={nav.id}
            type="button"
            onClick={nav.onClick}
            className={`w-full px-3 py-1.5 flex items-center gap-3 text-left transition-colors ${
              nav.active
                ? isHitchhiker
                  ? 'bg-[#cc181e] text-white font-bold'
                  : isPolymerDark
                  ? 'bg-[#383838] text-white font-bold'
                  : 'bg-[#e5e5e5] text-[#0a0a0a] font-bold'
                : 'hover:bg-neutral-100 dark:hover:bg-neutral-800'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                nav.active
                  ? isHitchhiker
                    ? 'bg-white'
                    : 'bg-[#ff0000]'
                  : 'bg-neutral-400'
              }`}
            />
            <span>{nav.label}</span>
          </button>
        ))}
      </div>

      {/* LIBRARY Section */}
      <div className="px-2 py-2.5 border-b border-neutral-200/70">
        <div
          className="px-3 pb-1 text-[11px] font-bold uppercase tracking-wider"
          style={{ color: isHitchhiker ? '#cc181e' : '#606060' }}
        >
          LIBRARY
        </div>
        <button
          type="button"
          onClick={() => {
            setActiveView('history');
            onCloseMobile();
          }}
          className="w-full px-3 py-1.5 flex items-center gap-3 text-left hover:bg-neutral-100"
        >
          <Clock className="w-3.5 h-3.5 text-neutral-500" />
          <span>History</span>
        </button>
        <button
          type="button"
          onClick={() => {
            setActiveView('saved');
            onCloseMobile();
          }}
          className="w-full px-3 py-1.5 flex items-center gap-3 text-left hover:bg-neutral-100"
        >
          <Bookmark className="w-3.5 h-3.5 text-neutral-500" />
          <span>Favorites</span>
        </button>
        <button
          type="button"
          onClick={() => {
            setActiveView('compare');
            onCloseMobile();
          }}
          className="w-full px-3 py-1.5 flex items-center gap-3 text-left hover:bg-neutral-100"
        >
          <Sparkles className="w-3.5 h-3.5 text-neutral-500" />
          <span>Compare Eras</span>
        </button>
      </div>

      {/* SUBSCRIPTIONS Section (Matches 1000067169.jpg & 1000067166.jpg) */}
      <div className="px-2 py-2.5 border-b border-neutral-200/70">
        <div
          className="px-3 pb-1.5 text-[11px] font-bold uppercase tracking-wider"
          style={{ color: isHitchhiker ? '#cc181e' : '#606060' }}
        >
          SUBSCRIPTIONS
        </div>
        <ul className="flex flex-col gap-0.5">
          {eraChannels.map((ch) => (
            <li key={ch.id}>
              <button
                type="button"
                onClick={() => {
                  openChannelPage(ch.id);
                  onCloseMobile();
                }}
                className="w-full px-3 py-1 flex items-center justify-between text-left hover:bg-neutral-100"
              >
                <span className="flex items-center gap-2.5 truncate">
                  <span
                    className={`w-5 h-5 text-white font-bold text-[9px] flex items-center justify-center shrink-0 ${
                      isHitchhiker ? 'rounded-[2px] bg-[#cc181e]' : 'rounded-full bg-[#ff0000]'
                    }`}
                  >
                    {ch.title.slice(0, 2).toUpperCase()}
                  </span>
                  <span className="truncate">{ch.title}</span>
                </span>
                <span className="text-[10px] text-neutral-400">{ch.count}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* BROWSE CATEGORIES */}
      <div className="px-2 py-2.5">
        <div className="px-3 pb-1 text-[11px] font-bold uppercase tracking-wider text-neutral-500">
          CATEGORIES ({currentEra.year})
        </div>
        <ul className="flex flex-col gap-0.5">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            const pts = useTimeMachineStore.getState().userProfile.categoryScores[cat.id] ?? 0;
            return (
              <li key={cat.id}>
                <button
                  type="button"
                  onClick={() => {
                    setCategory(cat.id);
                    onCloseMobile();
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 text-xs rounded transition-colors text-left ${
                    isSelected
                      ? 'font-bold text-white'
                      : 'hover:bg-neutral-200/60 text-neutral-800'
                  }`}
                  style={{
                    backgroundColor: isSelected ? currentEra.accentColor : undefined,
                  }}
                >
                  <span className="flex items-center gap-2 truncate">
                    <CategoryIcon name={cat.iconName} className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate">{cat.title}</span>
                  </span>
                  {cat.id !== 'all' && pts > 0 && (
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                        isSelected
                          ? 'bg-black/25 text-white'
                          : 'bg-amber-100 text-amber-900 font-semibold'
                      }`}
                    >
                      +{pts}
                    </span>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden md:block w-56 shrink-0">{guideContent}</aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div className="fixed inset-0 bg-black/50" onClick={onCloseMobile} />
          <div className="relative z-10 w-64 bg-white h-full overflow-y-auto">
            {guideContent}
          </div>
        </div>
      )}
    </>
  );
}

// ============================================================================
// 12. VIDEO CARD & VIDEO GRID (Section 16.2)
// ============================================================================

export function VideoCard({
  scoredItem,
  era,
}: {
  scoredItem: ScoredVideoCard;
  era: EraConfig;
}) {
  const { video } = scoredItem;
  const openVideoDetail = useTimeMachineStore((s) => s.openVideoDetail);
  const openChannelPage = useTimeMachineStore((s) => s.openChannelPage);
  const toggleSaveVideo = useTimeMachineStore((s) => s.toggleSaveVideo);
  const isSaved = useTimeMachineStore((s) =>
    s.userProfile.savedVideoIds.includes(video.id)
  );
  const polymerDarkTheme = useTimeMachineStore((s) => s.polymerDarkTheme);
  const isPolymerDark = era.eraGroup === 'modern-polymer' && polymerDarkTheme;

  const [imgError, setImgError] = useState(false);
  const fallbackThumb = useMemo(
    () => buildSvgFallbackThumbnail(video.historicalYear, video.categoryId, video.title),
    [video.historicalYear, video.categoryId, video.title]
  );

  const isHitchhiker = era.eraGroup === 'material-modernization';
  const isPolymer = era.eraGroup === 'modern-polymer';
  const isClassic = era.eraGroup === 'classic-web';

  return (
    <article
      className="flex flex-col group select-none"
      style={{
        backgroundColor:
          isPolymer || isHitchhiker ? 'transparent' : era.surfaceColor,
        border: isClassic ? `1px solid ${era.borderColor}` : 'none',
        padding: isClassic ? '6px' : '0px',
      }}
    >
      {/* Thumbnail Frame */}
      <div
        onClick={() => openVideoDetail(video)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            openVideoDetail(video);
          }
        }}
        role="button"
        tabIndex={0}
        aria-label={`Watch ${video.title} (${video.historicalYear})`}
        className="relative w-full overflow-hidden bg-black cursor-pointer"
        style={{
          aspectRatio: era.thumbnailAspectRatio === '4/3' ? '4 / 3' : '16 / 9',
          border: isClassic ? '1px solid #777777' : 'none',
        }}
      >
        <img
          src={imgError || !video.thumbnailUrl ? fallbackThumb : video.thumbnailUrl}
          alt={video.title}
          loading="lazy"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover group-hover:opacity-95 transition-opacity"
        />

        {/* Hover Watch Later / QuickList Button in top-right (just like authentic YouTube) */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleSaveVideo(video);
          }}
          title={isSaved ? 'Saved in QuickList / Watch Later' : 'Add to Watch Later / QuickList'}
          className={`absolute top-1.5 right-1.5 w-6 h-6 rounded-[2px] bg-black/80 text-white flex items-center justify-center transition-opacity ${
            isSaved ? 'opacity-100 text-amber-400' : 'opacity-0 group-hover:opacity-100'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
        </button>

        {/* Bottom-Right Duration Badge */}
        <span className="absolute bottom-1 right-1 px-1 py-0.2 text-[11px] font-sans font-bold bg-black/85 text-white rounded-[2px] leading-tight">
          {formatDurationSeconds(video.durationSeconds)}
        </span>
      </div>

      {/* Metadata Below Thumbnail */}
      <div className="mt-2 flex items-start gap-2.5">
        {isPolymer && (
          <button
            type="button"
            onClick={() => openChannelPage(video.channelId)}
            className="w-9 h-9 rounded-full shrink-0 flex items-center justify-center font-bold text-xs text-white mt-0.5"
            style={{ backgroundColor: '#cc0000' }}
            title={video.channelTitle}
          >
            {video.channelTitle.slice(0, 2).toUpperCase()}
          </button>
        )}

        <div className="flex-1 min-w-0">
          <button
            type="button"
            onClick={() => openVideoDetail(video)}
            className={`text-left font-bold leading-snug line-clamp-2 ${
              isClassic || isHitchhiker ? 'hover:underline' : ''
            }`}
            style={{
              color: isClassic
                ? '#0033cc'
                : isHitchhiker
                ? '#167ac6'
                : isPolymerDark
                ? '#ffffff'
                : '#0a0a0a',
              fontSize: isPolymer ? '14px' : '13px',
              textDecoration: isClassic ? 'underline' : 'none',
            }}
          >
            {video.title}
          </button>

          <div className="mt-0.5 flex items-center gap-1 text-[11px] text-[#767676]">
            {isClassic && <span>From: </span>}
            <button
              type="button"
              onClick={() => openChannelPage(video.channelId)}
              className={`truncate hover:underline ${
                isClassic ? 'text-[#0033cc] underline font-semibold' : 'text-[#606060]'
              }`}
            >
              {video.channelTitle}
            </button>
            {(isHitchhiker || isPolymer) && (
              <span
                className="inline-flex items-center justify-center w-3 h-3 rounded-full bg-neutral-400 text-white text-[8px] font-bold shrink-0"
                title="Verified Creator"
              >
                ✓
              </span>
            )}
          </div>

          <div className="text-[11px] text-[#767676]">
            {isClassic ? (
              <>
                <div>Views: {formatNumber(video.viewCount)}</div>
                <div className="mt-0.5">
                  <RatingStars videoId={video.id} simulation={video.ratingSimulation} />
                </div>
              </>
            ) : (
              <span>
                {formatNumber(video.viewCount)} views • {formatUtcDateShort(video.publishedAt)}
              </span>
            )}
          </div>
        </div>
      </div>
    </article>
  );
}

// ============================================================================
// 13. VIDEO PLAYER (YOUTUBE IFRAME API + RETRO PLAYER SIMULATOR) (Section 11)
// ============================================================================

export function VideoPlayer({
  video,
  era,
}: {
  video: Video;
  era: EraConfig;
}) {
  const playbackState = useTimeMachineStore((s) => s.playbackState);
  const setPlayerMode = useTimeMachineStore((s) => s.setPlayerMode);
  const recordWatchProgress = useTimeMachineStore((s) => s.recordWatchProgress);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [customEmbedInput, setCustomEmbedInput] = useState(playbackState.customYoutubeId);
  const playerContainerRef = useRef<HTMLDivElement>(null);

  const totalDuration = Math.max(30, video.durationSeconds || 240);

  // Reset playback state cleanly when switching videos and start tracking watch time in youtube-iframe mode (Section 11.1 & 9.3)
  useEffect(() => {
    setIsPlaying(playbackState.playerMode === 'youtube-iframe');
    setCurrentTime(0);
  }, [video.id, playbackState.playerMode]);

  // Real watch-time signal emitter (ticks every 1s only while actively playing) (Section 9.3)
  useEffect(() => {
    if (!isPlaying) return undefined;
    const timer = window.setInterval(() => {
      setCurrentTime((prev) => {
        if (prev + 1 >= totalDuration) {
          setIsPlaying(false);
          return totalDuration;
        }
        return prev + 1;
      });
      recordWatchProgress(video.id, 1);
    }, 1000);
    return () => window.clearInterval(timer);
  }, [isPlaying, totalDuration, video.id, recordWatchProgress]);

  const handleToggleFullscreen = () => {
    const el = playerContainerRef.current;
    if (!el) return;
    if (!document.fullscreenElement && el.requestFullscreen) {
      el.requestFullscreen().catch(() => {});
    } else if (document.fullscreenElement && document.exitFullscreen) {
      document.exitFullscreen().catch(() => {});
    }
  };

  const progressPercent = Math.min(100, Math.round((currentTime / totalDuration) * 100));

  return (
    <div
      ref={playerContainerRef}
      className="w-full flex flex-col bg-black rounded overflow-hidden border border-neutral-800 shadow-lg"
    >
      {/* Top Mode Switcher Bar inside Player Frame */}
      <div className="bg-neutral-950 text-neutral-300 px-3 py-1.5 text-[11px] flex flex-wrap items-center justify-between gap-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <span className="font-mono text-amber-400 font-bold">
            [{era.year} PLAYER ENGINE]
          </span>
          <span>
            {era.year <= 2009
              ? 'Flash Player 9 / 4:3 & Widescreen Portal Skin'
              : era.year <= 2013
              ? 'ActionScript 3 Dark Red Scrubber Skin'
              : 'HTML5 Transparent Scrubber Skin'}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setPlayerMode('retro-simulator')}
            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
              playbackState.playerMode === 'retro-simulator'
                ? 'bg-red-600 text-white'
                : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
            }`}
          >
            Period Simulator
          </button>
          <button
            type="button"
            onClick={() => setPlayerMode('youtube-iframe')}
            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
              playbackState.playerMode === 'youtube-iframe'
                ? 'bg-red-600 text-white'
                : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
            }`}
          >
            YouTube IFrame API
          </button>
        </div>
      </div>

      {playbackState.playerMode === 'youtube-iframe' ? (
        <div className="w-full bg-black flex flex-col">
          <div
            className="relative w-full mx-auto"
            style={{
              aspectRatio: era.thumbnailAspectRatio === '4/3' ? '4 / 3' : '16 / 9',
              maxHeight: '480px',
            }}
          >
            <iframe
              key={video.youtubeEmbedId || video.id}
              title={`YouTube IFrame Player - ${video.title}`}
              src={`https://www.youtube-nocookie.com/embed/${encodeURIComponent(
                video.youtubeEmbedId || video.id || playbackState.customYoutubeId || 'dMH0bHeiRNg'
              )}?autoplay=1&rel=0&modestbranding=1`}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
          <div className="bg-neutral-900 p-2.5 text-xs text-neutral-300 flex flex-wrap items-center justify-between gap-2 border-t border-neutral-800">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1 text-emerald-400 font-bold">
                ● Live YouTube Embed (<code className="text-amber-300">{video.youtubeEmbedId || video.id}</code>)
              </span>
              <a
                href={`https://www.youtube.com/watch?v=${encodeURIComponent(video.youtubeEmbedId || video.id)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-700 text-sky-300 font-semibold"
              >
                <span>Open on YouTube.com</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <div className="flex items-center gap-1.5">
              <input
                type="text"
                value={customEmbedInput}
                onChange={(e) => setCustomEmbedInput(e.target.value)}
                placeholder="Any 11-char YouTube ID"
                className="px-2 py-1 text-xs rounded bg-neutral-800 border border-neutral-700 text-white w-36"
              />
              <button
                type="button"
                onClick={() =>
                  setPlayerMode('youtube-iframe', customEmbedInput.trim() || video.id)
                }
                className="px-2.5 py-1 rounded bg-red-600 text-white font-bold text-xs"
              >
                Load ID
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Interactive Retro Player Simulator with Real Watch-Time Signal Tracking */
        <div className="w-full flex flex-col">
          <div
            onClick={() => setIsPlaying(!isPlaying)}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                setIsPlaying(!isPlaying);
              }
            }}
            aria-label={isPlaying ? 'Pause simulated playback' : 'Start simulated playback'}
            className="relative w-full bg-neutral-950 overflow-hidden cursor-pointer select-none flex items-center justify-center"
            style={{
              aspectRatio: era.thumbnailAspectRatio === '4/3' ? '4 / 3' : '16 / 9',
              maxHeight: '460px',
            }}
          >
            <img
              src={video.thumbnailUrl}
              alt={video.title}
              className={`w-full h-full object-cover transition-all duration-500 ${
                isPlaying ? 'scale-105 brightness-50' : 'brightness-75'
              }`}
            />
            {isPlaying && (
              <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 bg-gradient-to-t from-black/80 via-black/20 to-black/60">
                <div className="flex items-center justify-between text-[11px] font-mono text-emerald-300">
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/70 border border-emerald-500/40">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                    LIVE STREAMING ARCHIVE FRAME ({era.year})
                  </span>
                  <span className="px-2 py-0.5 rounded bg-black/70 text-amber-300">
                    {era.year <= 2008 ? 'FLV 240p • 24fps' : era.year <= 2013 ? 'H.264 720p HD' : 'VP9 1080p60'}
                  </span>
                </div>

                {/* Animated Audio-Visual Equalizer & Telemetry Bars */}
                <div className="my-auto flex items-end justify-center gap-1.5 h-24 px-6">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15].map((barIdx) => {
                    const phase = ((currentTime * 7 + barIdx * 13) % 100) / 100;
                    const heightPct = 22 + Math.round(Math.abs(Math.sin(currentTime * 0.9 + barIdx * 0.6)) * 75);
                    return (
                      <div
                        key={barIdx}
                        className="w-2.5 sm:w-3 rounded-t transition-all duration-300"
                        style={{
                          height: `${heightPct}%`,
                          background:
                            era.eraGroup === 'classic-web'
                              ? 'linear-gradient(180deg, #fde047 0%, #ef4444 100%)'
                              : 'linear-gradient(180deg, #38bdf8 0%, #ef4444 100%)',
                          opacity: 0.75 + phase * 0.25,
                        }}
                      />
                    );
                  })}
                </div>

                <div className="flex items-center justify-between text-xs font-mono text-white/90 bg-black/60 px-3 py-1.5 rounded border border-white/15">
                  <span className="truncate">{video.channelTitle} • {video.title}</span>
                  <span className="text-amber-300 shrink-0 ml-2">+{currentTime}s Watch Affinity</span>
                </div>
              </div>
            )}

            {/* Vintage Scanline / CRT Overlay in 2006–2009 */}
            {era.eraGroup === 'classic-web' && (
              <div
                className="absolute inset-0 pointer-events-none opacity-20"
                style={{
                  backgroundImage:
                    'repeating-linear-gradient(0deg, rgba(0,0,0,0.35), rgba(0,0,0,0.35) 1px, transparent 1px, transparent 3px)',
                }}
              />
            )}

            {/* Center Play/Pause Overlay */}
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/30 p-4 text-center">
              <div
                className={`w-16 h-12 rounded-lg flex items-center justify-center shadow-xl transition-transform ${
                  isPlaying ? 'bg-black/60 scale-90' : 'bg-red-600/95 hover:scale-105'
                }`}
              >
                {isPlaying ? (
                  <Pause className="w-7 h-7 text-white" />
                ) : (
                  <Play className="w-7 h-7 text-white fill-current ml-0.5" />
                )}
              </div>
              <span className="mt-2 px-2.5 py-1 rounded bg-black/75 text-white text-xs font-medium max-w-md truncate">
                {isPlaying
                  ? `Playing (${formatDurationSeconds(currentTime)} / ${formatDurationSeconds(
                      totalDuration
                    )}) — Recording Watch-Time Affinity...`
                  : 'Click to Play in Period Player Simulator'}
              </span>
            </div>

            {/* 2006 Early Watermark Badge */}
            {era.year === 2006 && (
              <div className="absolute bottom-3 right-3 px-2 py-0.5 bg-white/80 text-neutral-900 font-extrabold text-xs rounded shadow">
                YouTube 2006
              </div>
            )}
          </div>

          {/* Period-Accurate Control Bar */}
          <div
            className="px-3 py-2 flex flex-col gap-1.5 border-t"
            style={
              era.eraGroup === 'classic-web'
                ? {
                    background: 'linear-gradient(180deg, #e5e7eb 0%, #9ca3af 100%)',
                    borderColor: '#6b7280',
                    color: '#111827',
                  }
                : {
                    backgroundColor: '#181818',
                    borderColor: '#2d2d2d',
                    color: '#f3f4f6',
                  }
            }
          >
            {/* Interactive Progress Scrubber */}
            <div className="flex items-center gap-2">
              <input
                type="range"
                min={0}
                max={totalDuration}
                value={currentTime}
                onChange={(e) => setCurrentTime(Number(e.target.value))}
                aria-label="Seek playback position"
                className="w-full h-1.5 accent-red-600 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-1 rounded hover:bg-black/10"
                  aria-label={isPlaying ? 'Pause' : 'Play'}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>

                <button
                  type="button"
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1 rounded hover:bg-black/10"
                  aria-label={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>

                <span className="font-mono text-[11px]">
                  {formatDurationSeconds(currentTime)} / {formatDurationSeconds(totalDuration)} (
                  {progressPercent}%)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-black/20">
                  {era.year <= 2007 ? '320×240 FLV' : era.year <= 2009 ? '480p / 720p HD' : '1080p HD'}
                </span>
                <button
                  type="button"
                  onClick={handleToggleFullscreen}
                  className="p-1 rounded hover:bg-black/10"
                  aria-label="Toggle Fullscreen"
                >
                  <Maximize2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// 14. VIDEO DETAIL PAGE & ERA-SPECIFIC WATCH LAYOUTS (Section 11.2 & 11.3)
// ============================================================================

export function VideoDetailPage() {
  const currentVideo = useTimeMachineStore((s) => s.currentVideo);
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const videos = useTimeMachineStore((s) => s.videos);
  const userProfile = useTimeMachineStore((s) => s.userProfile);
  const openVideoDetail = useTimeMachineStore((s) => s.openVideoDetail);
  const openChannelPage = useTimeMachineStore((s) => s.openChannelPage);
  const toggleSaveVideo = useTimeMachineStore((s) => s.toggleSaveVideo);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);
  const localComments = useTimeMachineStore(
    (s) => (currentVideo ? s.localCommentsByVideo[currentVideo.id] ?? [] : [])
  );
  const addLocalComment = useTimeMachineStore((s) => s.addLocalComment);

  const [commentInput, setCommentInput] = useState('');
  const [copiedEmbed, setCopiedEmbed] = useState(false);

  if (!currentVideo) {
    return (
      <div className="p-6 border rounded bg-white text-center">
        <p className="text-sm text-neutral-600 mb-3">No active video selected.</p>
        <button
          type="button"
          onClick={() => setActiveView('home')}
          className="px-4 py-1.5 rounded bg-red-600 text-white text-xs font-bold"
        >
          Return to {currentEra.year} Feed
        </button>
      </div>
    );
  }

  const isSaved = userProfile.savedVideoIds.includes(currentVideo.id);
  const relatedScored = computeRecommendedFeed(
    videos.filter((v) => v.id !== currentVideo.id),
    userProfile,
    currentEra.recommendationProfile,
    currentEra.year
  );

  const handleCopyEmbed = () => {
    const code = `<object width="425" height="350"><param name="movie" value="https://www.youtube.com/v/${currentVideo.id}"></param></object>`;
    try {
      navigator.clipboard?.writeText(code);
    } catch {
      // Fallback
    }
    setCopiedEmbed(true);
    setTimeout(() => setCopiedEmbed(false), 2000);
  };

  const isCosmicPanda = currentEra.playbackPageLayout === 'cosmic-dark-stage';
  const isClassicRightMeta = currentEra.playbackPageLayout === 'classic-right-meta';

  return (
    <div className="flex flex-col gap-4">
      {/* Top Breadcrumb Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <button
          type="button"
          onClick={() => setActiveView('home')}
          className="inline-flex items-center gap-1 font-bold hover:underline"
          style={{ color: currentEra.linkColor }}
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to {currentEra.year} Home Feed</span>
        </button>
        <div className="flex items-center gap-2">
          <RealityBadge
            layer={currentVideo.isMock ? 'Simulated Historical Experience' : 'Live YouTube Data'}
            compact
          />
          <span className="text-neutral-500 font-mono">
            Published: {formatUtcDateShort(currentVideo.publishedAt)}
          </span>
        </div>
      </div>

      {/* 2011 Cosmic Panda Dark Cinema Stage */}
      {isCosmicPanda && (
        <div className="bg-[#1b1b1b] text-white p-4 rounded-md shadow-inner border border-neutral-800">
          <div className="mb-2 flex items-center justify-between">
            <h1 className="text-lg font-bold text-white">{currentVideo.title}</h1>
            <span className="text-[11px] px-2 py-0.5 rounded bg-neutral-800 text-amber-300 border border-neutral-700">
              2011 Cosmic Panda Theater Stage
            </span>
          </div>
          <VideoPlayer video={currentVideo} era={currentEra} />
        </div>
      )}

      {/* Main Watch Layout Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Primary Column (Player + Metadata + Comments) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {!isCosmicPanda && (
            <>
              {isClassicRightMeta && (
                <h1
                  className="text-lg font-bold leading-snug"
                  style={{ color: currentEra.textColor }}
                >
                  {currentVideo.title}
                </h1>
              )}
              <VideoPlayer video={currentVideo} era={currentEra} />
            </>
          )}

          {/* 2006–2009 Exact Action & Rating Box below Player (Matches 1000067167.jpg) */}
          {isClassicRightMeta ? (
            <div className="bg-white border border-[#cccccc] rounded-[2px] overflow-hidden text-xs">
              <div className="p-2.5 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-col gap-0.5">
                  <span className="font-bold text-[11px] text-neutral-800">Rate this video:</span>
                  <RatingStars
                    videoId={currentVideo.id}
                    simulation={currentVideo.ratingSimulation}
                    interactive
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1.5 text-[11px]">
                  <button
                    type="button"
                    onClick={() => toggleSaveVideo(currentVideo)}
                    className="text-left text-[#0033cc] underline font-medium flex items-center gap-1"
                  >
                    <Bookmark className="w-3 h-3 text-red-600" />
                    <span>{isSaved ? 'Saved in Favorites' : 'Save to Favorites'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => openChannelPage(currentVideo.channelId)}
                    className="text-left text-[#0033cc] underline font-medium flex items-center gap-1"
                  >
                    <Users className="w-3 h-3 text-blue-700" />
                    <span>Add to Groups</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleCopyEmbed}
                    className="text-left text-[#0033cc] underline font-medium flex items-center gap-1"
                  >
                    <Share2 className="w-3 h-3 text-neutral-600" />
                    <span>{copiedEmbed ? 'Link Copied!' : 'Share Video'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveView('era-guide')}
                    className="text-left text-[#0033cc] underline font-medium flex items-center gap-1"
                  >
                    <Film className="w-3 h-3 text-amber-700" />
                    <span>Post Video</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => useTimeMachineStore.getState().dismissVideo(currentVideo)}
                    className="text-left text-[#0033cc] underline font-medium flex items-center gap-1"
                  >
                    <AlertTriangle className="w-3 h-3 text-neutral-500" />
                    <span>Flag as Inappropriate</span>
                  </button>
                </div>
              </div>

              <div className="bg-[#f2f2f2] border-t border-[#cccccc] px-3 py-1.5 flex flex-wrap items-center justify-around text-[11px] text-neutral-800">
                <span>
                  Views: <strong>{formatNumber(currentVideo.viewCount)}</strong>
                </span>
                <span className="text-neutral-400">|</span>
                <span>
                  Comments: <strong>{formatNumber((currentVideo.commentCount ?? 0) + localComments.length)}</strong>
                </span>
                <span className="text-neutral-400">|</span>
                <span>
                  Favorited: <strong>{isSaved ? 19 : 18} times</strong>
                </span>
              </div>
            </div>
          ) : (
            /* 2010–2019 Metadata & Interaction Panel */
            <div
              className="p-3.5 border rounded"
              style={{
                backgroundColor: currentEra.surfaceColor,
                borderColor: currentEra.borderColor,
                borderRadius: currentEra.borderRadius,
              }}
            >
            {!isClassicRightMeta && !isCosmicPanda && (
              <h1
                className="text-lg font-bold leading-snug mb-2"
                style={{ color: currentEra.textColor }}
              >
                {currentVideo.title}
              </h1>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-neutral-200">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => openChannelPage(currentVideo.channelId)}
                  className="w-10 h-10 rounded flex items-center justify-center font-bold text-white text-sm"
                  style={{
                    backgroundColor: currentEra.accentColor,
                    borderRadius: currentEra.eraGroup === 'modern-polymer' ? '9999px' : '4px',
                  }}
                >
                  {currentVideo.channelTitle.slice(0, 2).toUpperCase()}
                </button>
                <div>
                  <button
                    type="button"
                    onClick={() => openChannelPage(currentVideo.channelId)}
                    className="font-bold text-sm hover:underline block"
                    style={{ color: currentEra.linkColor }}
                  >
                    {currentVideo.channelTitle}
                  </button>
                  <span className="text-[11px] text-neutral-500">
                    Uploaded on {formatUtcDateShort(currentVideo.publishedAt)}
                  </span>
                </div>
                <SubscribeControl
                  channelId={currentVideo.channelId}
                  channelTitle={currentVideo.channelTitle}
                  era={currentEra}
                />
              </div>

              <div className="flex flex-col items-end gap-1">
                <div className="text-sm font-bold text-neutral-800 flex items-center gap-1.5">
                  <Eye className="w-4 h-4 text-neutral-500" />
                  <span>{formatNumber(currentVideo.viewCount)} views</span>
                </div>
                <span className="text-[10px] text-neutral-500">
                  (Current/Archive statistic, not historical {currentEra.year} view count)
                </span>
              </div>
            </div>

            {/* Period Rating Controls (5-Star Simulation in 2006-2009 vs Like/Dislike Bar in 2010-2019) */}
            <div className="py-3 flex flex-wrap items-center justify-between gap-3 border-b border-neutral-200">
              {currentEra.showStarRatingSimulation ? (
                <div className="flex flex-col gap-1">
                  <span className="text-[11px] font-bold text-neutral-700">
                    Rate this video (2006–2009 5-Star Interface):
                  </span>
                  <RatingStars
                    videoId={currentVideo.id}
                    simulation={currentVideo.ratingSimulation}
                    interactive
                  />
                </div>
              ) : (
                <LikeDislikeBar
                  videoId={currentVideo.id}
                  likeCount={currentVideo.likeCount}
                  year={currentEra.year}
                />
              )}

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => toggleSaveVideo(currentVideo)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-bold border ${
                    isSaved
                      ? 'bg-amber-100 text-amber-900 border-amber-400'
                      : 'bg-neutral-100 text-neutral-800 border-neutral-300 hover:bg-neutral-200'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-current' : ''}`} />
                  <span>{isSaved ? 'Saved in Favorites' : 'Favorite'}</span>
                </button>
              </div>
            </div>

            {/* Description Box (shown below player in 2010–2019) */}
            {!isClassicRightMeta && (
              <div className="mt-3 text-xs text-neutral-700 leading-relaxed">
                <p>{currentVideo.description}</p>
                {currentVideo.tags && currentVideo.tags.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {currentVideo.tags.map((t) => (
                      <span
                        key={t}
                        className="px-2 py-0.5 rounded bg-neutral-100 text-neutral-600 font-mono text-[10px]"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
          )}

          {/* Comments Section (XSS-safe text rendering) */}
          {currentEra.showComments && (
            <div
              className="p-3.5 border rounded"
              style={{
                backgroundColor: currentEra.surfaceColor,
                borderColor: currentEra.borderColor,
                borderRadius: currentEra.borderRadius,
              }}
            >
              <div className="flex items-center justify-between mb-3 pb-1.5 border-b border-neutral-200">
                <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>
                    Text Comments ({formatNumber((currentVideo.commentCount ?? 0) + localComments.length)})
                  </span>
                </h2>
                <RealityBadge layer="Simulated Historical Experience" compact />
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  addLocalComment(currentVideo.id, commentInput);
                  setCommentInput('');
                }}
                className="flex gap-2 mb-4"
              >
                <input
                  type="text"
                  value={commentInput}
                  onChange={(e) => setCommentInput(e.target.value)}
                  placeholder={`Post a local session comment as if you're browsing in ${currentEra.year}...`}
                  className="flex-1 px-2.5 py-1.5 text-xs border border-neutral-300 rounded bg-white text-neutral-900"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 text-xs font-bold rounded text-white"
                  style={{ backgroundColor: currentEra.accentColor }}
                >
                  Post Comment
                </button>
              </form>

              <div className="flex flex-col gap-2.5 text-xs">
                {localComments.map((c) => (
                  <div key={c.id} className="p-2 rounded bg-amber-50/70 border border-amber-200">
                    <div className="flex items-center justify-between text-[11px] font-bold text-amber-900">
                      <span>{c.author}</span>
                      <span>{c.dateLabel}</span>
                    </div>
                    <p className="mt-1 text-neutral-800">{c.text}</p>
                  </div>
                ))}

                <div className="p-2 rounded bg-neutral-50 border border-neutral-200">
                  <div className="flex items-center justify-between text-[11px] font-bold text-blue-800">
                    <span>RetroArchivist_{currentEra.year}</span>
                    <span className="text-neutral-500">{currentEra.year} Archive Note</span>
                  </div>
                  <p className="mt-1 text-neutral-700">
                    Watching this in {currentEra.year}! Love the {currentEra.thumbnailAspectRatio}{' '}
                    layout and classic {currentEra.ChannelPageLayout} vibes.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar Column: In 2006-2009 includes Classic Right-Hand Info & Embed Box + Related Videos */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {isClassicRightMeta && (
            <div className="bg-white border border-[#cccccc] rounded-[2px] p-3 text-xs text-neutral-800">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="text-[11px] leading-snug">
                  <div>
                    Added <strong>{formatUtcDateShort(currentVideo.publishedAt)}</strong>
                  </div>
                  <div>
                    From{' '}
                    <button
                      type="button"
                      onClick={() => openChannelPage(currentVideo.channelId)}
                      className="text-[#0033cc] underline font-bold"
                    >
                      {currentVideo.channelTitle}
                    </button>
                  </div>
                </div>

                <div className="flex flex-col items-end">
                  <SubscribeControl
                    channelId={currentVideo.channelId}
                    channelTitle={currentVideo.channelTitle}
                    era={currentEra}
                  />
                  <span className="text-[10px] text-neutral-600 mt-0.5">
                    to {currentVideo.channelTitle}
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-neutral-800 leading-relaxed mb-2">
                {currentVideo.description}
              </p>

              <div className="text-[11px] space-y-1 border-t border-neutral-200 pt-2">
                <div>
                  <span className="text-neutral-600">Category </span>
                  <button
                    type="button"
                    onClick={() => {
                      useTimeMachineStore.getState().setCategory(currentVideo.categoryId);
                      setActiveView('home');
                    }}
                    className="text-[#0033cc] underline"
                  >
                    {CATEGORIES.find((c) => c.id === currentVideo.categoryId)?.title || 'Entertainment'}
                  </button>
                </div>
                {currentVideo.tags && currentVideo.tags.length > 0 && (
                  <div>
                    <span className="text-neutral-600">Tags </span>
                    {currentVideo.tags.map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => useTimeMachineStore.getState().setSearchQuery(t)}
                        className="text-[#0033cc] underline mr-1.5"
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-2 pt-1">
                  <label className="font-bold text-neutral-700 w-10">URL</label>
                  <input
                    type="text"
                    readOnly
                    value={`http://www.youtube.com/watch?v=${currentVideo.id}`}
                    className="flex-1 px-1.5 py-0.5 text-[11px] font-mono bg-white border border-[#7f9db9] text-neutral-800"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <label className="font-bold text-neutral-700 w-10">Embed</label>
                  <input
                    type="text"
                    readOnly
                    value={`<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/${currentVideo.id}"></param></object>`}
                    className="flex-1 px-1.5 py-0.5 text-[11px] font-mono bg-white border border-[#7f9db9] text-neutral-800"
                  />
                  <button
                    type="button"
                    onClick={handleCopyEmbed}
                    className="px-2 py-0.5 text-[10px] font-bold bg-neutral-200 border border-neutral-400 text-neutral-900"
                  >
                    {copiedEmbed ? 'Copied' : 'Copy'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Related / Up Next Videos */}
          <div
            className="p-3 border rounded"
            style={{
              backgroundColor: currentEra.surfaceColor,
              borderColor: currentEra.borderColor,
              borderRadius: currentEra.borderRadius,
            }}
          >
            <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-neutral-200">
              <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700">
                {currentEra.year >= 2015 ? 'Up Next (Autoplay Queue)' : 'Related Videos'} (
                {currentEra.year})
              </h2>
              <span className="text-[10px] text-neutral-500 font-mono">70/30 Ranked</span>
            </div>

            <div className="flex flex-col gap-2.5">
              {relatedScored.slice(0, 6).map((item) => (
                <button
                  key={item.video.id}
                  type="button"
                  onClick={() => openVideoDetail(item.video)}
                  className="flex items-start gap-2.5 text-left p-1.5 rounded hover:bg-neutral-100 transition-colors group"
                >
                  <img
                    src={item.video.thumbnailUrl}
                    alt={item.video.title}
                    className="w-28 aspect-video object-cover rounded border border-neutral-300 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <p
                      className="text-xs font-bold line-clamp-2 group-hover:underline"
                      style={{
                        color:
                          currentEra.eraGroup === 'classic-web'
                            ? currentEra.linkColor
                            : currentEra.textColor,
                      }}
                    >
                      {item.video.title}
                    </p>
                    <p className="text-[11px] text-neutral-500 truncate mt-0.5">
                      {item.video.channelTitle}
                    </p>
                    <p className="text-[10px] text-neutral-500">
                      {formatNumber(item.video.viewCount)} views •{' '}
                      <span className="font-mono text-indigo-700">{item.slotType}</span>
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 15. CHANNEL PAGE SIMULATION (Section 15.3)
// ============================================================================

export function ChannelPage() {
  const selectedChannelId = useTimeMachineStore((s) => s.selectedChannelId);
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const currentYear = useTimeMachineStore((s) => s.currentYear);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);

  const channelVideos = useMemo(() => {
    const yearPool = MOCK_CATALOG_BY_YEAR[currentYear] ?? [];
    const matches = yearPool.filter((v) => v.channelId === selectedChannelId);
    return matches.length > 0 ? matches : yearPool.slice(0, 4);
  }, [selectedChannelId, currentYear]);

  const channelTitle = channelVideos[0]?.channelTitle || 'RetroCreatorChannel';
  const channelId = selectedChannelId || channelVideos[0]?.channelId || 'ch-default';

  const scoredChannelItems = useMemo(
    () =>
      channelVideos.map((v) => ({
        video: v,
        totalScore: 25,
        slotType: 'personalized' as const,
        breakdown: {
          categoryAffinity: 15,
          discoveryBonus: 5,
          freshnessWithinEra: 3,
          relevance: 10,
          qualitySignal: 5,
          repetitionPenalty: 0,
          dismissalPenalty: 0,
        },
      })),
    [channelVideos]
  );

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={() => setActiveView('home')}
          className="inline-flex items-center gap-1 text-xs font-bold hover:underline"
          style={{ color: currentEra.linkColor }}
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Back to {currentYear} Feed</span>
        </button>
        <RealityBadge layer="Simulated Historical Experience" compact />
      </div>

      {/* Era-Specific Channel Header Banner */}
      <div
        className="border rounded overflow-hidden"
        style={{
          backgroundColor: currentEra.surfaceColor,
          borderColor: currentEra.borderColor,
          borderRadius: currentEra.borderRadius,
        }}
      >
        <div
          className="h-28 px-5 flex items-end pb-3 text-white"
          style={{
            background:
              currentEra.channelPageLayout === 'classic-profile-boxes'
                ? 'linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%)'
                : currentEra.channelPageLayout === 'cosmic-modular'
                ? 'linear-gradient(90deg, #18181b 0%, #3f3f46 100%)'
                : 'linear-gradient(90deg, #7f1d1d 0%, #dc2626 100%)',
          }}
        >
          <div className="flex items-center justify-between w-full flex-wrap gap-2">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded bg-white/20 backdrop-blur border border-white/40 flex items-center justify-center text-xl font-extrabold">
                {channelTitle.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <h1 className="text-xl font-bold">{channelTitle}</h1>
                <p className="text-xs text-white/85">
                  Layout Mode: <span className="font-mono">{currentEra.channelPageLayout}</span> •{' '}
                  {currentYear} Archive
                </p>
              </div>
            </div>
            <SubscribeControl
              channelId={channelId}
              channelTitle={channelTitle}
              era={currentEra}
            />
          </div>
        </div>

        <div className="px-5 py-3 text-xs text-neutral-600 flex flex-wrap items-center justify-between gap-2 border-t border-neutral-200">
          <span>
            Showing {currentYear} uploads from <strong>{channelTitle}</strong> (strictly locked to{' '}
            {currentYear}).
          </span>
          <span className="font-mono text-[11px]">Channel ID: {channelId}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {scoredChannelItems.map((item) => (
          <VideoCard key={item.video.id} scoredItem={item} era={currentEra} />
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 16. HISTORY, SAVED FAVORITES, PROFILE ENGINE, ERA GUIDE & SETTINGS (Section 15)
// ============================================================================

export function HistoryPanel() {
  const history = useTimeMachineStore((s) => s.userProfile.recentlyWatched);
  const clearWatchHistory = useTimeMachineStore((s) => s.clearWatchHistory);
  const setYear = useTimeMachineStore((s) => s.setYear);
  const openVideoDetail = useTimeMachineStore((s) => s.openVideoDetail);
  const currentEra = useTimeMachineStore((s) => s.currentEra);

  const handleReopenHistoryItem = async (entry: WatchHistoryEntry) => {
    const yearPool = MOCK_CATALOG_BY_YEAR[entry.year] ?? [];
    const found = yearPool.find((v) => v.id === entry.videoId);
    if (entry.year !== currentEra.year) {
      await setYear(entry.year);
    }
    if (found) {
      openVideoDetail(found);
    }
  };

  return (
    <div
      className="p-4 border rounded"
      style={{
        backgroundColor: currentEra.surfaceColor,
        borderColor: currentEra.borderColor,
      }}
    >
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-4 border-b border-neutral-200">
        <div>
          <h1 className="text-base font-bold text-neutral-900">
            Local Watch History ({history.length})
          </h1>
          <p className="text-xs text-neutral-600">
            Tracks videos opened and active playback duration for watch-time recommendation signals.
          </p>
        </div>
        {history.length > 0 && (
          <button
            type="button"
            onClick={() => clearWatchHistory()}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <p className="text-xs text-neutral-500 py-8 text-center">
          No videos opened in your watch history yet. Click any video card to start exploring!
        </p>
      ) : (
        <div className="flex flex-col gap-2">
          {history.map((item) => (
            <div
              key={`${item.videoId}-${item.watchedAt}`}
              className="p-2.5 rounded border border-neutral-200 hover:bg-neutral-50 flex flex-wrap items-center justify-between gap-2 text-xs"
            >
              <div>
                <button
                  type="button"
                  onClick={() => handleReopenHistoryItem(item)}
                  className="font-bold text-blue-700 hover:underline text-left"
                >
                  {item.title}
                </button>
                <div className="text-[11px] text-neutral-500 mt-0.5">
                  Channel: {item.channelTitle} • Era Year:{' '}
                  <span className="font-mono font-bold text-neutral-800">{item.year}</span> • Active
                  Watch Time:{' '}
                  <span className="font-mono font-bold text-emerald-700">
                    {item.watchedSeconds}s
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => handleReopenHistoryItem(item)}
                className="px-2.5 py-1 rounded bg-neutral-200 hover:bg-neutral-300 text-neutral-800 font-semibold"
              >
                Watch Again
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function SavedVideosPage() {
  const savedIds = useTimeMachineStore((s) => s.userProfile.savedVideoIds);
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const setYear = useTimeMachineStore((s) => s.setYear);
  const openVideoDetail = useTimeMachineStore((s) => s.openVideoDetail);
  const toggleSaveVideo = useTimeMachineStore((s) => s.toggleSaveVideo);

  const savedVideos = useMemo(() => {
    const all: Video[] = [];
    for (const yr of SUPPORTED_YEARS) {
      for (const v of MOCK_CATALOG_BY_YEAR[yr] ?? []) {
        if (savedIds.includes(v.id)) {
          all.push(v);
        }
      }
    }
    return all;
  }, [savedIds]);

  return (
    <div
      className="p-4 border rounded"
      style={{
        backgroundColor: currentEra.surfaceColor,
        borderColor: currentEra.borderColor,
      }}
    >
      <div className="pb-3 mb-4 border-b border-neutral-200">
        <h1 className="text-base font-bold text-neutral-900">
          Saved Time Capsule Favorites ({savedVideos.length})
        </h1>
        <p className="text-xs text-neutral-600">
          Your bookmarked videos persist across year jumps in localStorage.
        </p>
      </div>

      {savedVideos.length === 0 ? (
        <p className="text-xs text-neutral-500 py-8 text-center">
          No saved videos yet. Click the bookmark icon on any video card to save it across eras.
        </p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {savedVideos.map((v) => (
            <div
              key={v.id}
              className="p-3 rounded border border-neutral-200 bg-neutral-50 flex flex-col justify-between gap-2 text-xs"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="px-2 py-0.5 rounded bg-red-600 text-white font-mono font-bold text-[10px]">
                    {v.historicalYear} Era
                  </span>
                  <span className="text-[11px] text-neutral-500">{v.channelTitle}</span>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    if (v.historicalYear !== currentEra.year) {
                      await setYear(v.historicalYear);
                    }
                    openVideoDetail(v);
                  }}
                  className="font-bold text-sm text-blue-800 hover:underline text-left line-clamp-2"
                >
                  {v.title}
                </button>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={async () => {
                    if (v.historicalYear !== currentEra.year) {
                      await setYear(v.historicalYear);
                    }
                    openVideoDetail(v);
                  }}
                  className="px-2.5 py-1 rounded bg-neutral-900 text-white font-semibold"
                >
                  Open in {v.historicalYear}
                </button>
                <button
                  type="button"
                  onClick={() => toggleSaveVideo(v)}
                  className="text-red-600 hover:underline"
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function ProfilePanel() {
  const userProfile = useTimeMachineStore((s) => s.userProfile);
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const setDiscoveryPreference = useTimeMachineStore((s) => s.setDiscoveryPreference);
  const resetUserProfile = useTimeMachineStore((s) => s.resetUserProfile);
  const importUserProfileJson = useTimeMachineStore((s) => s.importUserProfileJson);
  const addToast = useTimeMachineStore((s) => s.addToast);

  const [importText, setImportText] = useState('');
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  const totalWatchSeconds = Object.values(userProfile.watchDurationsSec).reduce(
    (acc, v) => acc + v,
    0
  );

  const handleExportProfile = () => {
    const jsonStr = JSON.stringify(userProfile, null, 2);
    try {
      navigator.clipboard?.writeText(jsonStr);
      addToast({
        title: 'Profile JSON Copied to Clipboard',
        description: 'Schema v2 profile exported safely.',
        variant: 'success',
      });
    } catch {
      // Fallback
    }
    setImportText(jsonStr);
  };

  return (
    <div
      className="p-4 border rounded flex flex-col gap-5"
      style={{
        backgroundColor: currentEra.surfaceColor,
        borderColor: currentEra.borderColor,
      }}
    >
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-200">
        <div>
          <h1 className="text-base font-bold text-neutral-900">
            Adaptive 70/30 Recommendation Engine & Local Profile (v{userProfile.version})
          </h1>
          <p className="text-xs text-neutral-600">
            Formula: score = categoryAffinity + discoveryBonus + freshnessWithinEra + relevance +
            qualitySignal - repetitionPenalty - dismissalPenalty
          </p>
        </div>
        <RealityBadge layer="Simulated Historical Experience" />
      </div>

      {/* Session Summary Metrics (Section 15.7) */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
        <div className="p-3 rounded bg-neutral-100 border border-neutral-200">
          <span className="text-neutral-500 block">Videos Opened</span>
          <span className="text-lg font-extrabold text-neutral-900">
            {userProfile.clickedVideoIds.length}
          </span>
        </div>
        <div className="p-3 rounded bg-neutral-100 border border-neutral-200">
          <span className="text-neutral-500 block">Active Watch Time</span>
          <span className="text-lg font-extrabold text-emerald-700">
            {formatDurationSeconds(totalWatchSeconds)}
          </span>
        </div>
        <div className="p-3 rounded bg-neutral-100 border border-neutral-200">
          <span className="text-neutral-500 block">Categories Explored</span>
          <span className="text-lg font-extrabold text-indigo-700">
            {Object.keys(userProfile.categoryScores).length}
          </span>
        </div>
        <div className="p-3 rounded bg-neutral-100 border border-neutral-200">
          <span className="text-neutral-500 block">Years Visited</span>
          <span className="text-lg font-extrabold text-amber-700">
            {userProfile.preferredYears.length} / 14
          </span>
        </div>
        <div className="p-3 rounded bg-neutral-100 border border-neutral-200">
          <span className="text-neutral-500 block">Saved Favorites</span>
          <span className="text-lg font-extrabold text-red-600">
            {userProfile.savedVideoIds.length}
          </span>
        </div>
      </div>

      {/* 70/30 Split Ratio Slider */}
      <div className="p-3.5 rounded bg-neutral-50 border border-neutral-200 text-xs flex flex-col gap-2">
        <div className="flex items-center justify-between font-bold">
          <span>
            Feed Split Target:{' '}
            {Math.round((1 - userProfile.discoveryPreference) * 100)}% Personalized /{' '}
            {Math.round(userProfile.discoveryPreference * 100)}% Discovery
          </span>
          <button
            type="button"
            onClick={() => setDiscoveryPreference(0.30)}
            className="text-[11px] text-blue-700 hover:underline"
          >
            Reset to 70/30 Default
          </button>
        </div>
        <input
          type="range"
          min={0.15}
          max={0.50}
          step={0.05}
          value={userProfile.discoveryPreference}
          onChange={(e) => setDiscoveryPreference(Number(e.target.value))}
          aria-label="Discovery vs Personalization Ratio"
          className="w-full accent-indigo-600 cursor-pointer"
        />
      </div>

      {/* Category Affinity Breakdown */}
      <div>
        <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-700 mb-2">
          Category Affinity Scores (Click +10, Save +12, Relevant +8, Dismiss -12)
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs">
          {CATEGORIES.filter((c) => c.id !== 'all').map((cat) => {
            const score = userProfile.categoryScores[cat.id] ?? 0;
            return (
              <div
                key={cat.id}
                className="p-2.5 rounded border border-neutral-200 flex items-center justify-between"
              >
                <span className="font-medium text-neutral-800">{cat.title}</span>
                <span className="font-mono font-bold px-2 py-0.5 rounded bg-neutral-100 text-neutral-900">
                  {score} pts
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Profile Export / Import / Reset Controls (Section 9.7 & 20.3) */}
      <div className="pt-3 border-t border-neutral-200 flex flex-col gap-3 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportProfile}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-neutral-900 text-white font-bold"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Profile JSON</span>
            </button>
            <button
              type="button"
              onClick={() => importUserProfileJson(importText)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-blue-600 text-white font-bold"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Validate & Import JSON</span>
            </button>
          </div>

          {!confirmResetOpen ? (
            <button
              type="button"
              onClick={() => setConfirmResetOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-red-600 text-white font-bold"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Profile</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 bg-red-50 border border-red-300 px-3 py-1 rounded">
              <span className="font-bold text-red-900">Confirm full profile wipe?</span>
              <button
                type="button"
                onClick={() => {
                  resetUserProfile();
                  setConfirmResetOpen(false);
                }}
                className="px-2 py-0.5 rounded bg-red-600 text-white font-bold"
              >
                Yes, Reset
              </button>
              <button
                type="button"
                onClick={() => setConfirmResetOpen(false)}
                className="px-2 py-0.5 rounded bg-neutral-200 text-neutral-800"
              >
                Cancel
              </button>
            </div>
          )}
        </div>

        <textarea
          rows={5}
          value={importText}
          onChange={(e) => setImportText(e.target.value)}
          placeholder="Paste exported UserProfile JSON (schema v2) here to validate and import, or click 'Export Profile JSON' above to inspect your current profile..."
          className="w-full p-2.5 font-mono text-[11px] border border-neutral-300 rounded bg-neutral-50 text-neutral-800"
        />
      </div>
    </div>
  );
}

export function EraInformationPanel() {
  const currentEra = useTimeMachineStore((s) => s.currentEra);

  return (
    <div
      className="p-4 border rounded flex flex-col gap-4"
      style={{
        backgroundColor: currentEra.surfaceColor,
        borderColor: currentEra.borderColor,
      }}
    >
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-200">
        <div>
          <h1 className="text-base font-bold text-neutral-900">
            Historical Interface Reconstruction Guide — {currentEra.eraLabel}
          </h1>
          <p className="text-xs text-neutral-600">
            Confidence Level: <span className="font-mono font-bold">{currentEra.historicalConfidence}</span>{' '}
            • Era Group: <span className="font-mono">{currentEra.eraGroup}</span>
          </p>
        </div>
        <RealityBadge layer="Historical Reference" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div className="p-3.5 rounded bg-amber-50/70 border border-amber-200">
          <h2 className="font-bold text-amber-950 mb-2 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-amber-700" />
            <span>Katman A — Verified Historical Attributes</span>
          </h2>
          <ul className="list-disc list-inside space-y-1 text-neutral-800">
            {currentEra.verifiedFeatures.map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ul>
        </div>

        <div className="p-3.5 rounded bg-indigo-50/70 border border-indigo-200">
          <h2 className="font-bold text-indigo-950 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-indigo-700" />
            <span>Katman C — Simulated Historical Experience</span>
          </h2>
          <ul className="list-disc list-inside space-y-1 text-neutral-800">
            {currentEra.simulatedFeatures.map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ul>
        </div>
      </div>

      <div className="p-3.5 rounded bg-neutral-50 border border-neutral-200 text-xs">
        <h2 className="font-bold text-neutral-900 mb-1.5">Historical Context & Notes</h2>
        <div className="space-y-1.5 text-neutral-700">
          {currentEra.historicalNotes.map((n) => (
            <p key={n}>{n}</p>
          ))}
        </div>
      </div>

      <div className="p-3.5 rounded bg-white border border-neutral-200 text-xs">
        <h2 className="font-bold text-neutral-900 mb-2">Primary Reference Sources</h2>
        <ul className="space-y-1.5">
          {currentEra.sourceReferences.map((ref) => (
            <li key={ref.url} className="flex flex-wrap items-center justify-between gap-2">
              <a
                href={ref.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-700 hover:underline inline-flex items-center gap-1 font-medium"
              >
                <span>{ref.title}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <RealityBadge layer={ref.layer} compact />
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function SettingsPanel() {
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const discoveryMode = useTimeMachineStore((s) => s.discoveryMode);
  const setDiscoveryMode = useTimeMachineStore((s) => s.setDiscoveryMode);
  const prefersReducedMotion = useTimeMachineStore((s) => s.prefersReducedMotion);
  const setPrefersReducedMotion = useTimeMachineStore((s) => s.setPrefersReducedMotion);
  const selectedRegion = useTimeMachineStore((s) => s.selectedRegion);
  const setSelectedRegion = useTimeMachineStore((s) => s.setSelectedRegion);
  const backendBaseUrl = useTimeMachineStore((s) => s.backendBaseUrl);
  const useLiveBackend = useTimeMachineStore((s) => s.useLiveBackend);
  const setBackendConfig = useTimeMachineStore((s) => s.setBackendConfig);
  const directYoutubeApiKey = useTimeMachineStore((s) => s.directYoutubeApiKey);
  const setDirectYoutubeApiKey = useTimeMachineStore((s) => s.setDirectYoutubeApiKey);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);

  const [urlInput, setUrlInput] = useState(backendBaseUrl);
  const [apiKeyInput, setApiKeyInput] = useState(directYoutubeApiKey);
  const [showApiKey, setShowApiKey] = useState(false);
  const [testStatus, setTestStatus] = useState<{
    state: 'idle' | 'testing' | 'ok' | 'error';
    message: string;
  }>({ state: 'idle', message: '' });

  useEffect(() => {
    setApiKeyInput(directYoutubeApiKey);
  }, [directYoutubeApiKey]);

  const handleTestAndSaveApiKey = async () => {
    const clean = apiKeyInput.trim();
    if (!clean) {
      await setDirectYoutubeApiKey('');
      setTestStatus({
        state: 'idle',
        message: 'API anahtarı temizlendi.',
      });
      return;
    }
    setTestStatus({ state: 'testing', message: 'YouTube Data API v3 anahtarı doğrulanıyor...' });
    try {
      const testUrl = new URL('https://www.googleapis.com/youtube/v3/videos');
      testUrl.searchParams.set('part', 'snippet');
      testUrl.searchParams.set('id', 'dMH0bHeiRNg');
      testUrl.searchParams.set('key', clean);
      const res = await fetch(testUrl.toString());
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData?.error?.message || `HTTP ${res.status}`);
      }
      await setDirectYoutubeApiKey(clean);
      setTestStatus({
        state: 'ok',
        message: '✓ Bağlantı Başarılı! Anahtarınız tarayıcıya kalıcı olarak kaydedildi.',
      });
    } catch (err: any) {
      // Still save it if the user wants, or report the exact Google API message
      await setDirectYoutubeApiKey(clean);
      setTestStatus({
        state: 'error',
        message: `Anahtar kaydedildi ancak Google API yanıtı: ${err?.message || 'Bağlantı hatası'}`,
      });
    }
  };

  const regionPolicy = resolveRegionPolicy(currentEra.year, selectedRegion);

  return (
    <div
      className="p-4 border rounded flex flex-col gap-4 text-xs"
      style={{
        backgroundColor: currentEra.surfaceColor,
        borderColor: currentEra.borderColor,
      }}
    >
      <div className="pb-3 border-b border-neutral-200 flex items-center justify-between">
        <div>
          <h1 className="text-base font-bold text-neutral-900">
            System Settings, Region Policy & Backend API Bridge
          </h1>
          <p className="text-neutral-600">
            API keys are strictly isolated on the Express backend (`YOUTUBE_API_KEY`) and never
            stored in frontend variables.
          </p>
        </div>
        <ShieldCheck className="w-6 h-6 text-emerald-600" />
      </div>

      {/* Global Chaos Filter & Region Code */}
      <div className="p-3.5 rounded bg-neutral-50 border border-neutral-200 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <span className="font-bold text-neutral-900 flex items-center gap-1.5">
            <Globe className="w-4 h-4 text-blue-600" />
            <span>Regional Filter & Global Chaos Policy ({currentEra.year})</span>
          </span>
          <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-blue-100 text-blue-900 font-bold">
            {regionPolicy.globalChaosActive
              ? 'Global Chaos Active (No regionCode)'
              : `regionCode=${regionPolicy.regionCode}`}
          </span>
        </div>
        <p className="text-neutral-600">
          In 2006–2011 (`AUTO`), `regionCode` is omitted so international videos surface naturally.
          In 2012–2019 (`AUTO`), `regionCode` defaults to `US`. You can override the ISO 3166-1
          alpha-2 region below:
        </p>
        <div className="flex flex-wrap gap-1.5 mt-1">
          {['AUTO', 'US', 'TR', 'GB', 'JP', 'DE', 'FR', 'BR'].map((reg) => (
            <button
              key={reg}
              type="button"
              onClick={() => setSelectedRegion(reg)}
              className={`px-2.5 py-1 rounded font-mono font-bold border ${
                selectedRegion === reg
                  ? 'bg-neutral-900 text-white border-neutral-900'
                  : 'bg-white text-neutral-700 border-neutral-300 hover:bg-neutral-100'
              }`}
            >
              {reg}
            </button>
          ))}
        </div>
      </div>

      {/* Display & Accessibility */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="p-3.5 rounded border border-neutral-200 flex items-center justify-between">
          <div>
            <span className="font-bold block text-neutral-900">Retro Layout Mode</span>
            <span className="text-neutral-500">
              Historical strict widths vs Enhanced fluid accessibility
            </span>
          </div>
          <button
            type="button"
            onClick={() =>
              setDiscoveryMode(discoveryMode === 'historical' ? 'enhanced' : 'historical')
            }
            className="px-3 py-1.5 rounded bg-neutral-900 text-white font-bold"
          >
            {discoveryMode === 'historical' ? 'Historical' : 'Enhanced'}
          </button>
        </div>

        <div className="p-3.5 rounded border border-neutral-200 flex items-center justify-between">
          <div>
            <span className="font-bold block text-neutral-900">Reduced Motion</span>
            <span className="text-neutral-500">
              Disables time-travel transition animations
            </span>
          </div>
          <button
            type="button"
            onClick={() => setPrefersReducedMotion(!prefersReducedMotion)}
            className={`px-3 py-1.5 rounded font-bold ${
              prefersReducedMotion
                ? 'bg-emerald-600 text-white'
                : 'bg-neutral-200 text-neutral-800'
            }`}
          >
            {prefersReducedMotion ? 'Enabled' : 'Standard'}
          </button>
        </div>
      </div>

      {/* Direct YouTube Data API v3 Key (Saved Permanently in Browser localStorage) */}
      <div className="p-4 rounded-lg bg-emerald-50/90 border-2 border-emerald-400 flex flex-col gap-2.5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="font-bold text-sm text-emerald-950 flex items-center gap-1.5">
            <Radio className="w-4 h-4 text-emerald-600" />
            <span>Kalıcı YouTube Data API v3 Anahtarı (Dosyasız — Tarayıcı Hafızasında Saklanır)</span>
          </span>
          <div className="flex items-center gap-1.5">
            {directYoutubeApiKey ? (
              <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white font-bold text-[10px]">
                ✓ Anahtar Kayıtlı ve Aktif
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 font-bold text-[10px]">
                Yerleşik Arşiv Modu
              </span>
            )}
            <RealityBadge layer="Live YouTube Data" compact />
          </div>
        </div>

        <p className="text-neutral-700 leading-relaxed">
          Hiçbir kod veya <code>.env</code> dosyasıyla uğraşmanıza gerek yoktur. <strong>YouTube Data API v3</strong> anahtarınızı (<code>AIza...</code>) aşağıya yapıştırıp <strong>Kaydet ve Bağlan</strong> butonuna bastığınızda anahtarınız cihazınızın <code>localStorage</code> hafızasına kalıcı olarak kaydedilir; sayfayı kapatsanız bile silinmez.
        </p>

        <div className="flex flex-wrap items-center gap-2">
          <div className="relative flex-1 min-w-[220px] flex items-center">
            <input
              type={showApiKey ? 'text' : 'password'}
              value={apiKeyInput}
              onChange={(e) => setApiKeyInput(e.target.value)}
              placeholder="AIzaSy... (YouTube Data API v3 anahtarınızı buraya yapıştırın)"
              className="w-full px-3 py-2 border border-emerald-500 rounded font-mono text-xs bg-white text-neutral-900 pr-16 focus:outline-none focus:ring-2 focus:ring-emerald-600"
            />
            <button
              type="button"
              onClick={() => setShowApiKey(!showApiKey)}
              className="absolute right-2 px-2 py-0.5 text-[10px] font-bold rounded bg-neutral-100 hover:bg-neutral-200 text-neutral-700 border border-neutral-300"
            >
              {showApiKey ? 'Gizle' : 'Göster'}
            </button>
          </div>

          <button
            type="button"
            onClick={handleTestAndSaveApiKey}
            className="px-4 py-2 rounded font-bold text-white bg-emerald-700 hover:bg-emerald-600 shadow-sm transition-colors"
          >
            Activate Live API Key
          </button>

          {directYoutubeApiKey && (
            <button
              type="button"
              onClick={() => {
                setApiKeyInput('');
                setDirectYoutubeApiKey('');
                setTestStatus({ state: 'idle', message: 'Kayıtlı anahtar cihazdan silindi.' });
              }}
              className="px-3 py-2 rounded font-bold text-red-700 bg-red-100 hover:bg-red-200 border border-red-300"
            >
              Anahtarı Sil
            </button>
          )}

          {directYoutubeApiKey && (
            <button
              type="button"
              onClick={() => setActiveView('home')}
              className="px-3 py-2 rounded font-bold text-white bg-neutral-900 hover:bg-neutral-800"
            >
              {currentEra.year} Akışına Dön →
            </button>
          )}
        </div>

        {testStatus.message && (
          <div
            className={`mt-1 px-3 py-1.5 rounded text-xs font-semibold ${
              testStatus.state === 'ok'
                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                : testStatus.state === 'error'
                ? 'bg-amber-100 text-amber-950 border border-amber-300'
                : 'bg-white text-neutral-700 border border-neutral-300'
            }`}
          >
            {testStatus.message}
          </div>
        )}
      </div>

      {/* Optional Express Backend Connection */}
      <div className="p-3.5 rounded border border-neutral-200 flex flex-col gap-2">
        <span className="font-bold text-neutral-900 flex items-center gap-1.5">
          <Database className="w-4 h-4 text-indigo-600" />
          <span>Backend Express Server Bridge (`VITE_API_BASE_URL`)</span>
        </span>
        <div className="flex flex-wrap gap-2">
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="http://localhost:4000"
            className="flex-1 min-w-[200px] px-2.5 py-1.5 border border-neutral-300 rounded font-mono"
          />
          <button
            type="button"
            onClick={() => setBackendConfig(urlInput, !useLiveBackend)}
            className={`px-3 py-1.5 rounded font-bold text-white ${
              useLiveBackend ? 'bg-emerald-600' : 'bg-indigo-600'
            }`}
          >
            {useLiveBackend ? 'Connected (Switch to Local Mock)' : 'Connect Live Backend'}
          </button>
        </div>
      </div>
    </div>
  );
}


// ============================================================================
// 16B. TIME MACHINE TRANSITION OVERLAY & BEFORE/AFTER ERA COMPARISON
// ============================================================================

export function TimeTravelTransitionOverlay({
  active,
  fromYear,
  toYear,
  displayYear,
  targetEra,
}: {
  active: boolean;
  fromYear: number;
  toYear: number;
  displayYear: number;
  targetEra: EraConfig;
}) {
  if (!active) return null;
  const direction = toYear >= fromYear ? 'FORWARD IN TIME' : 'REWINDING WEB HISTORY';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md text-white p-4 select-none"
      role="dialog"
      aria-live="assertive"
      aria-label={`Time traveling from ${fromYear} to ${toYear}`}
    >
      {/* Scanline / CRT Grid Backdrop */}
      <div
        className="absolute inset-0 pointer-events-none opacity-25"
        style={{
          backgroundImage:
            'repeating-linear-gradient(0deg, rgba(255,255,255,0.08), rgba(255,255,255,0.08) 1px, transparent 1px, transparent 4px)',
        }}
      />

      <div className="relative z-10 max-w-lg w-full rounded-xl border border-red-500/50 bg-neutral-950/95 p-6 shadow-2xl text-center flex flex-col items-center gap-3">
        <span className="px-3 py-1 rounded-full bg-red-600/20 border border-red-500/40 text-red-400 font-mono text-xs font-bold tracking-widest uppercase">
          ⚡ {direction}: {fromYear} → {toYear}
        </span>

        <div className="text-6xl sm:text-7xl font-black font-mono tracking-tighter text-amber-400 drop-shadow">
          {displayYear}
        </div>

        <p className="text-sm font-bold text-white">{targetEra.eraLabel}</p>

        <div className="w-full grid grid-cols-3 gap-2 text-[11px] font-mono bg-neutral-900 p-3 rounded-lg border border-neutral-800">
          <div>
            <span className="text-neutral-500 block">ASPECT RATIO</span>
            <span className="text-emerald-400 font-bold">{targetEra.thumbnailAspectRatio}</span>
          </div>
          <div>
            <span className="text-neutral-500 block">RATING SYSTEM</span>
            <span className="text-amber-300 font-bold">
              {targetEra.showStarRatingSimulation ? '5-Star Widget' : 'Thumbs Up/Down'}
            </span>
          </div>
          <div>
            <span className="text-neutral-500 block">MAX WIDTH</span>
            <span className="text-sky-400 font-bold">{targetEra.maxContentWidth}</span>
          </div>
        </div>

        <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden mt-1">
          <div className="h-full bg-gradient-to-r from-amber-500 via-red-500 to-indigo-500 w-full animate-pulse" />
        </div>
        <span className="text-[11px] text-neutral-400 font-mono">
          Reconstructing DOM layout, CSS tokens & UTC {toYear} video archive...
        </span>
      </div>
    </div>
  );
}

export function EraComparisonPanel() {
  const currentYear = useTimeMachineStore((s) => s.currentYear);
  const setYear = useTimeMachineStore((s) => s.setYear);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);

  const [leftYear, setLeftYear] = useState<number>(2007);
  const [rightYear, setRightYear] = useState<number>(currentYear === 2007 ? 2018 : currentYear);

  const leftEra = getEraConfig(leftYear);
  const rightEra = getEraConfig(rightYear);

  return (
    <div className="p-4 border rounded bg-white text-neutral-900 flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-neutral-200">
        <div>
          <h1 className="text-base font-bold">
            Before / After Era Architecture Comparison (Önce / Sonra Karşılaştırması)
          </h1>
          <p className="text-xs text-neutral-600">
            Compare any two YouTube eras side by side across layout structure, ratings, and algorithm weights.
          </p>
        </div>
        <RealityBadge layer="Historical Reference" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[
          { side: 'BEFORE (Sol Dönem)', yr: leftYear, setYr: setLeftYear, era: leftEra },
          { side: 'AFTER (Sağ Dönem)', yr: rightYear, setYr: setRightYear, era: rightEra },
        ].map((col) => (
          <div
            key={col.side}
            className="p-4 rounded-lg border-2 flex flex-col gap-3"
            style={{
              backgroundColor: col.era.backgroundColor,
              borderColor: col.era.borderColor,
              fontFamily: col.era.fontFamily,
            }}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-neutral-900 text-white">
                {col.side}
              </span>
              <select
                value={col.yr}
                onChange={(e) => col.setYr(Number(e.target.value))}
                aria-label={col.side}
                className="px-2.5 py-1 rounded border border-neutral-400 bg-white text-xs font-bold text-neutral-900"
              >
                {SUPPORTED_YEARS.map((y) => (
                  <option key={y} value={y}>
                    {y} — {ERA_CONFIGS[y].eraGroup}
                  </option>
                ))}
              </select>
            </div>

            <div
              className="p-3 rounded border"
              style={{
                backgroundColor: col.era.surfaceColor,
                borderColor: col.era.borderColor,
              }}
            >
              <div className="flex items-center justify-between mb-2">
                <RetroLogo
                  year={col.era.year}
                  eraGroup={col.era.eraGroup}
                  darkTheme={false}
                  onClick={() => {
                    setYear(col.era.year);
                    setActiveView('home');
                  }}
                />
                <span
                  className="px-2 py-0.5 text-[10px] font-bold rounded text-white"
                  style={{ backgroundColor: col.era.accentColor }}
                >
                  {col.era.buttonStyle}
                </span>
              </div>
              <p className="text-xs font-bold text-neutral-800">{col.era.eraLabel}</p>
              <p className="text-[11px] text-neutral-600 mt-1">{col.era.historicalNotes[0]}</p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded bg-white/90 border border-neutral-300">
                <span className="text-[10px] text-neutral-500 block">Max Content Width</span>
                <span className="font-mono font-bold text-neutral-900">{col.era.maxContentWidth}</span>
              </div>
              <div className="p-2 rounded bg-white/90 border border-neutral-300">
                <span className="text-[10px] text-neutral-500 block">Thumbnail Ratio</span>
                <span className="font-mono font-bold text-neutral-900">{col.era.thumbnailAspectRatio}</span>
              </div>
              <div className="p-2 rounded bg-white/90 border border-neutral-300">
                <span className="text-[10px] text-neutral-500 block">Rating Mechanic</span>
                <span className="font-bold text-neutral-900">
                  {col.era.showStarRatingSimulation ? '★★★★★ (5 Stars)' : '👍 / 👎 Ratio Bar'}
                </span>
              </div>
              <div className="p-2 rounded bg-white/90 border border-neutral-300">
                <span className="text-[10px] text-neutral-500 block">Watch Page Layout</span>
                <span className="font-mono font-bold text-neutral-900">{col.era.playbackPageLayout}</span>
              </div>
              <div className="p-2 rounded bg-white/90 border border-neutral-300">
                <span className="text-[10px] text-neutral-500 block">Watch-Time Weight</span>
                <span className="font-mono font-bold text-emerald-700">
                  ×{col.era.recommendationProfile.watchTimeSignalWeight}
                </span>
              </div>
              <div className="p-2 rounded bg-white/90 border border-neutral-300">
                <span className="text-[10px] text-neutral-500 block">Discovery Bonus Weight</span>
                <span className="font-mono font-bold text-indigo-700">
                  ×{col.era.recommendationProfile.discoveryBonusWeight}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setYear(col.era.year);
                setActiveView('home');
              }}
              className="w-full py-2 rounded font-bold text-xs text-white shadow hover:opacity-95"
              style={{ backgroundColor: col.era.accentColor }}
            >
              Launch {col.era.year} Experience →
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// 16C. AUTHENTIC 2006–2009 CLASSIC PORTAL HOMEPAGE (Matches 1000067164.jpg)
// ============================================================================

export function ClassicPortalHomeShowcase({
  scoredFeed,
  era,
}: {
  scoredFeed: ScoredVideoCard[];
  era: EraConfig;
}) {
  const openVideoDetail = useTimeMachineStore((s) => s.openVideoDetail);
  const openChannelPage = useTimeMachineStore((s) => s.openChannelPage);
  const setCategory = useTimeMachineStore((s) => s.setCategory);
  const setSortBy = useTimeMachineStore((s) => s.setSortBy);
  const toggleSaveVideo = useTimeMachineStore((s) => s.toggleSaveVideo);
  const savedIds = useTimeMachineStore((s) => s.userProfile.savedVideoIds);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);

  const [featuredTab, setFeaturedTab] = useState<'featured' | 'mostViewed' | 'mostDiscussed' | 'topFavorites'>('featured');
  const [classicViewStyle, setClassicViewStyle] = useState<'portal-list' | 'grid'>('portal-list');

  const watchedRightNow = scoredFeed.slice(0, 5);
  const promotedVideos = scoredFeed.slice(2, 6);

  const displayedList = useMemo(() => {
    const copy = [...scoredFeed];
    if (featuredTab === 'mostViewed') {
      return copy.sort((a, b) => (b.video.viewCount ?? 0) - (a.video.viewCount ?? 0));
    }
    if (featuredTab === 'mostDiscussed') {
      return copy.sort((a, b) => (b.video.commentCount ?? 0) - (a.video.commentCount ?? 0));
    }
    if (featuredTab === 'topFavorites') {
      return copy.sort(
        (a, b) =>
          (b.video.ratingSimulation?.stars ?? 0) - (a.video.ratingSimulation?.stars ?? 0)
      );
    }
    return copy;
  }, [scoredFeed, featuredTab]);

  return (
    <div className="flex flex-col gap-3">
      {/* "What are the most popular videos..." Callout Banner from 2006 Screenshot */}
      <div className="p-2.5 bg-white border border-[#cccccc] rounded-[3px] flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-col">
          <span className="text-sm font-extrabold text-[#990000]">
            What are the most popular videos...
          </span>
          <span className="text-xs font-black tracking-tight text-neutral-300 uppercase">
            TODAY? THIS MONTH? THIS WEEK?
          </span>
        </div>

        <div className="flex items-center gap-3 text-[11px]">
          <div className="flex flex-col leading-tight">
            <span className="font-bold text-neutral-800">Time:</span>
            <button
              type="button"
              onClick={() => setSortBy('viewCount')}
              className="text-left text-[#0033cc] hover:underline font-semibold"
            >
              ● Today
            </button>
            <button
              type="button"
              onClick={() => setSortBy('rating')}
              className="text-left text-[#0033cc] hover:underline"
            >
              This Week
            </button>
            <button
              type="button"
              onClick={() => setSortBy('date')}
              className="text-left text-[#0033cc] hover:underline"
            >
              All Time
            </button>
          </div>
          <div className="text-[#0033cc] font-bold">
            Just follow the little red dots! →
          </div>
        </div>
      </div>

      {/* Main 2-Column 2006 Portal Split (70% Left Content / 30% Right Utility Boxes) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5">
        {/* Left 8 Columns */}
        <div className="lg:col-span-8 flex flex-col gap-3.5">
          {/* "Videos being watched right now..." 5-Card Strip */}
          <div className="bg-white border border-[#cccccc] rounded-[3px] p-2.5">
            <h2 className="text-xs font-bold text-neutral-700 mb-2">
              Videos being watched right now...
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {watchedRightNow.map((item) => (
                <button
                  key={item.video.id}
                  type="button"
                  onClick={() => openVideoDetail(item.video)}
                  className="flex flex-col text-left group focus:outline-none"
                >
                  <div className="relative w-full aspect-[4/3] border border-neutral-400 bg-black overflow-hidden shadow-sm">
                    <img
                      src={item.video.thumbnailUrl}
                      alt={item.video.title}
                      className="w-full h-full object-cover group-hover:opacity-90"
                    />
                    <span className="absolute bottom-0.5 right-0.5 bg-white/90 text-neutral-900 font-mono text-[9px] font-bold px-1 rounded-sm">
                      {formatDurationSeconds(item.video.durationSeconds)}
                    </span>
                  </div>
                  <span className="text-[11px] text-[#0033cc] font-bold underline line-clamp-1 mt-1">
                    {item.video.title}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* "Promoted Videos" 4-Column Row */}
          <div className="bg-white border border-[#cccccc] rounded-[3px] p-2.5">
            <h2 className="text-xs font-bold text-neutral-700 mb-2">Promoted Videos</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {promotedVideos.map((item) => (
                <div key={item.video.id} className="flex flex-col text-center">
                  <button
                    type="button"
                    onClick={() => openVideoDetail(item.video)}
                    className="w-full aspect-[4/3] border-2 border-neutral-500 bg-black overflow-hidden"
                  >
                    <img
                      src={item.video.thumbnailUrl}
                      alt={item.video.title}
                      className="w-full h-full object-cover"
                    />
                  </button>
                  <button
                    type="button"
                    onClick={() => openVideoDetail(item.video)}
                    className="text-[11px] font-bold text-[#0033cc] underline line-clamp-2 mt-1"
                  >
                    {item.video.title}
                  </button>
                  <button
                    type="button"
                    onClick={() => openChannelPage(item.video.channelId)}
                    className="text-[10px] text-neutral-600 underline"
                  >
                    {item.video.channelTitle}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* "Featured Videos" List Box (Exact match to 2006 screenshot) */}
          <div className="bg-white border border-[#cccccc] rounded-[3px] overflow-hidden">
            <div className="bg-[#e6e6e6] border-b border-[#cccccc] px-3 py-1.5 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm font-extrabold text-neutral-800">Featured Videos</h2>
              <div className="flex items-center gap-1 text-[11px]">
                {(
                  [
                    ['featured', 'Featured'],
                    ['mostViewed', 'Most Viewed'],
                    ['mostDiscussed', 'Most Discussed'],
                    ['topFavorites', 'Top Favorites'],
                  ] as const
                ).map(([tabKey, label]) => (
                  <button
                    key={tabKey}
                    type="button"
                    onClick={() => setFeaturedTab(tabKey)}
                    className={`px-2 py-0.5 rounded-t font-bold ${
                      featuredTab === tabKey
                        ? 'bg-white text-neutral-900 border border-b-0 border-[#cccccc]'
                        : 'text-[#0033cc] hover:underline'
                    }`}
                  >
                    {label}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() =>
                    setClassicViewStyle(classicViewStyle === 'portal-list' ? 'grid' : 'portal-list')
                  }
                  className="ml-2 px-1.5 py-0.5 rounded bg-neutral-200 text-neutral-800 text-[10px] font-mono"
                >
                  {classicViewStyle === 'portal-list' ? 'Grid View' : '2006 List View'}
                </button>
              </div>
            </div>

            {classicViewStyle === 'grid' ? (
              <div className="p-3 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {displayedList.map((item) => (
                  <VideoCard key={item.video.id} scoredItem={item} era={era} />
                ))}
              </div>
            ) : (
              <div className="divide-y divide-[#dcdcdc]">
                {displayedList.map((item) => {
                  const v = item.video;
                  const isSaved = savedIds.includes(v.id);
                  const catTitle =
                    CATEGORIES.find((c) => c.id === v.categoryId)?.title || 'Entertainment';
                  return (
                    <div
                      key={v.id}
                      className="p-3 flex flex-col sm:flex-row items-start justify-between gap-3 hover:bg-[#f9f9f5]"
                    >
                      {/* Left 4:3 Thumbnail with [+] QuickList button */}
                      <div className="w-full sm:w-32 shrink-0 flex flex-col">
                        <div
                          onClick={() => openVideoDetail(v)}
                          role="button"
                          tabIndex={0}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') openVideoDetail(v);
                          }}
                          className="relative w-full aspect-[4/3] border border-neutral-500 bg-black cursor-pointer overflow-hidden"
                        >
                          <img
                            src={v.thumbnailUrl}
                            alt={v.title}
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleSaveVideo(v);
                            }}
                            title="Add to QuickList / Favorites"
                            className="absolute bottom-1 left-1 w-4 h-4 bg-white border border-neutral-600 text-neutral-900 font-bold text-[11px] leading-none flex items-center justify-center shadow"
                          >
                            {isSaved ? '✓' : '+'}
                          </button>
                        </div>
                        <span className="text-[11px] text-neutral-700 mt-1">
                          Time: <strong>{formatDurationSeconds(v.durationSeconds)}</strong>
                        </span>
                      </div>

                      {/* Middle Title & Description */}
                      <div className="flex-1 min-w-0">
                        <button
                          type="button"
                          onClick={() => openVideoDetail(v)}
                          className="text-left font-bold text-sm text-[#0033cc] underline hover:text-red-700 leading-snug"
                        >
                          {v.title}
                        </button>
                        <p className="text-xs text-neutral-800 mt-1 line-clamp-3 leading-relaxed">
                          {v.description}
                        </p>
                        <div className="mt-1.5 flex items-center gap-1.5">
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                              item.slotType === 'personalized'
                                ? 'bg-emerald-100 text-emerald-900'
                                : 'bg-indigo-100 text-indigo-900'
                            }`}
                          >
                            {item.slotType === 'personalized' ? '70% Personalized' : '30% Discovery'}
                          </span>
                          <span className="text-[10px] text-neutral-500 font-mono">
                            Published: {formatUtcDateShort(v.publishedAt)}
                          </span>
                        </div>
                      </div>

                      {/* Right Metadata Column (From, Views, Red Stars, More in Category) */}
                      <div className="w-full sm:w-40 shrink-0 text-[11px] text-neutral-700 flex flex-col gap-0.5 sm:border-l sm:border-neutral-200 sm:pl-3">
                        <div>
                          From:{' '}
                          <button
                            type="button"
                            onClick={() => openChannelPage(v.channelId)}
                            className="text-[#0033cc] underline font-semibold"
                          >
                            {v.channelTitle}
                          </button>
                        </div>
                        <div>Views: {formatNumber(v.viewCount)}</div>
                        <div className="my-0.5">
                          <RatingStars videoId={v.id} simulation={v.ratingSimulation} />
                        </div>
                        <div className="mt-1">
                          More in{' '}
                          <button
                            type="button"
                            onClick={() => setCategory(v.categoryId)}
                            className="text-[#0033cc] underline font-semibold"
                          >
                            {catTitle}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right 4 Columns: Classic Login / QuickList Box + Yellow "What's New" Box */}
        <div className="lg:col-span-4 flex flex-col gap-3.5">
          {/* Exact 2006 "Login" Box from 1000067164.jpg */}
          <div className="bg-white border border-[#cccccc] rounded-[2px] p-2.5 text-xs">
            <div className="flex items-center justify-between pb-1 mb-2 border-b border-[#cccccc]">
              <span className="font-bold text-sm text-neutral-700">Login</span>
              <div className="text-[11px]">
                <button
                  type="button"
                  onClick={() => setActiveView('profile')}
                  className="text-[#0033cc] underline"
                >
                  Sign Up
                </button>{' '}
                |{' '}
                <button
                  type="button"
                  onClick={() => setActiveView('era-guide')}
                  className="text-[#0033cc] underline"
                >
                  Help
                </button>
              </div>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setActiveView('profile');
              }}
              className="flex flex-col gap-1.5 text-[11px]"
            >
              <div className="flex items-center justify-between gap-2">
                <label className="font-bold text-neutral-700 w-16 text-right">Username:</label>
                <input
                  type="text"
                  defaultValue="TimeTraveler_2006"
                  className="flex-1 px-1.5 py-0.5 border border-[#7f9db9] bg-white text-black text-xs"
                />
              </div>
              <div className="flex items-center justify-between gap-2">
                <label className="font-bold text-neutral-700 w-16 text-right">Password:</label>
                <input
                  type="password"
                  defaultValue="••••••••"
                  className="flex-1 px-1.5 py-0.5 border border-[#7f9db9] bg-white text-black text-xs"
                />
              </div>
              <div className="flex justify-center mt-1">
                <button
                  type="submit"
                  className="px-3 py-0.5 text-xs font-bold text-neutral-900 border border-[#888888] rounded-[2px]"
                  style={{ background: 'linear-gradient(180deg, #ffffff 0%, #d4d4d4 100%)' }}
                >
                  Login
                </button>
              </div>
              <div className="text-center pt-1.5 mt-1 border-t border-neutral-200">
                <button
                  type="button"
                  onClick={() => setActiveView('settings')}
                  className="text-[#0033cc] underline font-medium"
                >
                  Login with your Google account
                </button>
              </div>
            </form>
          </div>

          {/* Retro Contest Banner */}
          <div
            onClick={() => setCategory('10')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter') setCategory('10');
            }}
            className="p-3 rounded-[3px] border border-neutral-700 bg-gradient-to-r from-neutral-900 via-indigo-950 to-neutral-900 text-white cursor-pointer shadow"
          >
            <div className="text-[10px] font-mono uppercase text-amber-400 tracking-widest">
              {era.year} COMMUNITY SPOTLIGHT
            </div>
            <div className="text-sm font-black tracking-tight text-sky-300">
              ON THE RISE: BEDROOM SYNTH & INDIE CREATORS!
            </div>
            <div className="text-[10px] text-neutral-300 mt-0.5">
              Click to filter {era.year} Music & Synth Archive →
            </div>
          </div>

          {/* Iconic Yellow "What's New" Box from 2006 Screenshot */}
          <div className="bg-[#fefce8] border border-[#e5d595] rounded-[3px] p-3 text-xs text-neutral-800">
            <h3 className="text-sm font-extrabold text-[#996600] mb-2 pb-1 border-b border-[#e5d595]">
              What&apos;s New in {era.year}
            </h3>
            <div className="flex flex-col gap-2.5 text-[11px]">
              <div>
                <button
                  type="button"
                  onClick={() => setActiveView('compare')}
                  className="font-bold text-[#996600] underline block text-left"
                >
                  Before / After Era Comparison
                </button>
                <p className="text-neutral-700">
                  Compare {era.year} side by side against 2012 Cosmic Panda or 2018 Polymer.
                </p>
              </div>
              <div>
                <button
                  type="button"
                  onClick={() => setActiveView('profile')}
                  className="font-bold text-[#996600] underline block text-left"
                >
                  Show Your Ratings & Affinity
                </button>
                <p className="text-neutral-700">
                  Inspect how your 5-star ratings and clicks shape the 70/30 recommendation feed.
                </p>
              </div>
              <div>
                <button
                  type="button"
                  onClick={() => setActiveView('era-guide')}
                  className="font-bold text-[#996600] underline block text-left"
                >
                  Important Info for YouTube Historians
                </button>
                <p className="text-neutral-700">
                  We separate verified historical UI attributes (Katman A), live API metadata (Katman B), and simulated rankings (Katman C).
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}


// ============================================================================
// 16D. AUTHENTIC 2010–2013 TRANSITIONAL / COSMIC PANDA / 2012 BENTO SHOWCASE
//      (Matches 1000067165.jpg & 1000067168.jpg)
// ============================================================================

export function TransitionalPortalShowcase({
  scoredFeed,
  era,
}: {
  scoredFeed: ScoredVideoCard[];
  era: EraConfig;
}) {
  const openVideoDetail = useTimeMachineStore((s) => s.openVideoDetail);
  const openChannelPage = useTimeMachineStore((s) => s.openChannelPage);
  const markVideoRelevant = useTimeMachineStore((s) => s.markVideoRelevant);

  const topColumns = [
    { label: 'RECOMMENDED FOR YOU', item: scoredFeed[0] },
    { label: 'MOST POPULAR', item: scoredFeed[1] || scoredFeed[0] },
    { label: 'TECH & SCIENCE', item: scoredFeed.find((x) => x.video.categoryId === '28') || scoredFeed[2] || scoredFeed[0] },
    { label: 'MUSIC SPOTLIGHT', item: scoredFeed.find((x) => x.video.categoryId === '10') || scoredFeed[3] || scoredFeed[0] },
  ].filter((c) => Boolean(c.item));

  return (
    <div className="flex flex-col gap-4">
      {/* July 2012 Dark Date Strip + 4-Column Feature Header (Matches 1000067168.jpg) */}
      <div className="bg-white border border-[#d4d4d4] rounded-[3px] overflow-hidden shadow-sm">
        <div className="bg-[#555555] text-white px-3 py-1 text-[11px] font-bold tracking-wider uppercase flex items-center justify-between">
          <span>FRIDAY, 27 JULY {era.year} — TEMPORAL SNAPSHOT</span>
          <span className="text-neutral-300 font-mono text-[10px]">
            {era.year === 2011 ? 'COSMIC PANDA EXPERIMENT' : 'GUIDE & CHANNEL FEED'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#e2e2e2]">
          {topColumns.map(({ label, item }) => {
            const v = item.video;
            return (
              <div key={`${label}-${v.id}`} className="p-3 flex flex-col justify-between">
                <div>
                  <div className="text-[11px] font-extrabold text-neutral-700 uppercase tracking-tight mb-2">
                    {label}
                  </div>
                  <button
                    type="button"
                    onClick={() => openVideoDetail(v)}
                    className="relative w-full aspect-video bg-black overflow-hidden border border-neutral-300 group"
                  >
                    <img
                      src={v.thumbnailUrl}
                      alt={v.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <span className="absolute bottom-1 right-1 bg-black/85 text-white font-mono text-[10px] font-bold px-1 rounded-sm">
                      {formatDurationSeconds(v.durationSeconds)}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => openVideoDetail(v)}
                    className="mt-2 text-left text-xs font-bold text-[#1c62b9] hover:underline line-clamp-2"
                  >
                    {v.title}
                  </button>
                </div>
                <div className="mt-1.5 text-[11px] text-neutral-500">
                  <span>{v.channelTitle}</span> • <span>{formatNumber(v.viewCount)} views</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Transitional Channel Activity Rows with "more like this »" pill buttons */}
      <div className="bg-white border border-[#d4d4d4] rounded-[3px] p-3.5 shadow-sm">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-neutral-200">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-neutral-700">
            From Channels & Categories in {era.year}
          </h2>
          <RealityBadge layer="Simulated Historical Experience" compact />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {scoredFeed.map((item) => {
            const v = item.video;
            return (
              <div
                key={v.id}
                className="flex flex-col justify-between p-2.5 rounded border border-neutral-200 bg-[#fbfbfb] hover:bg-white transition-colors"
              >
                <div>
                  <button
                    type="button"
                    onClick={() => openChannelPage(v.channelId)}
                    className="text-[11px] font-bold text-neutral-600 hover:text-[#1c62b9] mb-1.5 block truncate"
                  >
                    {v.channelTitle}
                  </button>
                  <button
                    type="button"
                    onClick={() => openVideoDetail(v)}
                    className="relative w-full aspect-video bg-black overflow-hidden border border-neutral-300"
                  >
                    <img
                      src={v.thumbnailUrl}
                      alt={v.title}
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-1 right-1 bg-black/85 text-white font-mono text-[10px] px-1 rounded-sm">
                      {formatDurationSeconds(v.durationSeconds)}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => openVideoDetail(v)}
                    className="mt-2 text-left text-xs font-bold text-neutral-900 hover:text-[#1c62b9] line-clamp-2"
                  >
                    {v.title}
                  </button>
                  <div className="mt-1 text-[11px] text-neutral-500">
                    {formatNumber(v.viewCount)} views • {formatUtcDateShort(v.publishedAt)}
                  </div>
                </div>

                <div className="mt-2.5 pt-2 border-t border-neutral-200 flex items-center justify-between">
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      item.slotType === 'personalized'
                        ? 'bg-emerald-100 text-emerald-900'
                        : 'bg-indigo-100 text-indigo-900'
                    }`}
                  >
                    {item.slotType === 'personalized' ? '70% Affinity' : '30% Discovery'}
                  </span>
                  <button
                    type="button"
                    onClick={() => markVideoRelevant(v)}
                    className="px-2 py-0.5 text-[10px] font-semibold rounded border border-neutral-300 bg-gradient-to-b from-white to-neutral-100 hover:from-neutral-100 hover:to-neutral-200 text-neutral-700"
                  >
                    more like this »
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// 16E. AUTHENTIC 2014–2019 HITCHHIKER & POLYMER SHELF ARCHITECTURE
//      (Matches 1000067169.jpg & 1000067166.jpg)
// ============================================================================

export function HitchhikerAndPolymerShelves({
  scoredFeed,
  era,
  isPolymerDark,
}: {
  scoredFeed: ScoredVideoCard[];
  era: EraConfig;
  isPolymerDark: boolean;
}) {
  const openChannelPage = useTimeMachineStore((s) => s.openChannelPage);
  const personalizedShelf = scoredFeed.filter((x) => x.slotType === 'personalized');
  const discoveryShelf = scoredFeed.filter((x) => x.slotType === 'discovery');

  const isHitchhiker = era.eraGroup === 'material-modernization';

  return (
    <div className="flex flex-col gap-5">
      {/* Shelf 1: Recommended / Personalized 70% Stream */}
      <section
        className={isHitchhiker ? 'p-4 border bg-white shadow-sm' : 'py-1'}
        style={
          isHitchhiker
            ? {
                backgroundColor: era.surfaceColor,
                borderColor: era.borderColor,
                borderRadius: era.borderRadius,
              }
            : undefined
        }
      >
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2 border-b border-neutral-200/70">
          <div className="flex items-center gap-2">
            {era.eraGroup === 'modern-polymer' && (
              <span className="w-7 h-7 rounded-full bg-red-600 text-white font-bold text-xs flex items-center justify-center">
                YT
              </span>
            )}
            <h2
              className="text-sm font-bold"
              style={{ color: isPolymerDark ? '#ffffff' : era.textColor }}
            >
              Recommended for You ({era.year} Personalized 70% Shelf)
            </h2>
            <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-700 font-semibold">
              {personalizedShelf.length} videos
            </span>
          </div>
          <span className="text-[11px] text-neutral-500">
            {era.eraGroup === 'modern-polymer'
              ? 'Polymer 1.0 Responsive Grid • Verified Creator Badges ✓'
              : 'Hitchhiker Modular Card Shelf'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {(personalizedShelf.length > 0 ? personalizedShelf : scoredFeed.slice(0, 6)).map(
            (item) => (
              <VideoCard key={item.video.id} scoredItem={item} era={era} />
            )
          )}
        </div>
      </section>

      {/* Shelf 2: Temporal Discovery 30% Stream */}
      {discoveryShelf.length > 0 && (
        <section
          className={isHitchhiker ? 'p-4 border bg-white shadow-sm' : 'py-1 border-t pt-4'}
          style={
            isHitchhiker
              ? {
                  backgroundColor: era.surfaceColor,
                  borderColor: era.borderColor,
                  borderRadius: era.borderRadius,
                }
              : { borderColor: isPolymerDark ? '#383838' : era.borderColor }
          }
        >
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <h2
                className="text-sm font-bold"
                style={{ color: isPolymerDark ? '#ffffff' : era.textColor }}
              >
                Recently Published & Temporal Discovery ({era.year} 30% Serendipity Reserve)
              </h2>
              <button
                type="button"
                onClick={() => openChannelPage(discoveryShelf[0].video.channelId)}
                className="text-[11px] text-blue-600 hover:underline font-medium"
              >
                Featured Creator: {discoveryShelf[0].video.channelTitle} ✓
              </button>
            </div>
            <RealityBadge layer="Simulated Historical Experience" compact />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {discoveryShelf.map((item) => (
              <VideoCard key={item.video.id} scoredItem={item} era={era} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

// ============================================================================
// 17. MAIN APP & ERA THEME PROVIDER (Section 16 & 17)
// ============================================================================

export default function App() {
  const currentYear = useTimeMachineStore((s) => s.currentYear);
  const currentEra = useTimeMachineStore((s) => s.currentEra);
  const videos = useTimeMachineStore((s) => s.videos);
  const userProfile = useTimeMachineStore((s) => s.userProfile);
  const selectedCategory = useTimeMachineStore((s) => s.selectedCategory);
  const searchQuery = useTimeMachineStore((s) => s.searchQuery);
  const sortBy = useTimeMachineStore((s) => s.sortBy);
  const setSortBy = useTimeMachineStore((s) => s.setSortBy);
  const loadingState = useTimeMachineStore((s) => s.loadingState);
  const warnings = useTimeMachineStore((s) => s.warnings);
  const mockMode = useTimeMachineStore((s) => s.mockMode);
  const cacheStatus = useTimeMachineStore((s) => s.cacheStatus);
  const activeView = useTimeMachineStore((s) => s.activeView);
  const setActiveView = useTimeMachineStore((s) => s.setActiveView);
  const discoveryMode = useTimeMachineStore((s) => s.discoveryMode);
  const polymerDarkTheme = useTimeMachineStore((s) => s.polymerDarkTheme);
  const toasts = useTimeMachineStore((s) => s.toasts);
  const removeToast = useTimeMachineStore((s) => s.removeToast);

  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [warpState, setWarpState] = useState<{
    active: boolean;
    fromYear: number;
    toYear: number;
    displayYear: number;
  }>({ active: false, fromYear: currentYear, toYear: currentYear, displayYear: currentYear });
  const prevYearRef = useRef<number>(currentYear);

  // Sync URL ?year=YYYY query parameter on load and auto-fetch live stream if API key is saved in localStorage
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const urlYear = Number(params.get('year'));
      if (urlYear >= 2006 && urlYear <= 2019 && urlYear !== currentYear) {
        useTimeMachineStore.getState().setYear(urlYear);
        return;
      }
    } catch {
      // Ignore in restricted iframe
    }
    if (useTimeMachineStore.getState().directYoutubeApiKey) {
      useTimeMachineStore.getState().fetchYearStream();
    }
  }, []);

  useEffect(() => {
    try {
      const url = new URL(window.location.href);
      url.searchParams.set('year', String(currentYear));
      window.history.replaceState({}, '', url.toString());
    } catch {
      // Ignore in sandboxed iframe
    }

    const fromYr = prevYearRef.current;
    if (fromYr !== currentYear) {
      prevYearRef.current = currentYear;
      const reduced = useTimeMachineStore.getState().prefersReducedMotion;
      soundEngine.playTimeWarp(fromYr, currentYear);
      if (!reduced) {
        setWarpState({
          active: true,
          fromYear: fromYr,
          toYear: currentYear,
          displayYear: fromYr,
        });
        const diff = currentYear - fromYr;
        const steps = Math.min(8, Math.abs(diff));
        let step = 0;
        const interval = window.setInterval(() => {
          step += 1;
          const nextDisp =
            step >= steps
              ? currentYear
              : Math.round(fromYr + (diff * step) / steps);
          setWarpState((s) => ({ ...s, displayYear: nextDisp }));
          if (step >= steps) {
            window.clearInterval(interval);
          }
        }, 55);
        const timer = window.setTimeout(() => {
          window.clearInterval(interval);
          setWarpState((s) => ({ ...s, active: false, displayYear: currentYear }));
        }, 560);
        return () => {
          window.clearInterval(interval);
          window.clearTimeout(timer);
        };
      }
    }
    return undefined;
  }, [currentYear]);

  // Compute 70/30 Personalized + Discovery Feed
  const scoredFeed = useMemo(
    () =>
      computeRecommendedFeed(
        videos,
        userProfile,
        currentEra.recommendationProfile,
        currentYear
      ),
    [videos, userProfile, currentEra.recommendationProfile, currentYear]
  );

  const isPolymerDark = currentEra.eraGroup === 'modern-polymer' && polymerDarkTheme;

  // CSS Design Tokens injected cleanly via data-era and data-year (Section 17)
  const themeVariables = useMemo(
    () =>
      ({
        '--tm-bg': isPolymerDark ? '#181818' : currentEra.backgroundColor,
        '--tm-surface': isPolymerDark ? '#202020' : currentEra.surfaceColor,
        '--tm-surface-alt': isPolymerDark ? '#282828' : currentEra.surfaceAltColor,
        '--tm-text': isPolymerDark ? '#ffffff' : currentEra.textColor,
        '--tm-text-muted': isPolymerDark ? '#aaaaaa' : currentEra.mutedTextColor,
        '--tm-link': isPolymerDark ? '#3ea6ff' : currentEra.linkColor,
        '--tm-accent': currentEra.accentColor,
        '--tm-border': isPolymerDark ? '#383838' : currentEra.borderColor,
        '--tm-shadow': currentEra.shadowStyle,
        '--tm-radius': currentEra.borderRadius,
        '--tm-font': currentEra.fontFamily,
        '--tm-font-size': currentEra.fontScale,
        '--tm-content-width':
          discoveryMode === 'enhanced' ? '1360px' : currentEra.maxContentWidth,
        '--tm-header-height': currentEra.headerHeight,
        '--tm-thumbnail-ratio': currentEra.thumbnailAspectRatio,
      }) as React.CSSProperties,
    [currentEra, discoveryMode, isPolymerDark]
  );

  const bounds = getUtcYearBounds(currentYear);
  const personalizedCount = scoredFeed.filter((i) => i.slotType === 'personalized').length;
  const discoveryCount = scoredFeed.filter((i) => i.slotType === 'discovery').length;

  return (
    <div
      data-era={currentEra.eraId}
      data-year={currentYear}
      style={{
        ...themeVariables,
        backgroundColor: 'var(--tm-bg)',
        color: 'var(--tm-text)',
        fontFamily: 'var(--tm-font)',
        fontSize: 'var(--tm-font-size)',
      }}
      className="min-h-screen flex flex-col transition-colors duration-200"
    >
      {/* Full-Screen Time Machine Transition Warp Overlay */}
      <TimeTravelTransitionOverlay
        active={warpState.active}
        fromYear={warpState.fromYear}
        toYear={warpState.toYear}
        displayYear={warpState.displayYear}
        targetEra={currentEra}
      />

      {/* Top Time Machine Timeline Bar */}
      <TimelineSlider />

      {/* Era Global Header */}
      <GlobalHeader onToggleMobileSidebar={() => setMobileSidebarOpen(true)} />

      {/* Pure Era Canvas — Diagnostics moved into Floating Dock & Era Guide */}

      {/* Main Content Container */}
      <main
        className="flex-1 w-full mx-auto px-3 py-4 flex gap-5"
        style={{ maxWidth: 'var(--tm-content-width)' }}
      >
        {/* Period Sidebar (2010–2019 Guide Sidebar; in 2006–2009 YouTube had NO left sidebar and used top folder tabs + right-hand boxes) */}
        {currentEra.eraGroup !== 'classic-web' && currentEra.sidebarMode !== 'none' && (
          <Sidebar
            mobileOpen={mobileSidebarOpen}
            onCloseMobile={() => setMobileSidebarOpen(false)}
          />
        )}

        {/* Primary Viewport */}
        <div className="flex-1 min-w-0">
          {activeView === 'watch' ? (
            <VideoDetailPage />
          ) : activeView === 'channel' ? (
            <ChannelPage />
          ) : activeView === 'history' ? (
            <HistoryPanel />
          ) : activeView === 'saved' ? (
            <SavedVideosPage />
          ) : activeView === 'profile' ? (
            <ProfilePanel />
          ) : activeView === 'era-guide' ? (
            <EraInformationPanel />
          ) : activeView === 'compare' ? (
            <EraComparisonPanel />
          ) : activeView === 'settings' ? (
            <SettingsPanel />
          ) : (
            /* Home / Discovery Stream View */
            <div className="flex flex-col gap-4">
              {/* Compact Filter & Sort Bar (shown when searching or filtering a category, or compactly integrated) */}
              <div
                className={`px-3 py-1.5 border rounded flex flex-wrap items-center justify-between gap-2 text-xs ${
                  !searchQuery && selectedCategory === 'all' ? 'opacity-90' : ''
                }`}
                style={{
                  backgroundColor: 'var(--tm-surface)',
                  borderColor: 'var(--tm-border)',
                  borderRadius: currentEra.borderRadius,
                }}
              >
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-bold">
                    {searchQuery
                      ? `Search Results for "${searchQuery}" in ${currentYear}`
                      : selectedCategory === 'all'
                      ? `${currentYear} Temporal Feed`
                      : `${
                          CATEGORIES.find((c) => c.id === selectedCategory)?.title || 'Category'
                        } (${currentYear})`}
                  </span>
                  <RealityBadge layer="Simulated Historical Experience" compact />
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="text-neutral-500">Sort:</span>
                  {(['relevance', 'viewCount', 'date', 'rating'] as const).map((sKey) => (
                    <button
                      key={sKey}
                      type="button"
                      onClick={() => setSortBy(sKey)}
                      className={`px-2 py-1 rounded text-[11px] font-semibold capitalize ${
                        sortBy === sKey
                          ? 'bg-neutral-900 text-white'
                          : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                      }`}
                    >
                      {sKey === 'viewCount' ? 'Views (Current)' : sKey}
                    </button>
                  ))}
                </div>
              </div>

              {/* Loading / Empty / Video Grid */}
              {loadingState === 'loading' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[1, 2, 3, 4, 5, 6].map((n) => (
                    <div
                      key={n}
                      className="p-3 border rounded animate-pulse bg-white/60 h-56 flex flex-col justify-between"
                    >
                      <div className="w-full h-32 bg-neutral-300 rounded" />
                      <div className="h-4 bg-neutral-300 rounded w-3/4" />
                      <div className="h-3 bg-neutral-200 rounded w-1/2" />
                    </div>
                  ))}
                </div>
              ) : scoredFeed.length === 0 ? (
                <div
                  className="p-8 border rounded text-center"
                  style={{
                    backgroundColor: 'var(--tm-surface)',
                    borderColor: 'var(--tm-border)',
                  }}
                >
                  <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                  <h2 className="text-sm font-bold mb-1">
                    No {currentYear} Videos Matched Your Filter
                  </h2>
                  <p className="text-xs text-neutral-500 mb-3">
                    All results outside {currentYear} are strictly filtered out by the UTC Date Lock.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      useTimeMachineStore.getState().setSearchQuery('');
                      useTimeMachineStore.getState().setCategory('all');
                    }}
                    className="px-3 py-1.5 rounded bg-red-600 text-white text-xs font-bold"
                  >
                    Reset Filters for {currentYear}
                  </button>
                </div>
              ) : currentEra.eraGroup === 'classic-web' ? (
                <ClassicPortalHomeShowcase scoredFeed={scoredFeed} era={currentEra} />
              ) : currentEra.eraGroup === 'transitional' ? (
                <TransitionalPortalShowcase scoredFeed={scoredFeed} era={currentEra} />
              ) : currentEra.eraGroup === 'material-modernization' ||
                currentEra.eraGroup === 'modern-polymer' ? (
                <HitchhikerAndPolymerShelves
                  scoredFeed={scoredFeed}
                  era={currentEra}
                  isPolymerDark={isPolymerDark}
                />
              ) : (
                <div
                  className={`grid grid-cols-1 sm:grid-cols-2 ${
                    currentEra.gridColumns >= 4
                      ? 'lg:grid-cols-3 xl:grid-cols-4'
                      : 'lg:grid-cols-3'
                  } gap-4`}
                >
                  {scoredFeed.map((item) => (
                    <VideoCard key={item.video.id} scoredItem={item} era={currentEra} />
                  ))}
                </div>
              )}

              {/* Dynamic Pagination: Load More Videos for Selected Year */}
              <div className="flex justify-center pt-2 pb-16">
                <button
                  type="button"
                  onClick={() => useTimeMachineStore.getState().loadMoreYearVideos()}
                  className="px-5 py-2 rounded font-bold text-xs border shadow-sm transition-colors hover:opacity-95"
                  style={{
                    backgroundColor: currentEra.surfaceColor,
                    borderColor: currentEra.borderColor,
                    color: currentEra.eraGroup === 'classic-web' ? '#0033cc' : currentEra.textColor,
                  }}
                >
                  Load More {currentYear} Videos from YouTube Archive / API »
                </button>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Toast Notification Stack */}
      {toasts.length > 0 && (
        <div
          className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm"
          role="status"
          aria-live="polite"
        >
          {toasts.map((t) => (
            <div
              key={t.id}
              className="p-3 rounded shadow-lg border bg-neutral-900 text-white text-xs flex items-start justify-between gap-2"
            >
              <div>
                <p className="font-bold text-amber-300">{t.title}</p>
                {t.description && <p className="text-neutral-300 mt-0.5">{t.description}</p>}
              </div>
              <button
                type="button"
                onClick={() => removeToast(t.id)}
                className="text-neutral-400 hover:text-white"
                aria-label="Dismiss notification"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Footer */}
      <footer
        className="w-full border-t mt-8 px-3 py-4 text-xs"
        style={{
          backgroundColor: 'var(--tm-surface)',
          borderColor: 'var(--tm-border)',
          color: 'var(--tm-text-muted)',
        }}
      >
        <div
          className="mx-auto flex flex-wrap items-center justify-between gap-2"
          style={{ maxWidth: 'var(--tm-content-width)' }}
        >
          <div>
            <strong>Retro YouTube Time Machine (2006–2019)</strong> • Era:{' '}
            <span className="font-mono">{currentEra.eraId}</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setActiveView('era-guide')}
              className="hover:underline"
            >
              Historical Methodology & Sources
            </button>
            <button
              type="button"
              onClick={() => setActiveView('profile')}
              className="hover:underline"
            >
              70/30 Recommendation Engine
            </button>
            <button
              type="button"
              onClick={() => setActiveView('settings')}
              className="hover:underline"
            >
              API & Region Settings
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
