import { RecommendationProfile } from '../config/eras/eraTypes';

export const INTERACTION_WEIGHTS = {
  CARD_CLICK: 10,
  WATCH_DURATION_BONUS_MAX: 14,
  REPEAT_CLICK_CAP: 4,
  SAVE_VIDEO: 12,
  MARK_RELEVANT: 8,
  DISMISS_VIDEO: -12,
} as const;

export interface UserProfileData {
  version: number;
  categoryScores: Record<string, number>;
  channelScores: Record<string, number>;
  watchedVideoIds: string[];
  watchDurationsSec: Record<string, number>;
  clickedVideoIds: string[];
  clickCountsByVideo: Record<string, number>;
  savedVideoIds: string[];
  dismissedVideoIds: string[];
  subscribedChannelIds: string[];
  localStarRatings: Record<string, number>;
  localLikes: Record<string, 'like' | 'dislike'>;
  searchHistory: string[];
  recentlyWatched: Array<{
    videoId: string;
    title: string;
    channelTitle: string;
    categoryId: string;
    year: number;
    watchedAt: string;
    watchedSeconds: number;
    source: string;
  }>;
  preferredYears: number[];
  sessionCount: number;
  lastActiveAt: string;
  lastSelectedYear: number;
  onboardingCompleted: boolean;
  discoveryPreference: number; // default 0.30 (30% discovery, 70% personalized)
}

export interface ScoredVideoItem<T> {
  video: T;
  totalScore: number;
  slotType: 'personalized' | 'discovery';
  breakdown: {
    categoryAffinity: number;
    discoveryBonus: number;
    freshnessWithinEra: number;
    relevance: number;
    qualitySignal: number;
    repetitionPenalty: number;
    dismissalPenalty: number;
  };
}

/**
 * Deterministic hash in [0, 1] for reproducible discovery ordering without uncontrolled Math.random().
 */
export function deterministicSeedScore(id: string, year: number, sessionCount: number): number {
  const input = `${id}:${year}:${sessionCount}`;
  let h = 2166136261;
  for (let i = 0; i < input.length; i += 1) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 1000) / 1000;
}

/**
 * Ranks a year-verified video pool using the 70/30 personalized vs. discovery strategy (Section 9.4 & 9.5).
 */
export function buildRecommendedFeed<
  T extends {
    id: string;
    categoryId: string;
    channelId: string;
    publishedAt: string;
    historicalYear: number;
    viewCount: number | null;
    likeCount: number | null;
  }
>(
  videos: T[],
  profile: UserProfileData,
  recProfile: RecommendationProfile,
  targetYear: number
): ScoredVideoItem<T>[] {
  const dismissedSet = new Set(profile.dismissedVideoIds);
  const clickedSet = new Set(profile.clickedVideoIds);
  const watchedSet = new Set(profile.watchedVideoIds);
  const seenIds = new Set<string>();

  // Filter strictly to target year and non-dismissed unique IDs
  const validPool = videos.filter((v) => {
    if (!v.id || seenIds.has(v.id)) return false;
    if (v.historicalYear !== targetYear) return false;
    if (dismissedSet.has(v.id)) return false;
    seenIds.add(v.id);
    return true;
  });

  if (validPool.length === 0) return [];

  const maxCatScore = Math.max(1, ...Object.values(profile.categoryScores), 1);
  const sortedCategories = Object.entries(profile.categoryScores)
    .filter(([, score]) => score > 0)
    .sort((a, b) => b[1] - a[1])
    .map(([catId]) => catId);

  const topPersonalizedCategories = new Set(sortedCategories.slice(0, 2));
  const hasUserPreferences = topPersonalizedCategories.size > 0;

  const scoredAll: ScoredVideoItem<T>[] = validPool.map((video) => {
    const rawCatScore = profile.categoryScores[video.categoryId] ?? 0;
    const normalizedCat = Math.max(0, Math.min(25, (rawCatScore / maxCatScore) * 25));
    const channelBoost = (profile.channelScores[video.channelId] ?? 0) > 0 ? 5 : 0;
    const watchSeconds = profile.watchDurationsSec[video.id] ?? 0;
    const watchSignal = Math.min(8, (watchSeconds / 60) * 3) * recProfile.watchTimeSignalWeight;

    const categoryAffinity = Number(
      (normalizedCat * recProfile.categoryAffinityWeight + channelBoost * recProfile.channelAffinityWeight).toFixed(2)
    );

    const isUnseenCategory = rawCatScore <= 0;
    const isUnclicked = !clickedSet.has(video.id);
    const seedVal = deterministicSeedScore(video.id, targetYear, profile.sessionCount);
    const discoveryBonus = Number(
      (((isUnseenCategory ? 10 : 3) + (isUnclicked ? 6 : 0) + seedVal * 5) * recProfile.discoveryBonusWeight).toFixed(2)
    );

    // Spread across months within the selected year (never penalizes older years)
    const pubMonth = new Date(Date.parse(video.publishedAt) || Date.UTC(targetYear, 5, 1)).getUTCMonth();
    const freshnessWithinEra = Number(
      ((((pubMonth + 1) / 12) * 4 + seedVal * 3) * recProfile.freshnessSpreadWeight).toFixed(2)
    );

    const relevance = Number((10 + watchSignal).toFixed(2));

    const safeViews = Math.max(0, video.viewCount ?? 0);
    const safeLikes = Math.max(0, video.likeCount ?? 0);
    const engagementRatio = safeViews > 0 ? safeLikes / safeViews : 0.02;
    const qualitySignal = Number(
      (Math.min(10, engagementRatio * 200) * recProfile.qualitySignalWeight).toFixed(2)
    );

    const clickCount = profile.clickCountsByVideo[video.id] ?? 0;
    const repetitionPenalty = Number(
      ((watchedSet.has(video.id) ? 8 : 0) + Math.min(12, clickCount * 4) * recProfile.repetitionPenaltyWeight).toFixed(2)
    );

    const dismissalPenalty = dismissedSet.has(video.id) ? 100 * recProfile.dismissalPenaltyWeight : 0;

    const totalScore = Number(
      (
        categoryAffinity +
        discoveryBonus +
        freshnessWithinEra +
        relevance +
        qualitySignal -
        repetitionPenalty -
        dismissalPenalty
      ).toFixed(2)
    );

    const isPersonalizedCandidate =
      hasUserPreferences &&
      (topPersonalizedCategories.has(video.categoryId) ||
        profile.subscribedChannelIds.includes(video.channelId));

    return {
      video,
      totalScore,
      slotType: isPersonalizedCandidate ? 'personalized' : 'discovery',
      breakdown: {
        categoryAffinity,
        discoveryBonus,
        freshnessWithinEra,
        relevance,
        qualitySignal,
        repetitionPenalty,
        dismissalPenalty,
      },
    };
  });

  const totalCount = scoredAll.length;
  const discoveryRatio = Math.min(0.5, Math.max(0.15, profile.discoveryPreference || recProfile.discoveryRatio || 0.3));
  const personalizedTargetCount = Math.round(totalCount * (1 - discoveryRatio));
  const discoveryTargetCount = totalCount - personalizedTargetCount;

  const personalizedBucket = scoredAll
    .filter((item) => item.slotType === 'personalized')
    .sort((a, b) => b.totalScore - a.totalScore);

  const discoveryBucket = scoredAll
    .filter((item) => item.slotType === 'discovery')
    .sort((a, b) => b.breakdown.discoveryBonus + b.totalScore * 0.4 - (a.breakdown.discoveryBonus + a.totalScore * 0.4));

  const finalFeed: ScoredVideoItem<T>[] = [];
  const usedIds = new Set<string>();

  for (const item of personalizedBucket) {
    if (finalFeed.length >= personalizedTargetCount) break;
    finalFeed.push({ ...item, slotType: 'personalized' });
    usedIds.add(item.video.id);
  }

  // If user is new or personalized bucket has fewer items than 70%, promote highest-scoring items while preserving 30% discovery
  if (finalFeed.length < personalizedTargetCount) {
    const remainingForPersonalized = scoredAll
      .filter((i) => !usedIds.has(i.video.id))
      .sort((a, b) => b.totalScore - a.totalScore);

    for (const item of remainingForPersonalized) {
      if (finalFeed.length >= personalizedTargetCount) break;
      finalFeed.push({
        ...item,
        slotType: hasUserPreferences ? 'personalized' : 'discovery',
      });
      usedIds.add(item.video.id);
    }
  }

  for (const item of discoveryBucket) {
    if (usedIds.has(item.video.id)) continue;
    if (finalFeed.length >= personalizedTargetCount + discoveryTargetCount) break;
    finalFeed.push({ ...item, slotType: 'discovery' });
    usedIds.add(item.video.id);
  }

  for (const item of scoredAll) {
    if (!usedIds.has(item.video.id)) {
      finalFeed.push({ ...item, slotType: 'discovery' });
      usedIds.add(item.video.id);
    }
  }

  return finalFeed;
}
