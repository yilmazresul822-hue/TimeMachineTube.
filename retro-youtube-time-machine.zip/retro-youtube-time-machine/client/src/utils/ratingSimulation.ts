export interface RatingSimulationResult {
  stars: number;
  roundedHalfStars: number;
  confidence: 'low' | 'medium' | 'high';
  sampleSize: number;
  engagementRatio: number;
  isSimulated: true;
  methodologyNote: string;
}

export function computeSimulatedStarRating(
  videoId: string,
  viewCount: number | null,
  likeCount: number | null,
  commentCount: number | null
): RatingSimulationResult | null {
  if (viewCount === null && likeCount === null) {
    return null;
  }
  const safeViews = Math.max(0, viewCount ?? 0);
  const safeLikes = Math.max(0, likeCount ?? 0);
  const safeComments = Math.max(0, commentCount ?? 0);
  if (safeViews === 0 && safeLikes === 0) {
    return null;
  }

  let hash = 0;
  for (let i = 0; i < videoId.length; i += 1) {
    hash = (hash * 31 + videoId.charCodeAt(i)) % 1000;
  }
  const deterministicJitter = ((hash % 21) - 10) * 0.01;
  const effectiveDenominator = Math.max(safeViews, safeLikes, 1);
  const likeRatio = safeLikes / effectiveDenominator;
  const engagementRatio = (safeLikes + safeComments * 1.5) / effectiveDenominator;
  const normalizedEngagement = Math.min(
    1,
    Math.max(0, Math.log10(Math.max(engagementRatio * 1000, 1)) / Math.log10(80))
  );

  const rawStars = 2.6 + normalizedEngagement * 2.3 + deterministicJitter;
  const clampedStars = Math.min(5.0, Math.max(1.0, Number(rawStars.toFixed(2))));
  const roundedHalfStars = Math.min(5.0, Math.max(1.0, Math.round(clampedStars * 2) / 2));

  let confidence: 'low' | 'medium' | 'high' = 'low';
  if (safeViews >= 50_000 && safeLikes >= 250) {
    confidence = 'high';
  } else if (safeViews >= 1_000 && safeLikes >= 15) {
    confidence = 'medium';
  }

  return {
    stars: clampedStars,
    roundedHalfStars,
    confidence,
    sampleSize: safeLikes + safeComments,
    engagementRatio: Number(likeRatio.toFixed(4)),
    isSimulated: true,
    methodologyNote:
      'Simulated 5-star rating derived from engagement density (likes & comments relative to log-scaled views). Historical 2006-2009 star ratings are not exposed by YouTube Data API v3.',
  };
}
