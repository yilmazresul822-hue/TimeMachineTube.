import { describe, expect, it } from 'vitest';
import {
  ERA_CONFIGS,
  SUPPORTED_YEARS,
  computeRecommendedFeed,
  computeSimulatedStarRating,
  createDefaultProfile,
  getUtcYearBounds,
  validateAndSanitizeProfile,
  verifyPublishedYearUtc,
  MOCK_CATALOG_BY_YEAR,
} from '../App';

describe('Retro YouTube Time Machine — Frontend Unit & Architecture Suite', () => {
  it('defines distinct EraConfig records for every year 2006 through 2019', () => {
    expect(SUPPORTED_YEARS.length).toBe(14);
    for (let y = 2006; y <= 2019; y += 1) {
      const cfg = ERA_CONFIGS[y];
      expect(cfg).toBeDefined();
      expect(cfg.year).toBe(y);
      expect(cfg.showStarRatingSimulation).toBe(y <= 2009);
      expect(cfg.showLikeDislikeBar).toBe(y >= 2010);
    }
  });

  it('enforces 70/30 personalized vs discovery split and prevents duplicates', () => {
    const profile = createDefaultProfile();
    profile.categoryScores = { '10': 40, '20': 30 };
    const pool = MOCK_CATALOG_BY_YEAR[2008];
    const era = ERA_CONFIGS[2008];
    const ranked = computeRecommendedFeed(pool, profile, era.recommendationProfile, 2008);

    expect(ranked.length).toBe(pool.length);
    const ids = new Set(ranked.map((r) => r.video.id));
    expect(ids.size).toBe(ranked.length);

    const personalized = ranked.filter((r) => r.slotType === 'personalized').length;
    const discovery = ranked.filter((r) => r.slotType === 'discovery').length;
    expect(personalized).toBe(Math.round(pool.length * 0.7));
    expect(discovery).toBe(pool.length - personalized);
  });

  it('recovers safely from corrupted localStorage profile payloads', () => {
    const res1 = validateAndSanitizeProfile(null);
    expect(res1.recoveredFromCorruption).toBe(true);
    expect(res1.profile.version).toBe(2);

    const res2 = validateAndSanitizeProfile({ version: 999, categoryScores: 'bad' });
    expect(res2.recoveredFromCorruption).toBe(true);
  });

  it('verifies UTC dates and rejects out-of-year videos', () => {
    const bounds = getUtcYearBounds(2015);
    expect(bounds.publishedAfter).toBe('2015-01-01T00:00:00Z');
    expect(bounds.publishedBefore).toBe('2016-01-01T00:00:00Z');
    expect(verifyPublishedYearUtc('2015-06-15T12:00:00Z', 2015)).toBe(true);
    expect(verifyPublishedYearUtc('2016-01-01T00:00:00Z', 2015)).toBe(false);
  });

  it('calculates bounded 1.0–5.0 simulated star ratings deterministically', () => {
    const sim1 = computeSimulatedStarRating('vid-a', 250000, 12000, 900);
    const sim2 = computeSimulatedStarRating('vid-a', 250000, 12000, 900);
    expect(sim1).toEqual(sim2);
    expect(sim1!.stars).toBeGreaterThanOrEqual(1.0);
    expect(sim1!.stars).toBeLessThanOrEqual(5.0);
  });
});
