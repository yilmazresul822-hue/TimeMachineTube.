import { ERA_CONFIGS } from './index';
export const era2010 = ERA_CONFIGS[2010];
export default era2010;
