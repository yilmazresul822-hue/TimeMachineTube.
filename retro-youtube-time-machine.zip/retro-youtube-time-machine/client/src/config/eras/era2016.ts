import { ERA_CONFIGS } from './index';
export const era2016 = ERA_CONFIGS[2016];
export default era2016;
