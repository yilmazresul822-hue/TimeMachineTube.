import { ERA_CONFIGS } from './index';
export const era2013 = ERA_CONFIGS[2013];
export default era2013;
