import { ERA_CONFIGS } from './index';
export const era2007 = ERA_CONFIGS[2007];
export default era2007;
