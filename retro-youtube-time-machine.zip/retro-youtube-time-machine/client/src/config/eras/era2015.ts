import { ERA_CONFIGS } from './index';
export const era2015 = ERA_CONFIGS[2015];
export default era2015;
