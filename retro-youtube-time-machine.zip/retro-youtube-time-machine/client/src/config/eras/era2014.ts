import { ERA_CONFIGS } from './index';
export const era2014 = ERA_CONFIGS[2014];
export default era2014;
