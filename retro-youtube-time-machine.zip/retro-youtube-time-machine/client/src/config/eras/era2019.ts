import { ERA_CONFIGS } from './index';
export const era2019 = ERA_CONFIGS[2019];
export default era2019;
