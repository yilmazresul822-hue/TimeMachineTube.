import { ERA_CONFIGS } from './index';
export const era2012 = ERA_CONFIGS[2012];
export default era2012;
