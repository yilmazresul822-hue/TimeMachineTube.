import { ERA_CONFIGS } from './index';
export const era2008 = ERA_CONFIGS[2008];
export default era2008;
