import { ERA_CONFIGS } from './index';
export const era2006 = ERA_CONFIGS[2006];
export default era2006;
