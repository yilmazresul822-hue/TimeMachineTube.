export type RealityLayer =
  | 'Historical Reference'
  | 'Live YouTube Data'
  | 'Simulated Historical Experience'
  | 'Estimated Reconstruction';

export type HistoricalConfidence = 'high' | 'medium-high' | 'estimated-reconstruction';

export interface RecommendationProfile {
  profileId: string;
  eraGroup: '2006-2009' | '2010-2013' | '2014-2016' | '2017-2019';
  personalizedRatio: number; // default 0.70
  discoveryRatio: number;    // default 0.30
  categoryAffinityWeight: number;
  watchTimeSignalWeight: number;
  channelAffinityWeight: number;
  discoveryBonusWeight: number;
  freshnessSpreadWeight: number;
  qualitySignalWeight: number;
  repetitionPenaltyWeight: number;
  dismissalPenaltyWeight: number;
  description: string;
}

export interface SourceReference {
  title: string;
  url: string;
  layer: RealityLayer;
}

export interface EraConfig {
  year: number;
  eraId: string;
  eraLabel: string;
  eraGroup: 'classic-web' | 'transitional' | 'material-modernization' | 'modern-polymer';
  historicalConfidence: HistoricalConfidence;
  layoutMode: 'portal-centered' | 'structured-960' | 'card-grid-fluid' | 'polymer-wide';
  maxContentWidth: string;
  headerHeight: string;
  navigationMode: 'top-tabs' | 'sub-header-links' | 'guide-drawer' | 'polymer-top-and-mini';
  sidebarMode: 'none' | 'classic-boxes' | 'guide-persistent' | 'polymer-collapsible';
  gridColumns: number;
  thumbnailAspectRatio: '4/3' | '16/9';
  fontFamily: string;
  fontScale: string;
  backgroundColor: string;
  surfaceColor: string;
  surfaceAltColor: string;
  textColor: string;
  mutedTextColor: string;
  linkColor: string;
  borderColor: string;
  accentColor: string;
  buttonStyle: 'glossy-amber' | 'gradient-silver' | 'flat-blue-red' | 'material-raised' | 'polymer-pill';
  cardStyle: 'bordered-box' | 'compact-portal' | 'hitchhiker-card' | 'material-surface' | 'polymer-clean';
  shadowStyle: string;
  borderRadius: string;
  spacingScale: 'compact' | 'normal' | 'spacious';
  showStarRatingSimulation: boolean;
  showLikeDislikeBar: boolean;
  showModernSubscribeButton: boolean;
  showAvatar: boolean;
  showComments: boolean;
  showViewCount: boolean;
  showPublishedDate: boolean;
  searchPresentation: 'boxed-utility' | 'inset-gradient' | 'centered-blue-btn' | 'polymer-minimal';
  loadingStyle: 'classic-text-bar' | 'spinner-red' | 'material-linear' | 'skeleton-cards';
  transitionStyle: 'instant-portal' | 'fade-stage' | 'material-elevation' | 'smooth-polymer';
  recommendationProfile: RecommendationProfile;
  playbackPageLayout: 'classic-right-meta' | 'cosmic-dark-stage' | 'hitchhiker-two-col' | 'polymer-theater';
  channelPageLayout: 'classic-profile-boxes' | 'cosmic-modular' | 'one-channel-banner' | 'polymer-channel-tabs';
  mobileOverrides: {
    collapseSidebar: boolean;
    singleColumnBelowPx: number;
    touchFriendlyControls: boolean;
  };
  historicalNotes: string[];
  verifiedFeatures: string[];
  simulatedFeatures: string[];
  sourceReferences: SourceReference[];
}
