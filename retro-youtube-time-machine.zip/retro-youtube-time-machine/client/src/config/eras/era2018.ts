import { ERA_CONFIGS } from './index';
export const era2018 = ERA_CONFIGS[2018];
export default era2018;
