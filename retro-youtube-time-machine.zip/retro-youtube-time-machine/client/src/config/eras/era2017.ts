import { ERA_CONFIGS } from './index';
export const era2017 = ERA_CONFIGS[2017];
export default era2017;
