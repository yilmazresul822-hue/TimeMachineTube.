import { ERA_CONFIGS } from './index';
export const era2009 = ERA_CONFIGS[2009];
export default era2009;
