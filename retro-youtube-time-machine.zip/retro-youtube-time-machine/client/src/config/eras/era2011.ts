import { ERA_CONFIGS } from './index';
export const era2011 = ERA_CONFIGS[2011];
export default era2011;
