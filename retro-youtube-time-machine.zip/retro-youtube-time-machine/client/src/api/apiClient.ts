export interface ApiRequestOptions {
  signal?: AbortSignal;
  params?: Record<string, string | number | undefined | null>;
}

const DEFAULT_BASE_URL =
  (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_API_BASE_URL) ||
  'http://localhost:4000';

export async function apiGet<T>(path: string, options: ApiRequestOptions = {}): Promise<T> {
  const url = new URL(path, DEFAULT_BASE_URL);
  if (options.params) {
    for (const [k, v] of Object.entries(options.params)) {
      if (v !== undefined && v !== null && v !== '') {
        url.searchParams.set(k, String(v));
      }
    }
  }
  const response = await fetch(url.toString(), {
    method: 'GET',
    headers: { Accept: 'application/json' },
    signal: options.signal,
  });
  if (!response.ok) {
    const errBody = await response.json().catch(() => ({}));
    throw new Error(errBody?.error?.message || `HTTP ${response.status}`);
  }
  return response.json() as Promise<T>;
}
