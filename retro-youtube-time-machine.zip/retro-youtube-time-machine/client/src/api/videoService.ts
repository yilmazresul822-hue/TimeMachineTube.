import { apiGet } from './apiClient';
import { Video } from '../App';

export interface VideoStreamResponse {
  items: Video[];
  year: number;
  mode: string;
  source: 'youtube-api' | 'mock-fallback' | 'cache';
  isMock: boolean;
  nextPageToken: string | null;
  hasMore: boolean;
  totalResults: number | null;
  cacheStatus: 'HIT' | 'MISS' | 'BYPASS' | 'MOCK_FALLBACK';
  warnings: string[];
  requestId: string;
}

export async function fetchVideosByYear(
  params: {
    year: number;
    categoryId?: string;
    regionCode?: string | null;
    query?: string;
    sort?: string;
    limit?: number;
  },
  signal?: AbortSignal
): Promise<VideoStreamResponse> {
  return apiGet<VideoStreamResponse>('/api/videos', { params, signal });
}
