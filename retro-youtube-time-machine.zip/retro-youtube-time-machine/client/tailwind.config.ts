import type { Config } from 'tailwindcss';

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        tmBg: 'var(--tm-bg)',
        tmSurface: 'var(--tm-surface)',
        tmSurfaceAlt: 'var(--tm-surface-alt)',
        tmText: 'var(--tm-text)',
        tmMuted: 'var(--tm-text-muted)',
        tmLink: 'var(--tm-link)',
        tmAccent: 'var(--tm-accent)',
        tmBorder: 'var(--tm-border)',
      },
      fontFamily: {
        tm: 'var(--tm-font)',
      },
    },
  },
  plugins: [],
} satisfies Config;
