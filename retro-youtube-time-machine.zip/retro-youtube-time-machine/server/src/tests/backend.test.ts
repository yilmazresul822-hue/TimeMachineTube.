import { describe, expect, it } from 'vitest';
import {
  getUtcYearBounds,
  isSupportedYear,
  resolveRegionPolicy,
  verifyPublishedYearUtc,
} from '../utils/dateLock';
import { computeSimulatedStarRating } from '../utils/ratingSimulation';
import { QuotaSafeCacheService } from '../services/cacheService';
import { getMockVideosForQuery } from '../data/mockVideos';

describe('Retro YouTube Time Machine — Backend Unit & Integration Suite', () => {
  it('validates supported years strictly between 2006 and 2019', () => {
    expect(isSupportedYear(2005)).toBe(false);
    expect(isSupportedYear(2006)).toBe(true);
    expect(isSupportedYear(2012)).toBe(true);
    expect(isSupportedYear(2019)).toBe(true);
    expect(isSupportedYear(2020)).toBe(false);
  });

  it('computes strict UTC year boundaries using next-year start', () => {
    const bounds = getUtcYearBounds(2012);
    expect(bounds.publishedAfter).toBe('2012-01-01T00:00:00Z');
    expect(bounds.publishedBefore).toBe('2013-01-01T00:00:00Z');
  });

  it('verifies publishedAt timestamps in UTC without timezone drift', () => {
    expect(verifyPublishedYearUtc('2012-01-01T00:00:00Z', 2012)).toBe(true);
    expect(verifyPublishedYearUtc('2012-12-31T23:59:59Z', 2012)).toBe(true);
    expect(verifyPublishedYearUtc('2013-01-01T00:00:00Z', 2012)).toBe(false);
    expect(verifyPublishedYearUtc('2011-12-31T23:59:59Z', 2012)).toBe(false);
  });

  it('applies Global Chaos Filter (no regionCode in 2006-2011, US default in 2012-2019)', () => {
    expect(resolveRegionPolicy(2008, null)).toEqual({
      regionCode: null,
      globalChaosActive: true,
    });
    expect(resolveRegionPolicy(2015, null)).toEqual({
      regionCode: 'US',
      globalChaosActive: false,
    });
    expect(resolveRegionPolicy(2009, 'JP')).toEqual({
      regionCode: 'JP',
      globalChaosActive: false,
    });
  });

  it('computes deterministic 1..5 star ratings and handles missing/zero stats safely', () => {
    expect(computeSimulatedStarRating('v1', null, null, null)).toBeNull();
    expect(computeSimulatedStarRating('v1', 0, 0, 0)).toBeNull();
    const sim = computeSimulatedStarRating('vid-2007', 120_000, 4_800, 520);
    expect(sim).not.toBeNull();
    expect(sim!.stars).toBeGreaterThanOrEqual(1);
    expect(sim!.stars).toBeLessThanOrEqual(5);
    expect(sim!.isSimulated).toBe(true);
  });

  it('deduplicates concurrent in-flight cache requests for the same key', async () => {
    const cache = new QuotaSafeCacheService(900);
    let upstreamCallCount = 0;
    const key = cache.buildKey({ endpoint: 'videos', year: 2008, categoryId: '20' });

    const concurrentCalls = Array.from({ length: 10 }, () =>
      cache.getOrFetch(key, async () => {
        upstreamCallCount += 1;
        await new Promise((r) => setTimeout(r, 25));
        return { data: ['video-a', 'video-b'], cacheable: true };
      })
    );

    const results = await Promise.all(concurrentCalls);
    expect(upstreamCallCount).toBe(1);
    expect(results[0].data).toEqual(['video-a', 'video-b']);
  });

  it('returns only videos matching the selected year in mock fallback mode', () => {
    const videos2009 = getMockVideosForQuery({ year: 2009 });
    expect(videos2009.length).toBeGreaterThan(0);
    for (const v of videos2009) {
      expect(v.historicalYear).toBe(2009);
      expect(verifyPublishedYearUtc(v.publishedAt, 2009)).toBe(true);
      expect(v.isMock).toBe(true);
    }
  });
});
