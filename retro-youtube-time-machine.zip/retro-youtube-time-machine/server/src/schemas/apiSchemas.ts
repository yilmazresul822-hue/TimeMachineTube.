import { z } from 'zod';
import { MAX_SUPPORTED_YEAR, MIN_SUPPORTED_YEAR } from '../utils/dateLock';

export const videosQuerySchema = z.object({
  year: z.coerce
    .number()
    .int()
    .min(MIN_SUPPORTED_YEAR, `Year must be at least ${MIN_SUPPORTED_YEAR}`)
    .max(MAX_SUPPORTED_YEAR, `Year must be at most ${MAX_SUPPORTED_YEAR}`)
    .default(2008),
  categoryId: z
    .string()
    .trim()
    .regex(/^([0-9]{1,3}|all)$/, 'Invalid categoryId format')
    .optional(),
  regionCode: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z]{2}$/, 'regionCode must be ISO 3166-1 alpha-2 (e.g. US, TR, GB, JP)')
    .optional(),
  query: z
    .string()
    .trim()
    .max(100, 'Search query must not exceed 100 characters')
    .optional(),
  pageToken: z
    .string()
    .trim()
    .max(64, 'Invalid pageToken')
    .regex(/^[A-Za-z0-9_-]+$/, 'Invalid pageToken characters')
    .optional(),
  limit: z.coerce.number().int().min(1).max(36).default(24),
  sort: z.enum(['relevance', 'viewCount', 'date', 'rating']).default('relevance'),
  mode: z.enum(['feed', 'search', 'category', 'channel']).default('feed'),
  channelId: z.string().trim().max(64).optional(),
});

export const searchQuerySchema = videosQuerySchema.extend({
  query: z
    .string()
    .trim()
    .min(1, 'Search query cannot be empty')
    .max(100, 'Search query must not exceed 100 characters'),
});

export const videoIdParamSchema = z.object({
  videoId: z
    .string()
    .trim()
    .min(3)
    .max(32)
    .regex(/^[A-Za-z0-9_-]+$/, 'Invalid videoId format'),
});
