import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import { envConfig } from './config/env';
import { securityAndRequestIdMiddleware } from './middleware/securityHeaders';
import { rateLimiterMiddleware } from './middleware/rateLimiter';
import { apiRouter } from './routes/apiRoutes';
import { logger } from './utils/logger';

export function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.use(securityAndRequestIdMiddleware);
  app.use(
    cors({
      origin: envConfig.corsOrigin,
      methods: ['GET', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Accept', 'X-Request-Id'],
    })
  );
  app.use(express.json({ limit: '64kb' }));
  app.use('/api', rateLimiterMiddleware, apiRouter);

  app.use((_req: Request, res: Response) => {
    res.status(404).json({
      error: {
        code: 'VIDEO_NOT_FOUND',
        message: 'Requested API endpoint does not exist.',
        userAction: 'Verify the API URL path.',
        requestId: String(res.locals.requestId || 'req-404'),
      },
    });
  });

  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    logger.error({ err: err.message, requestId: res.locals.requestId }, 'Unhandled server error');
    res.status(500).json({
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: 'An unexpected error occurred on the server.',
        userAction: 'Please retry your request or continue in local archive mode.',
        requestId: String(res.locals.requestId || 'req-500'),
      },
    });
  });

  return app;
}
