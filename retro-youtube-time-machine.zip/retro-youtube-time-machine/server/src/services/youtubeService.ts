import axios, { AxiosInstance } from 'axios';
import { envConfig } from '../config/env';
import {
  KNOWN_CATEGORIES,
  MOCK_VIDEOS_BY_YEAR,
  getMockVideosForQuery,
} from '../data/mockVideos';
import {
  ApiSingleVideoResponse,
  ApiVideoListResponse,
  CategoryItem,
  Video,
} from '../types/api';
import {
  getUtcYearBounds,
  resolveRegionPolicy,
  verifyPublishedYearUtc,
} from '../utils/dateLock';
import { logger } from '../utils/logger';
import { computeSimulatedStarRating } from '../utils/ratingSimulation';
import { cacheService } from './cacheService';

export function parseIso8601DurationToSeconds(iso: string | undefined): number {
  if (!iso || typeof iso !== 'string') return 0;
  const match = iso.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/);
  if (!match) return 0;
  const hours = Number.parseInt(match[1] || '0', 10);
  const minutes = Number.parseInt(match[2] || '0', 10);
  const seconds = Number.parseInt(match[3] || '0', 10);
  return hours * 3600 + minutes * 60 + seconds;
}

export function safeParseCount(raw: unknown): number | null {
  if (raw === undefined || raw === null || raw === '') return null;
  const parsed = Number.parseInt(String(raw), 10);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

export class YouTubeService {
  private http: AxiosInstance;

  constructor(httpClient?: AxiosInstance) {
    this.http =
      httpClient ??
      axios.create({
        baseURL: 'https://www.googleapis.com/youtube/v3',
        timeout: 8_000,
      });
  }

  public async fetchVideos(params: {
    year: number;
    categoryId?: string;
    regionCode?: string;
    query?: string;
    pageToken?: string;
    limit: number;
    sort: 'relevance' | 'viewCount' | 'date' | 'rating';
    mode: 'feed' | 'search' | 'category' | 'channel';
    channelId?: string;
    requestId: string;
  }): Promise<ApiVideoListResponse> {
    const bounds = getUtcYearBounds(params.year);
    const regionPolicy = resolveRegionPolicy(params.year, params.regionCode);

    if (!envConfig.youtubeApiKey) {
      const mockItems = getMockVideosForQuery({
        year: params.year,
        categoryId: params.categoryId,
        query: params.query,
        channelId: params.channelId,
        sort: params.sort,
        limit: params.limit,
      });
      return {
        items: mockItems,
        year: params.year,
        mode: params.mode,
        source: 'mock-fallback',
        isMock: true,
        nextPageToken: null,
        hasMore: false,
        totalResults: mockItems.length,
        cacheStatus: 'MOCK_FALLBACK',
        warnings: [
          'YOUTUBE_API_KEY is not configured on the backend. Serving period-verified local mock dataset.',
        ],
        requestId: params.requestId,
        appliedDateLock: {
          publishedAfter: bounds.publishedAfter,
          publishedBefore: bounds.publishedBefore,
          regionCode: regionPolicy.regionCode,
          globalChaosActive: regionPolicy.globalChaosActive,
        },
      };
    }

    const cacheKey = cacheService.buildKey({
      endpoint: 'videos',
      year: params.year,
      categoryId: params.categoryId,
      regionCode: regionPolicy.regionCode,
      query: params.query,
      pageToken: params.pageToken,
      sort: params.sort,
      limit: params.limit,
      channelId: params.channelId,
    });

    try {
      const { data, cacheStatus } = await cacheService.getOrFetch(
        cacheKey,
        async () => {
          const searchParams: Record<string, string | number> = {
            part: 'snippet',
            type: 'video',
            maxResults: Math.min(params.limit, 36),
            publishedAfter: bounds.publishedAfter,
            publishedBefore: bounds.publishedBefore,
            order: params.sort,
            safeSearch: 'moderate',
            key: envConfig.youtubeApiKey!,
          };

          if (params.query && params.query.trim().length > 0) {
            searchParams.q = params.query.trim();
          } else {
            searchParams.q = `${params.year}`;
          }

          if (params.categoryId && params.categoryId !== 'all') {
            searchParams.videoCategoryId = params.categoryId;
          }
          if (regionPolicy.regionCode) {
            searchParams.regionCode = regionPolicy.regionCode;
          }
          if (params.pageToken) {
            searchParams.pageToken = params.pageToken;
          }
          if (params.channelId) {
            searchParams.channelId = params.channelId;
          }

          const searchRes = await this.http.get('/search', { params: searchParams });
          const rawSearchItems: Array<Record<string, any>> = searchRes.data?.items ?? [];
          const nextPageToken: string | null = searchRes.data?.nextPageToken ?? null;

          const videoIds = Array.from(
            new Set(
              rawSearchItems
                .map((item) => item?.id?.videoId)
                .filter((id): id is string => typeof id === 'string' && id.length > 0)
            )
          );

          if (videoIds.length === 0) {
            return {
              cacheable: true,
              data: {
                items: [] as Video[],
                nextPageToken: null,
              },
            };
          }

          // Single batched videos.list call to conserve API quota (Section 6.6)
          const detailsRes = await this.http.get('/videos', {
            params: {
              part: 'snippet,contentDetails,statistics',
              id: videoIds.join(','),
              key: envConfig.youtubeApiKey!,
            },
          });

          const rawVideoItems: Array<Record<string, any>> = detailsRes.data?.items ?? [];
          const seenIds = new Set<string>();
          const normalized: Video[] = [];

          for (const raw of rawVideoItems) {
            const vid = String(raw.id || '');
            if (!vid || seenIds.has(vid)) continue;

            const publishedAt = String(raw.snippet?.publishedAt || '');
            // Strict UTC post-verification (Section 6.3)
            if (!verifyPublishedYearUtc(publishedAt, params.year)) {
              continue;
            }

            seenIds.add(vid);
            const viewCount = safeParseCount(raw.statistics?.viewCount);
            const likeCount = safeParseCount(raw.statistics?.likeCount);
            const commentCount = safeParseCount(raw.statistics?.commentCount);
            const durationIso = String(raw.contentDetails?.duration || 'PT0S');
            const ratingSim = computeSimulatedStarRating(vid, viewCount, likeCount, commentCount);

            normalized.push({
              id: vid,
              title: String(raw.snippet?.title || 'Untitled Video'),
              description: String(raw.snippet?.description || ''),
              channelId: String(raw.snippet?.channelId || ''),
              channelTitle: String(raw.snippet?.channelTitle || 'Unknown Channel'),
              publishedAt,
              categoryId: String(raw.snippet?.categoryId || params.categoryId || '24'),
              thumbnailUrl:
                raw.snippet?.thumbnails?.high?.url ||
                raw.snippet?.thumbnails?.medium?.url ||
                raw.snippet?.thumbnails?.default?.url ||
                '',
              viewCount,
              likeCount,
              commentCount,
              duration: durationIso,
              durationSeconds: parseIso8601DurationToSeconds(durationIso),
              liveBroadcastContent:
                raw.snippet?.liveBroadcastContent === 'live'
                  ? 'live'
                  : raw.snippet?.liveBroadcastContent === 'upcoming'
                  ? 'upcoming'
                  : 'none',
              source: 'youtube-api',
              isMock: false,
              historicalYear: params.year,
              yearVerified: true,
              historicalPopularity: 'unknown-historical-rank',
              ratingSimulation: ratingSim,
              ratingSimulationAvailable: ratingSim !== null,
              tags: Array.isArray(raw.snippet?.tags) ? raw.snippet.tags.slice(0, 10) : [],
            });
          }

          return {
            cacheable: true,
            data: {
              items: normalized,
              nextPageToken,
            },
          };
        }
      );

      return {
        items: data.items,
        year: params.year,
        mode: params.mode,
        source: cacheStatus === 'HIT' ? 'cache' : 'youtube-api',
        isMock: false,
        nextPageToken: data.nextPageToken,
        hasMore: Boolean(data.nextPageToken),
        totalResults: null, // Never fabricate exact totalResults when YouTube API only provides estimates
        cacheStatus,
        warnings: [
          'View and like counts reflect current YouTube API statistics, not historical snapshot numbers from the selected year.',
        ],
        requestId: params.requestId,
        appliedDateLock: {
          publishedAfter: bounds.publishedAfter,
          publishedBefore: bounds.publishedBefore,
          regionCode: regionPolicy.regionCode,
          globalChaosActive: regionPolicy.globalChaosActive,
        },
      };
    } catch (err: any) {
      const status = err?.response?.status;
      const reason = err?.response?.data?.error?.errors?.[0]?.reason || 'upstream_error';
      logger.warn({ status, reason, year: params.year }, 'YouTube API call failed; activating controlled mock fallback');

      const fallbackItems = getMockVideosForQuery({
        year: params.year,
        categoryId: params.categoryId,
        query: params.query,
        channelId: params.channelId,
        sort: params.sort,
        limit: params.limit,
      });

      return {
        items: fallbackItems,
        year: params.year,
        mode: params.mode,
        source: 'mock-fallback',
        isMock: true,
        nextPageToken: null,
        hasMore: false,
        totalResults: fallbackItems.length,
        cacheStatus: 'MOCK_FALLBACK',
        warnings: [
          status === 403 || reason === 'quotaExceeded'
            ? 'YouTube Data API v3 quota limit reached. Switched to verified local archive dataset.'
            : 'Upstream YouTube API temporarily unreachable. Switched to verified local archive dataset.',
        ],
        requestId: params.requestId,
        appliedDateLock: {
          publishedAfter: bounds.publishedAfter,
          publishedBefore: bounds.publishedBefore,
          regionCode: regionPolicy.regionCode,
          globalChaosActive: regionPolicy.globalChaosActive,
        },
      };
    }
  }

  public async fetchVideoById(videoId: string, requestId: string): Promise<ApiSingleVideoResponse | null> {
    // Check mock dataset first if ID starts with mock-
    if (videoId.startsWith('mock-')) {
      for (const yearStr of Object.keys(MOCK_VIDEOS_BY_YEAR)) {
        const yearNum = Number(yearStr);
        const found = MOCK_VIDEOS_BY_YEAR[yearNum]?.find((v) => v.id === videoId);
        if (found) {
          const related = MOCK_VIDEOS_BY_YEAR[yearNum].filter((v) => v.id !== videoId);
          return {
            item: found,
            relatedItems: related,
            source: 'mock-fallback',
            isMock: true,
            cacheStatus: 'MOCK_FALLBACK',
            warnings: ['Viewing simulated archive record in Mock Mode.'],
            requestId,
          };
        }
      }
      return null;
    }

    if (!envConfig.youtubeApiKey) {
      return null;
    }

    const cacheKey = `video_detail|id:${videoId}`;
    const { data, cacheStatus } = await cacheService.getOrFetch(cacheKey, async () => {
      const res = await this.http.get('/videos', {
        params: {
          part: 'snippet,contentDetails,statistics',
          id: videoId,
          key: envConfig.youtubeApiKey!,
        },
      });
      const raw = res.data?.items?.[0];
      if (!raw) {
        return { cacheable: false, data: null };
      }
      const publishedAt = String(raw.snippet?.publishedAt || '');
      const pubYear = new Date(Date.parse(publishedAt)).getUTCFullYear() || 2008;
      const viewCount = safeParseCount(raw.statistics?.viewCount);
      const likeCount = safeParseCount(raw.statistics?.likeCount);
      const commentCount = safeParseCount(raw.statistics?.commentCount);
      const durationIso = String(raw.contentDetails?.duration || 'PT0S');
      const ratingSim = computeSimulatedStarRating(videoId, viewCount, likeCount, commentCount);

      const video: Video = {
        id: String(raw.id),
        title: String(raw.snippet?.title || 'Untitled Video'),
        description: String(raw.snippet?.description || ''),
        channelId: String(raw.snippet?.channelId || ''),
        channelTitle: String(raw.snippet?.channelTitle || 'Unknown Channel'),
        publishedAt,
        categoryId: String(raw.snippet?.categoryId || '24'),
        thumbnailUrl:
          raw.snippet?.thumbnails?.high?.url ||
          raw.snippet?.thumbnails?.medium?.url ||
          '',
        viewCount,
        likeCount,
        commentCount,
        duration: durationIso,
        durationSeconds: parseIso8601DurationToSeconds(durationIso),
        liveBroadcastContent: 'none',
        source: 'youtube-api',
        isMock: false,
        historicalYear: pubYear,
        yearVerified: true,
        historicalPopularity: 'unknown-historical-rank',
        ratingSimulation: ratingSim,
        ratingSimulationAvailable: ratingSim !== null,
      };

      return { cacheable: true, data: video };
    });

    if (!data) return null;

    const relatedPool = MOCK_VIDEOS_BY_YEAR[data.historicalYear] ?? MOCK_VIDEOS_BY_YEAR[2008];
    return {
      item: data,
      relatedItems: relatedPool.slice(0, 6),
      source: cacheStatus === 'HIT' ? 'cache' : 'youtube-api',
      isMock: false,
      cacheStatus: cacheStatus === 'HIT' ? 'HIT' : 'MISS',
      warnings: [],
      requestId,
    };
  }

  public async fetchCategories(): Promise<{
    items: CategoryItem[];
    source: 'youtube-api' | 'mock-fallback' | 'cache';
    isMock: boolean;
  }> {
    return {
      items: KNOWN_CATEGORIES,
      source: envConfig.youtubeApiKey ? 'cache' : 'mock-fallback',
      isMock: !envConfig.youtubeApiKey,
    };
  }
}

export const youtubeService = new YouTubeService();
