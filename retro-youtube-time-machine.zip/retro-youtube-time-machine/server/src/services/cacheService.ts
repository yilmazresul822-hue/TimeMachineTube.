import NodeCache from 'node-cache';
import { envConfig } from '../config/env';

export interface CacheQueryParams {
  endpoint: string;
  year: number;
  categoryId?: string;
  regionCode?: string | null;
  query?: string;
  pageToken?: string;
  sort?: string;
  limit?: number;
  channelId?: string;
}

export class QuotaSafeCacheService {
  private cache: NodeCache;
  private inFlight: Map<string, Promise<unknown>>;

  constructor(ttlSeconds = envConfig.cacheTtlSeconds) {
    this.cache = new NodeCache({
      stdTTL: Math.max(900, ttlSeconds), // At least 15 minutes default TTL
      checkperiod: 120,
      useClones: false,
    });
    this.inFlight = new Map();
  }

  public buildKey(params: CacheQueryParams): string {
    const normalizedQuery = (params.query ?? '').trim().toLowerCase();
    return [
      params.endpoint,
      `year:${params.year}`,
      `cat:${params.categoryId || 'all'}`,
      `region:${params.regionCode || 'none'}`,
      `q:${normalizedQuery || 'none'}`,
      `page:${params.pageToken || 'first'}`,
      `sort:${params.sort || 'relevance'}`,
      `limit:${params.limit || 24}`,
      `ch:${params.channelId || 'none'}`,
    ].join('|');
  }

  public get<T>(key: string): T | undefined {
    return this.cache.get<T>(key);
  }

  public set<T>(key: string, value: T, ttlSeconds?: number): void {
    if (ttlSeconds !== undefined) {
      this.cache.set(key, value, ttlSeconds);
    } else {
      this.cache.set(key, value);
    }
  }

  /**
   * Deduplicates concurrent identical requests so 10 simultaneous calls
   * for the same cache key trigger only 1 upstream execution (Section 7.3).
   */
  public async getOrFetch<T>(
    key: string,
    fetcher: () => Promise<{ data: T; cacheable: boolean; ttlSeconds?: number }>
  ): Promise<{ data: T; cacheStatus: 'HIT' | 'MISS' | 'BYPASS' }> {
    const cached = this.get<T>(key);
    if (cached !== undefined) {
      return { data: cached, cacheStatus: 'HIT' };
    }

    const existingPromise = this.inFlight.get(key) as Promise<{
      data: T;
      cacheStatus: 'HIT' | 'MISS' | 'BYPASS';
    }> | undefined;

    if (existingPromise) {
      return existingPromise;
    }

    const executionPromise = (async () => {
      try {
        const result = await fetcher();
        if (result.cacheable) {
          this.set(key, result.data, result.ttlSeconds);
          return { data: result.data, cacheStatus: 'MISS' as const };
        }
        return { data: result.data, cacheStatus: 'BYPASS' as const };
      } finally {
        this.inFlight.delete(key);
      }
    })();

    this.inFlight.set(key, executionPromise);
    return executionPromise;
  }

  public getStats() {
    return {
      keys: this.cache.keys().length,
      inFlightCount: this.inFlight.size,
      stats: this.cache.getStats(),
    };
  }

  public flush(): void {
    this.cache.flushAll();
    this.inFlight.clear();
  }
}

export const cacheService = new QuotaSafeCacheService();
