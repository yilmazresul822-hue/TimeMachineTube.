import { CategoryItem, Video } from '../types/api';
import { computeSimulatedStarRating } from '../utils/ratingSimulation';

export const KNOWN_CATEGORIES: CategoryItem[] = [
  { id: 'all', title: 'All Categories', iconName: 'Compass', description: 'Complete temporal stream for the selected year', assignable: true },
  { id: '1', title: 'Film & Animation', iconName: 'Film', description: 'Stop-motion, indie shorts, Flash animations & machinima', assignable: true },
  { id: '10', title: 'Music', iconName: 'Music', description: 'bedroom synth covers, indie bands & iconic music videos', assignable: true },
  { id: '20', title: 'Gaming', iconName: 'Gamepad2', description: 'Let\'s Plays, speedruns, CRT walkthroughs & esports highlights', assignable: true },
  { id: '28', title: 'Science & Technology', iconName: 'Cpu', description: 'Unboxings, hardware teardowns, coding demos & experiments', assignable: true },
  { id: '23', title: 'Comedy', iconName: 'Laugh', description: 'Sketches, viral parodies & early internet humor', assignable: true },
  { id: '22', title: 'People & Blogs', iconName: 'Users', description: 'Webcam vlogs, daily stories & creator milestones', assignable: true },
  { id: '24', title: 'Entertainment', iconName: 'Tv', description: 'Pop culture, challenges & collaborative creator shows', assignable: true },
  { id: '27', title: 'Education', iconName: 'GraduationCap', description: 'Chalkboard explainers, math proofs & history deep dives', assignable: true },
  { id: '17', title: 'Sports', iconName: 'Trophy', description: 'Skateboarding tapes, trick shots & tournament recaps', assignable: true },
];

interface SeedTemplate {
  suffix: string;
  cat: string;
  channelId: string;
  channelTitle: string;
  titleTemplate: (year: number) => string;
  descTemplate: (year: number) => string;
  monthDay: string;
  duration: string;
  durationSeconds: number;
  baseViews: number;
  baseLikes: number;
  baseComments: number;
  regionOrigin: string;
  tags: string[];
}

const SEED_TEMPLATES: SeedTemplate[] = [
  {
    suffix: 'music-synth',
    cat: '10',
    channelId: 'ch-analog-bedroom',
    channelTitle: 'AnalogBedroomSessions',
    titleTemplate: (y) =>
      y <= 2009
        ? `Live Analog Synth Jam in My Bedroom (${y} Webcam Recording)`
        : y <= 2014
        ? `Synthesizer Cover & Loop Pedal Improvisation [${y} Studio Session]`
        : `Modular Synth & Dawless Late Night Jam (${y} 1080p60)`,
    descTemplate: (y) =>
      `Recorded directly from my home studio desk in ${y}. Using hardware analog keyboards, studio monitor headphones, and live looping.`,
    monthDay: '03-14T18:22:10Z',
    duration: 'PT3M42S',
    durationSeconds: 222,
    baseViews: 148_200,
    baseLikes: 6_420,
    baseComments: 890,
    regionOrigin: 'GB',
    tags: ['synth', 'music', 'jam', 'electronic'],
  },
  {
    suffix: 'gaming-retro',
    cat: '20',
    channelId: 'ch-crt-vault',
    channelTitle: 'CRTVaultGaming',
    titleTemplate: (y) =>
      y <= 2009
        ? `Super Platformer Speedrun World Record Attempt (${y} Capture Card)`
        : y <= 2013
        ? `Let's Play Retro Pixel Odyssey - Part 1 (No Commentary ${y})`
        : `How Frame-Perfect Speedrunners Broke Platformers in ${y}`,
    descTemplate: (y) =>
      `Captured on our Sony Trinitron CRT setup in ${y}. Full stage breakdown, trick jumps, and controller inputs explained.`,
    monthDay: '06-08T21:15:00Z',
    duration: 'PT8M15S',
    durationSeconds: 495,
    baseViews: 312_900,
    baseLikes: 14_800,
    baseComments: 2_310,
    regionOrigin: 'JP',
    tags: ['gaming', 'speedrun', 'retro', 'crt'],
  },
  {
    suffix: 'tech-workbench',
    cat: '28',
    channelId: 'ch-silicon-bench',
    channelTitle: 'SiliconWorkbench',
    titleTemplate: (y) =>
      y <= 2009
        ? `Unboxing & Testing the New ${y} Pocket Smartphone + Laptop Benchmarks`
        : y <= 2014
        ? `${y} Flagship Smartphone & Aluminum Laptop Teardown + Camera Test`
        : `Inside ${y}'s Custom PCB Architecture: Full Microscope Teardown`,
    descTemplate: (y) =>
      `Hands-on hardware review and circuit board inspection filmed on the workbench in ${y}. Testing battery life, display sharpness, and thermal performance.`,
    monthDay: '09-22T14:05:30Z',
    duration: 'PT6M48S',
    durationSeconds: 408,
    baseViews: 425_600,
    baseLikes: 19_200,
    baseComments: 3_140,
    regionOrigin: 'US',
    tags: ['technology', 'review', 'hardware', 'teardown'],
  },
  {
    suffix: 'clay-animation',
    cat: '1',
    channelId: 'ch-stopmotion-lab',
    channelTitle: 'MiniatureClayLab',
    titleTemplate: (y) =>
      y <= 2009
        ? `The Clockwork Alchemist - Stop Motion Claymation Short (${y})`
        : y <= 2014
        ? `Making of "The Glowing Beaker" — 2,400 Frames of Clay Animation (${y})`
        : `Handcrafted Stop-Motion Science Diorama Short Film (${y} Festival Cut)`,
    descTemplate: (y) =>
      `Every brass gear and glowing potion beaker was sculpted by hand over four months in ${y}. Shot at 15 frames per second on a tabletop stage.`,
    monthDay: '11-03T11:40:00Z',
    duration: 'PT2M55S',
    durationSeconds: 175,
    baseViews: 289_400,
    baseLikes: 21_500,
    baseComments: 1_980,
    regionOrigin: 'FR',
    tags: ['animation', 'stopmotion', 'claymation', 'shortfilm'],
  },
  {
    suffix: 'comedy-sketch',
    cat: '23',
    channelId: 'ch-dorm-sketch',
    channelTitle: 'TwoGuysAndACamcorder',
    titleTemplate: (y) =>
      y <= 2009
        ? `When Your Dial-Up / Wi-Fi Drops at 99% Download (${y} Sketch)`
        : y <= 2014
        ? `Every Group Project Meeting Ever (${y} Comedy Parody)`
        : `If Algorithms Controlled Your Real-Life Conversations (${y} Sketch)`,
    descTemplate: (y) =>
      `Filmed in one afternoon with zero budget in ${y}. Thanks for subscribing and leaving 5 stars / thumbs up!`,
    monthDay: '04-19T19:50:12Z',
    duration: 'PT3M12S',
    durationSeconds: 192,
    baseViews: 510_000,
    baseLikes: 28_400,
    baseComments: 4_120,
    regionOrigin: 'CA',
    tags: ['comedy', 'sketch', 'parody', 'humor'],
  },
  {
    suffix: 'vlog-diary',
    cat: '22',
    channelId: 'ch-web-chronicles',
    channelTitle: 'EverydayWebChronicles',
    titleTemplate: (y) =>
      y <= 2009
        ? `A Day in the Life: Navigating the ${y} Internet & Answering Comments`
        : y <= 2014
        ? `Q&A Vlog: Our Studio Upgrade & Community Milestone (${y})`
        : `Reflecting on ${y - 2005} Years of Online Video Culture (${y} Documentary Vlog)`,
    descTemplate: (y) =>
      `Responding to video responses and community questions from ${y}. Drop your thoughts in the comments below!`,
    monthDay: '07-29T16:10:00Z',
    duration: 'PT4M36S',
    durationSeconds: 276,
    baseViews: 94_300,
    baseLikes: 5_120,
    baseComments: 1_050,
    regionOrigin: 'DE',
    tags: ['vlog', 'community', 'qna', 'diary'],
  },
  {
    suffix: 'science-edu',
    cat: '27',
    channelId: 'ch-chalkboard-physics',
    channelTitle: 'ChalkboardPhysicsLab',
    titleTemplate: (y) =>
      `Why Pendulums Synchronize: Visual Physics Demonstration (${y})`,
    descTemplate: (y) =>
      `A clear tabletop physics experiment recorded in ${y} demonstrating coupled oscillators, resonance, and conservation of momentum.`,
    monthDay: '10-12T09:30:00Z',
    duration: 'PT5M20S',
    durationSeconds: 320,
    baseViews: 198_700,
    baseLikes: 11_300,
    baseComments: 840,
    regionOrigin: 'TR',
    tags: ['science', 'physics', 'education', 'experiment'],
  },
  {
    suffix: 'skate-sports',
    cat: '17',
    channelId: 'ch-plaza-tape',
    channelTitle: 'DowntownPlazaTapes',
    titleTemplate: (y) =>
      `Downtown Street Skate & Fisheye Lens Montage (${y} Summer Tape)`,
    descTemplate: (y) =>
      `Filmed with a century fisheye adapter throughout summer ${y}. Kickflips, ledges, and evening sessions with the local crew.`,
    monthDay: '08-15T20:00:00Z',
    duration: 'PT4M05S',
    durationSeconds: 245,
    baseViews: 127_500,
    baseLikes: 7_890,
    baseComments: 620,
    regionOrigin: 'BR',
    tags: ['skateboarding', 'sports', 'fisheye', 'montage'],
  },
];

export function buildSvgDataUriThumbnail(year: number, categoryId: string, title: string): string {
  const palette: Record<string, [string, string, string]> = {
    '10': ['#1e1b4b', '#4338ca', '#f59e0b'],
    '20': ['#064e3b', '#047857', '#34d399'],
    '28': ['#0f172a', '#0369a1', '#38bdf8'],
    '1': ['#4c1d95', '#7e22ce', '#f472b6'],
    '23': ['#7c2d12', '#c2410c', '#fbbf24'],
    '22': ['#1f2937', '#374151', '#60a5fa'],
    '27': ['#14532d', '#15803d', '#fde047'],
    '17': ['#31102F', '#9d174d', '#fb7185'],
  };
  const [c1, c2, accent] = palette[categoryId] || ['#1e293b', '#334155', '#ef4444'];
  const safeLabel = title.slice(0, 32).replace(/[<>&"']/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="480" height="270" viewBox="0 0 480 270">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${c1}"/>
        <stop offset="100%" stop-color="${c2}"/>
      </linearGradient>
    </defs>
    <rect width="480" height="270" fill="url(#g)"/>
    <circle cx="390" cy="70" r="85" fill="${accent}" fill-opacity="0.16"/>
    <rect x="24" y="24" width="84" height="28" rx="4" fill="#000000" fill-opacity="0.55"/>
    <text x="66" y="43" fill="${accent}" font-family="Arial, sans-serif" font-size="14" font-weight="bold" text-anchor="middle">${year} ARCHIVE</text>
    <text x="24" y="218" fill="#ffffff" font-family="Arial, sans-serif" font-size="17" font-weight="bold">${safeLabel}...</text>
    <text x="24" y="242" fill="#cbd5e1" font-family="Arial, sans-serif" font-size="12">MOCK FALLBACK DATASET • CATEGORY ${categoryId}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export const MOCK_VIDEOS_BY_YEAR: Record<number, Video[]> = {};

for (let year = 2006; year <= 2019; year += 1) {
  const yearFactor = 1 + (year - 2006) * 0.18;
  MOCK_VIDEOS_BY_YEAR[year] = SEED_TEMPLATES.map((tpl, idx) => {
    const id = `mock-${year}-${idx + 1}-${tpl.suffix}`;
    const views = Math.round(tpl.baseViews * yearFactor * (1 + (idx % 3) * 0.12));
    const likes = Math.round(tpl.baseLikes * yearFactor);
    const comments = Math.round(tpl.baseComments * yearFactor);
    const title = tpl.titleTemplate(year);
    const ratingSim = computeSimulatedStarRating(id, views, likes, comments);

    return {
      id,
      title,
      description: tpl.descTemplate(year),
      channelId: tpl.channelId,
      channelTitle: tpl.channelTitle,
      publishedAt: `${year}-${tpl.monthDay}`,
      categoryId: tpl.cat,
      thumbnailUrl: buildSvgDataUriThumbnail(year, tpl.cat, title),
      viewCount: views,
      likeCount: likes,
      commentCount: comments,
      duration: tpl.duration,
      durationSeconds: tpl.durationSeconds,
      liveBroadcastContent: 'none',
      source: 'mock-fallback',
      isMock: true,
      historicalYear: year,
      yearVerified: true,
      historicalPopularity: 'simulated-era-curated',
      ratingSimulation: ratingSim,
      ratingSimulationAvailable: ratingSim !== null,
      regionOrigin: tpl.regionOrigin,
      tags: [...tpl.tags, String(year)],
    };
  });
}

export function getMockVideosForQuery(params: {
  year: number;
  categoryId?: string;
  query?: string;
  channelId?: string;
  sort?: 'relevance' | 'viewCount' | 'date' | 'rating';
  limit?: number;
}): Video[] {
  const yearPool = MOCK_VIDEOS_BY_YEAR[params.year] ?? [];
  let filtered = [...yearPool];

  if (params.categoryId && params.categoryId !== 'all') {
    filtered = filtered.filter((v) => v.categoryId === params.categoryId);
  }

  if (params.channelId) {
    filtered = filtered.filter((v) => v.channelId === params.channelId);
  }

  if (params.query && params.query.trim().length > 0) {
    const q = params.query.trim().toLowerCase();
    filtered = filtered.filter(
      (v) =>
        v.title.toLowerCase().includes(q) ||
        v.description.toLowerCase().includes(q) ||
        v.channelTitle.toLowerCase().includes(q) ||
        (v.tags ?? []).some((t) => t.toLowerCase().includes(q))
    );
  }

  if (params.sort === 'viewCount') {
    filtered.sort((a, b) => (b.viewCount ?? 0) - (a.viewCount ?? 0));
  } else if (params.sort === 'date') {
    filtered.sort((a, b) => Date.parse(b.publishedAt) - Date.parse(a.publishedAt));
  } else if (params.sort === 'rating') {
    filtered.sort(
      (a, b) => (b.ratingSimulation?.stars ?? 0) - (a.ratingSimulation?.stars ?? 0)
    );
  }

  return filtered.slice(0, params.limit ?? 24);
}
