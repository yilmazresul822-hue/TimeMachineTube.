export const MIN_SUPPORTED_YEAR = 2006;
export const MAX_SUPPORTED_YEAR = 2019;

export interface UtcYearBounds {
  year: number;
  publishedAfter: string;
  publishedBefore: string;
}

export function isSupportedYear(year: number): boolean {
  return Number.isInteger(year) && year >= MIN_SUPPORTED_YEAR && year <= MAX_SUPPORTED_YEAR;
}

/**
 * Computes strict UTC ISO-8601 boundaries for a target historical year.
 * Start: YYYY-01-01T00:00:00Z
 * End:   (YYYY + 1)-01-01T00:00:00Z
 */
export function getUtcYearBounds(year: number): UtcYearBounds {
  if (!isSupportedYear(year)) {
    throw new RangeError(`Year ${year} is outside supported range (${MIN_SUPPORTED_YEAR}-${MAX_SUPPORTED_YEAR}).`);
  }
  const startUtc = new Date(Date.UTC(year, 0, 1, 0, 0, 0, 0)).toISOString().replace('.000Z', 'Z');
  const endUtc = new Date(Date.UTC(year + 1, 0, 1, 0, 0, 0, 0)).toISOString().replace('.000Z', 'Z');
  return {
    year,
    publishedAfter: startUtc,
    publishedBefore: endUtc,
  };
}

/**
 * Verifies that an ISO-8601 timestamp strictly falls within the target UTC calendar year.
 */
export function verifyPublishedYearUtc(publishedAtIso: string, targetYear: number): boolean {
  if (!publishedAtIso || typeof publishedAtIso !== 'string') {
    return false;
  }
  const timestamp = Date.parse(publishedAtIso);
  if (Number.isNaN(timestamp)) {
    return false;
  }
  const parsedDate = new Date(timestamp);
  return parsedDate.getUTCFullYear() === targetYear;
}

/**
 * Global Chaos Filter policy (Section 6.5):
 * - 2006–2011: Do not pass a default regionCode so international videos surface naturally.
 * - 2012–2019: Default to regionCode="US" unless user explicitly supplies a valid ISO 3166-1 alpha-2 region.
 */
export function resolveRegionPolicy(
  year: number,
  userRegionCode?: string | null
): { regionCode: string | null; globalChaosActive: boolean } {
  const cleaned = userRegionCode?.trim().toUpperCase() || null;
  if (cleaned && /^[A-Z]{2}$/.test(cleaned)) {
    return { regionCode: cleaned, globalChaosActive: false };
  }
  if (year >= 2006 && year <= 2011) {
    return { regionCode: null, globalChaosActive: true };
  }
  return { regionCode: 'US', globalChaosActive: false };
}
