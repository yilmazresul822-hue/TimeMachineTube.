import pino from 'pino';
import { envConfig } from '../config/env';

export const logger = pino({
  level: envConfig.nodeEnv === 'test' ? 'silent' : 'info',
  redact: {
    paths: [
      'req.headers.authorization',
      'apiKey',
      'key',
      'YOUTUBE_API_KEY',
      'params.key',
      'config.params.key',
    ],
    censor: '[REDACTED_SECRET]',
  },
});
