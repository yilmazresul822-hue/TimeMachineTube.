import { NextFunction, Request, Response } from 'express';
import crypto from 'crypto';

export function securityAndRequestIdMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const reqId = `tm-${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`;
  res.locals.requestId = reqId;
  res.setHeader('X-Request-Id', reqId);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
}
