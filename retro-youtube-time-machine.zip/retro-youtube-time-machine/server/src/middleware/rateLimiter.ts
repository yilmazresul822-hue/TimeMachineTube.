import { NextFunction, Request, Response } from 'express';
import { envConfig } from '../config/env';

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

export function rateLimiterMiddleware(req: Request, res: Response, next: NextFunction): void {
  const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const existing = buckets.get(clientIp);

  if (!existing || now > existing.resetAt) {
    buckets.set(clientIp, {
      count: 1,
      resetAt: now + envConfig.rateLimitWindowMs,
    });
    next();
    return;
  }

  existing.count += 1;
  if (existing.count > envConfig.rateLimitMaxRequests) {
    res.status(429).json({
      error: {
        code: 'RATE_LIMIT_EXCEEDED',
        message: 'Too many requests from this client within the rate-limit window.',
        userAction: 'Please wait a moment before switching years or issuing rapid searches.',
        requestId: String(res.locals.requestId || 'req-rate-limit'),
      },
    });
    return;
  }

  next();
}
