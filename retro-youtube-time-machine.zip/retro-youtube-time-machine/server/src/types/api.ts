export type RealityLayer =
  | 'Historical Reference'
  | 'Live YouTube Data'
  | 'Simulated Historical Experience'
  | 'Estimated Reconstruction';

export type DataSourceType = 'youtube-api' | 'mock-fallback' | 'cache';

export interface RatingSimulationResult {
  stars: number;
  roundedHalfStars: number;
  confidence: 'low' | 'medium' | 'high';
  sampleSize: number;
  engagementRatio: number;
  isSimulated: true;
  methodologyNote: string;
}

export interface Video {
  id: string;
  title: string;
  description: string;
  channelId: string;
  channelTitle: string;
  publishedAt: string;
  categoryId: string;
  thumbnailUrl: string;
  viewCount: number | null;
  likeCount: number | null;
  commentCount: number | null;
  duration: string;
  durationSeconds: number;
  liveBroadcastContent: 'none' | 'live' | 'upcoming';
  source: DataSourceType;
  isMock: boolean;
  historicalYear: number;
  yearVerified: boolean;
  historicalPopularity: 'unknown-historical-rank' | 'simulated-era-curated';
  ratingSimulation: RatingSimulationResult | null;
  ratingSimulationAvailable: boolean;
  regionOrigin?: string;
  tags?: string[];
}

export interface CategoryItem {
  id: string;
  title: string;
  iconName: string;
  description: string;
  assignable: boolean;
}

export interface ApiVideoListResponse {
  items: Video[];
  year: number;
  mode: 'feed' | 'search' | 'category' | 'channel';
  source: DataSourceType;
  isMock: boolean;
  nextPageToken: string | null;
  hasMore: boolean;
  totalResults: number | null;
  cacheStatus: 'HIT' | 'MISS' | 'BYPASS' | 'MOCK_FALLBACK';
  warnings: string[];
  requestId: string;
  appliedDateLock: {
    publishedAfter: string;
    publishedBefore: string;
    regionCode: string | null;
    globalChaosActive: boolean;
  };
}

export interface ApiSingleVideoResponse {
  item: Video;
  relatedItems: Video[];
  source: DataSourceType;
  isMock: boolean;
  cacheStatus: 'HIT' | 'MISS' | 'MOCK_FALLBACK';
  warnings: string[];
  requestId: string;
}

export interface ApiErrorResponse {
  error: {
    code:
      | 'INVALID_PARAMETERS'
      | 'VIDEO_NOT_FOUND'
      | 'RATE_LIMIT_EXCEEDED'
      | 'QUOTA_EXCEEDED'
      | 'UPSTREAM_API_ERROR'
      | 'INTERNAL_SERVER_ERROR';
    message: string;
    userAction: string;
    requestId: string;
    details?: Record<string, unknown>;
  };
}
