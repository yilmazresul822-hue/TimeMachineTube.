import { Router, Request, Response } from 'express';
import { envConfig } from '../config/env';
import {
  searchQuerySchema,
  videoIdParamSchema,
  videosQuerySchema,
} from '../schemas/apiSchemas';
import { cacheService } from '../services/cacheService';
import { youtubeService } from '../services/youtubeService';
import { MAX_SUPPORTED_YEAR, MIN_SUPPORTED_YEAR } from '../utils/dateLock';

export const apiRouter = Router();

const ERA_SUMMARIES = [
  { year: 2006, eraId: 'classic-2006', eraLabel: '2006 — Broadcast Yourself Web 2.0 Utility' },
  { year: 2007, eraId: 'classic-2007', eraLabel: '2007 — Early Partner & Flash Portal Era' },
  { year: 2008, eraId: 'classic-2008', eraLabel: '2008 — Widescreen Transition & 5-Star Portal' },
  { year: 2009, eraId: 'classic-2009', eraLabel: '2009 — HD 720p/1080p & Late Star-Rating Era' },
  { year: 2010, eraId: 'transitional-2010', eraLabel: '2010 — Thumbs Up/Down & Clean Watch Page' },
  { year: 2011, eraId: 'transitional-2011', eraLabel: '2011 — Cosmic Panda Dark Stage & Social Feed' },
  { year: 2012, eraId: 'transitional-2012', eraLabel: '2012 — Guide Sidebar & Channel Destination Era' },
  { year: 2013, eraId: 'transitional-2013', eraLabel: '2013 — Hitchhiker Cards & One Channel Layout' },
  { year: 2014, eraId: 'material-2014', eraLabel: '2014 — Creator Studio & Centered Guide UI' },
  { year: 2015, eraId: 'material-2015', eraLabel: '2015 — Early Material Surfaces & Red Branding' },
  { year: 2016, eraId: 'material-2016', eraLabel: '2016 — Material Cards & Trending Tab Evolution' },
  { year: 2017, eraId: 'modern-2017', eraLabel: '2017 — Polymer Redesign & New Play Icon Logo' },
  { year: 2018, eraId: 'modern-2018', eraLabel: '2018 — Refined Polymer & Dark Theme Maturity' },
  { year: 2019, eraId: 'modern-2019', eraLabel: '2019 — Wide Responsive Grid & Pre-Shorts Modern UI' },
];

apiRouter.get('/health', (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'ok',
    service: 'retro-youtube-time-machine-server',
    apiKeyConfigured: Boolean(envConfig.youtubeApiKey),
    mockFallbackReady: true,
    supportedYearRange: [MIN_SUPPORTED_YEAR, MAX_SUPPORTED_YEAR],
    cache: cacheService.getStats(),
    requestId: res.locals.requestId,
  });
});

apiRouter.get('/eras', (_req: Request, res: Response) => {
  res.status(200).json({
    minYear: MIN_SUPPORTED_YEAR,
    maxYear: MAX_SUPPORTED_YEAR,
    eras: ERA_SUMMARIES,
    requestId: res.locals.requestId,
  });
});

apiRouter.get('/categories', async (_req: Request, res: Response) => {
  const result = await youtubeService.fetchCategories();
  res.status(200).json({
    ...result,
    requestId: res.locals.requestId,
  });
});

apiRouter.get('/videos', async (req: Request, res: Response) => {
  const parsed = videosQuerySchema.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({
      error: {
        code: 'INVALID_PARAMETERS',
        message: parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; '),
        userAction: 'Please select a valid year between 2006 and 2019 and check filter values.',
        requestId: res.locals.requestId,
      },
    });
    return;
  }

  const response = await youtubeService.fetchVideos({
    ...parsed.data,
    requestId: res.locals.requestId,
  });
  res.status(200).json(response);
});

apiRouter.get('/search', async (req: Request, res: Response) => {
  const parsed = searchQuerySchema.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({
      error: {
        code: 'INVALID_PARAMETERS',
        message: parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; '),
        userAction: 'Provide a non-empty search query (up to 100 characters) and a valid year (2006–2019).',
        requestId: res.locals.requestId,
      },
    });
    return;
  }

  const response = await youtubeService.fetchVideos({
    ...parsed.data,
    mode: 'search',
    requestId: res.locals.requestId,
  });
  res.status(200).json(response);
});

apiRouter.get('/videos/:videoId', async (req: Request, res: Response) => {
  const parsed = videoIdParamSchema.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({
      error: {
        code: 'INVALID_PARAMETERS',
        message: 'Invalid videoId parameter format.',
        userAction: 'Provide a valid alphanumeric video identifier.',
        requestId: res.locals.requestId,
      },
    });
    return;
  }

  const found = await youtubeService.fetchVideoById(parsed.data.videoId, res.locals.requestId);
  if (!found) {
    res.status(404).json({
      error: {
        code: 'VIDEO_NOT_FOUND',
        message: `Video '${parsed.data.videoId}' was not found in the archive or upstream API.`,
        userAction: 'Return to the year feed or choose another video card.',
        requestId: res.locals.requestId,
      },
    });
    return;
  }

  res.status(200).json(found);
});
