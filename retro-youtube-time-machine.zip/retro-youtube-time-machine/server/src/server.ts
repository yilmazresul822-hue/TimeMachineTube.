import { createApp } from './app';
import { envConfig } from './config/env';
import { logger } from './utils/logger';

const app = createApp();

app.listen(envConfig.port, () => {
  logger.info(
    {
      port: envConfig.port,
      nodeEnv: envConfig.nodeEnv,
      youtubeApiKeyConfigured: Boolean(envConfig.youtubeApiKey),
    },
    'Retro YouTube Time Machine backend listening'
  );
});
