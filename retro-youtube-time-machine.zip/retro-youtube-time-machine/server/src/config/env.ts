import dotenv from 'dotenv';

dotenv.config();

export interface ServerEnvConfig {
  port: number;
  nodeEnv: 'development' | 'production' | 'test';
  corsOrigin: string;
  youtubeApiKey: string | null;
  cacheTtlSeconds: number;
  rateLimitWindowMs: number;
  rateLimitMaxRequests: number;
}

function parsePositiveInt(val: string | undefined, fallback: number): number {
  if (!val) return fallback;
  const parsed = Number.parseInt(val, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

const rawKey = process.env.YOUTUBE_API_KEY?.trim() ?? '';
const hasValidKey =
  rawKey.length > 10 &&
  rawKey !== 'your_youtube_api_key_here' &&
  !rawKey.startsWith('REPLACE_');

export const envConfig: ServerEnvConfig = {
  port: parsePositiveInt(process.env.PORT, 4000),
  nodeEnv:
    process.env.NODE_ENV === 'production'
      ? 'production'
      : process.env.NODE_ENV === 'test'
      ? 'test'
      : 'development',
  corsOrigin: process.env.CORS_ORIGIN?.trim() || 'http://localhost:5173',
  youtubeApiKey: hasValidKey ? rawKey : null,
  cacheTtlSeconds: Math.max(900, parsePositiveInt(process.env.CACHE_TTL_SECONDS, 900)),
  rateLimitWindowMs: parsePositiveInt(process.env.RATE_LIMIT_WINDOW_MS, 60_000),
  rateLimitMaxRequests: parsePositiveInt(process.env.RATE_LIMIT_MAX_REQUESTS, 60),
};
